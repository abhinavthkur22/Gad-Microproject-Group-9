﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Billing
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Billing))
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GunaShadowPanel1 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceButton2 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaAdvenceButton1 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.SearchProd = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Print = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.ClearAll = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.AddStock = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.BillingSTK = New Guna.UI.WinForms.GunaTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CustomerContactnotxt = New Guna.UI.WinForms.GunaTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CustomerAddresstxt = New Guna.UI.WinForms.GunaTextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.CustomerNametxt = New Guna.UI.WinForms.GunaTextBox()
        Me.GunaShadowPanel2 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.DataGridView1 = New Guna.UI.WinForms.GunaDataGridView()
        Me.Totalcost = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ShadowPanel3 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaCircleButton1 = New Guna.UI.WinForms.GunaCircleButton()
        Me.Button1 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaLabel1 = New Guna.UI.WinForms.GunaLabel()
        Me.Panel3 = New Guna.UI.WinForms.GunaElipsePanel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox2 = New Guna.UI.WinForms.GunaTextBox()
        Me.GunaCirclePictureBox2 = New Guna.UI.WinForms.GunaCirclePictureBox()
        Me.Doc = New System.Drawing.Printing.PrintDocument()
        Me.PPD = New System.Windows.Forms.PrintPreviewDialog()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GunaShadowPanel1.SuspendLayout()
        Me.GunaShadowPanel2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ShadowPanel3.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.GunaCirclePictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GunaShadowPanel1
        '
        Me.GunaShadowPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaShadowPanel1.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel1.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel1.Controls.Add(Me.GunaAdvenceButton2)
        Me.GunaShadowPanel1.Controls.Add(Me.GunaAdvenceButton1)
        Me.GunaShadowPanel1.Controls.Add(Me.SearchProd)
        Me.GunaShadowPanel1.Controls.Add(Me.Label7)
        Me.GunaShadowPanel1.Controls.Add(Me.Print)
        Me.GunaShadowPanel1.Controls.Add(Me.ClearAll)
        Me.GunaShadowPanel1.Controls.Add(Me.AddStock)
        Me.GunaShadowPanel1.Controls.Add(Me.Label4)
        Me.GunaShadowPanel1.Controls.Add(Me.BillingSTK)
        Me.GunaShadowPanel1.Controls.Add(Me.Label3)
        Me.GunaShadowPanel1.Controls.Add(Me.CustomerContactnotxt)
        Me.GunaShadowPanel1.Controls.Add(Me.Label2)
        Me.GunaShadowPanel1.Controls.Add(Me.CustomerAddresstxt)
        Me.GunaShadowPanel1.Controls.Add(Me.Label34)
        Me.GunaShadowPanel1.Controls.Add(Me.CustomerNametxt)
        Me.GunaShadowPanel1.Location = New System.Drawing.Point(2, 3)
        Me.GunaShadowPanel1.Name = "GunaShadowPanel1"
        Me.GunaShadowPanel1.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel1.Size = New System.Drawing.Size(1253, 257)
        Me.GunaShadowPanel1.TabIndex = 0
        '
        'GunaAdvenceButton2
        '
        Me.GunaAdvenceButton2.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton2.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton2.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton2.BorderColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton2.BorderSize = 2
        Me.GunaAdvenceButton2.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton2.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaAdvenceButton2.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton2.CheckedImage = Nothing
        Me.GunaAdvenceButton2.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton2.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaAdvenceButton2.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.Image = Global.ElectronicStore.My.Resources.Resources.printer__2_
        Me.GunaAdvenceButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton2.ImageSize = New System.Drawing.Size(25, 25)
        Me.GunaAdvenceButton2.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton2.Location = New System.Drawing.Point(867, 183)
        Me.GunaAdvenceButton2.Name = "GunaAdvenceButton2"
        Me.GunaAdvenceButton2.OnHoverBaseColor = System.Drawing.Color.Aqua
        Me.GunaAdvenceButton2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.OnHoverImage = Nothing
        Me.GunaAdvenceButton2.OnHoverLineColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.Radius = 10
        Me.GunaAdvenceButton2.Size = New System.Drawing.Size(184, 48)
        Me.GunaAdvenceButton2.TabIndex = 44
        Me.GunaAdvenceButton2.Text = "Print Bill"
        Me.GunaAdvenceButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaAdvenceButton1
        '
        Me.GunaAdvenceButton1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaAdvenceButton1.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton1.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton1.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.CheckedImage = CType(resources.GetObject("GunaAdvenceButton1.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton1.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaAdvenceButton1.ForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.Image = Global.ElectronicStore.My.Resources.Resources.menu3
        Me.GunaAdvenceButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton1.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton1.Location = New System.Drawing.Point(1065, 9)
        Me.GunaAdvenceButton1.Name = "GunaAdvenceButton1"
        Me.GunaAdvenceButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.OnHoverImage = Nothing
        Me.GunaAdvenceButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.Radius = 10
        Me.GunaAdvenceButton1.Size = New System.Drawing.Size(180, 42)
        Me.GunaAdvenceButton1.TabIndex = 43
        Me.GunaAdvenceButton1.Text = "Back To Dahboard"
        Me.GunaAdvenceButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'SearchProd
        '
        Me.SearchProd.AnimationHoverSpeed = 0.07!
        Me.SearchProd.AnimationSpeed = 0.03!
        Me.SearchProd.BackColor = System.Drawing.Color.Transparent
        Me.SearchProd.BaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.SearchProd.BorderColor = System.Drawing.Color.Gray
        Me.SearchProd.BorderSize = 2
        Me.SearchProd.CheckedBaseColor = System.Drawing.Color.Gray
        Me.SearchProd.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SearchProd.CheckedForeColor = System.Drawing.Color.White
        Me.SearchProd.CheckedImage = Nothing
        Me.SearchProd.CheckedLineColor = System.Drawing.Color.DimGray
        Me.SearchProd.DialogResult = System.Windows.Forms.DialogResult.None
        Me.SearchProd.FocusedColor = System.Drawing.Color.Empty
        Me.SearchProd.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchProd.ForeColor = System.Drawing.Color.Black
        Me.SearchProd.Image = Nothing
        Me.SearchProd.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.SearchProd.ImageSize = New System.Drawing.Size(25, 25)
        Me.SearchProd.LineColor = System.Drawing.Color.Black
        Me.SearchProd.Location = New System.Drawing.Point(262, 183)
        Me.SearchProd.Name = "SearchProd"
        Me.SearchProd.OnHoverBaseColor = System.Drawing.Color.Yellow
        Me.SearchProd.OnHoverBorderColor = System.Drawing.Color.Black
        Me.SearchProd.OnHoverForeColor = System.Drawing.Color.Black
        Me.SearchProd.OnHoverImage = Nothing
        Me.SearchProd.OnHoverLineColor = System.Drawing.Color.Black
        Me.SearchProd.OnPressedColor = System.Drawing.Color.Black
        Me.SearchProd.Radius = 10
        Me.SearchProd.Size = New System.Drawing.Size(215, 48)
        Me.SearchProd.TabIndex = 6
        Me.SearchProd.Text = "Search Product with STK"
        Me.SearchProd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(12, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(162, 23)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Billing Details"
        '
        'Print
        '
        Me.Print.AnimationHoverSpeed = 0.07!
        Me.Print.AnimationSpeed = 0.03!
        Me.Print.BackColor = System.Drawing.Color.Transparent
        Me.Print.BaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Print.BorderColor = System.Drawing.Color.Gray
        Me.Print.BorderSize = 2
        Me.Print.CheckedBaseColor = System.Drawing.Color.Gray
        Me.Print.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Print.CheckedForeColor = System.Drawing.Color.White
        Me.Print.CheckedImage = Nothing
        Me.Print.CheckedLineColor = System.Drawing.Color.DimGray
        Me.Print.DialogResult = System.Windows.Forms.DialogResult.None
        Me.Print.FocusedColor = System.Drawing.Color.Empty
        Me.Print.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Print.ForeColor = System.Drawing.Color.Black
        Me.Print.Image = Nothing
        Me.Print.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Print.ImageSize = New System.Drawing.Size(25, 25)
        Me.Print.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Print.Location = New System.Drawing.Point(1058, 183)
        Me.Print.Name = "Print"
        Me.Print.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Print.OnHoverBorderColor = System.Drawing.Color.Black
        Me.Print.OnHoverForeColor = System.Drawing.Color.Black
        Me.Print.OnHoverImage = Nothing
        Me.Print.OnHoverLineColor = System.Drawing.Color.Black
        Me.Print.OnPressedColor = System.Drawing.Color.Black
        Me.Print.Radius = 10
        Me.Print.Size = New System.Drawing.Size(184, 48)
        Me.Print.TabIndex = 9
        Me.Print.Text = "Preview Bill"
        Me.Print.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ClearAll
        '
        Me.ClearAll.AnimationHoverSpeed = 0.07!
        Me.ClearAll.AnimationSpeed = 0.03!
        Me.ClearAll.BackColor = System.Drawing.Color.Transparent
        Me.ClearAll.BaseColor = System.Drawing.Color.Red
        Me.ClearAll.BorderColor = System.Drawing.Color.Gray
        Me.ClearAll.BorderSize = 2
        Me.ClearAll.CheckedBaseColor = System.Drawing.Color.Gray
        Me.ClearAll.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClearAll.CheckedForeColor = System.Drawing.Color.White
        Me.ClearAll.CheckedImage = Nothing
        Me.ClearAll.CheckedLineColor = System.Drawing.Color.DimGray
        Me.ClearAll.DialogResult = System.Windows.Forms.DialogResult.None
        Me.ClearAll.FocusedColor = System.Drawing.Color.Empty
        Me.ClearAll.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearAll.ForeColor = System.Drawing.Color.Black
        Me.ClearAll.Image = Nothing
        Me.ClearAll.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ClearAll.ImageSize = New System.Drawing.Size(25, 25)
        Me.ClearAll.LineColor = System.Drawing.Color.Black
        Me.ClearAll.Location = New System.Drawing.Point(675, 183)
        Me.ClearAll.Name = "ClearAll"
        Me.ClearAll.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClearAll.OnHoverBorderColor = System.Drawing.Color.Black
        Me.ClearAll.OnHoverForeColor = System.Drawing.Color.White
        Me.ClearAll.OnHoverImage = Nothing
        Me.ClearAll.OnHoverLineColor = System.Drawing.Color.Black
        Me.ClearAll.OnPressedColor = System.Drawing.Color.Black
        Me.ClearAll.Radius = 10
        Me.ClearAll.Size = New System.Drawing.Size(184, 48)
        Me.ClearAll.TabIndex = 8
        Me.ClearAll.Text = "Clear All"
        Me.ClearAll.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'AddStock
        '
        Me.AddStock.AnimationHoverSpeed = 0.07!
        Me.AddStock.AnimationSpeed = 0.03!
        Me.AddStock.BackColor = System.Drawing.Color.Transparent
        Me.AddStock.BaseColor = System.Drawing.Color.Lime
        Me.AddStock.BorderColor = System.Drawing.Color.Gray
        Me.AddStock.BorderSize = 2
        Me.AddStock.CheckedBaseColor = System.Drawing.Color.Gray
        Me.AddStock.CheckedBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.AddStock.CheckedForeColor = System.Drawing.Color.White
        Me.AddStock.CheckedImage = Nothing
        Me.AddStock.CheckedLineColor = System.Drawing.Color.DimGray
        Me.AddStock.DialogResult = System.Windows.Forms.DialogResult.None
        Me.AddStock.FocusedColor = System.Drawing.Color.Empty
        Me.AddStock.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddStock.ForeColor = System.Drawing.Color.Black
        Me.AddStock.Image = Nothing
        Me.AddStock.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.AddStock.ImageSize = New System.Drawing.Size(25, 25)
        Me.AddStock.LineColor = System.Drawing.Color.Black
        Me.AddStock.Location = New System.Drawing.Point(483, 183)
        Me.AddStock.Name = "AddStock"
        Me.AddStock.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AddStock.OnHoverBorderColor = System.Drawing.Color.Black
        Me.AddStock.OnHoverForeColor = System.Drawing.Color.White
        Me.AddStock.OnHoverImage = Nothing
        Me.AddStock.OnHoverLineColor = System.Drawing.Color.Black
        Me.AddStock.OnPressedColor = System.Drawing.Color.Black
        Me.AddStock.Radius = 10
        Me.AddStock.Size = New System.Drawing.Size(184, 48)
        Me.AddStock.TabIndex = 7
        Me.AddStock.Text = "Add Stock"
        Me.AddStock.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(31, 176)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(98, 18)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "STK CODE"
        '
        'BillingSTK
        '
        Me.BillingSTK.BackColor = System.Drawing.Color.Transparent
        Me.BillingSTK.BaseColor = System.Drawing.Color.White
        Me.BillingSTK.BorderColor = System.Drawing.Color.Gray
        Me.BillingSTK.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.BillingSTK.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(244, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.BillingSTK.FocusedBorderColor = System.Drawing.Color.Black
        Me.BillingSTK.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.BillingSTK.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BillingSTK.ForeColor = System.Drawing.Color.Black
        Me.BillingSTK.Location = New System.Drawing.Point(17, 183)
        Me.BillingSTK.Margin = New System.Windows.Forms.Padding(10)
        Me.BillingSTK.Name = "BillingSTK"
        Me.BillingSTK.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.BillingSTK.Radius = 10
        Me.BillingSTK.SelectedText = ""
        Me.BillingSTK.Size = New System.Drawing.Size(235, 48)
        Me.BillingSTK.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(554, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 18)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "ContactNo"
        '
        'CustomerContactnotxt
        '
        Me.CustomerContactnotxt.BackColor = System.Drawing.Color.Transparent
        Me.CustomerContactnotxt.BaseColor = System.Drawing.Color.White
        Me.CustomerContactnotxt.BorderColor = System.Drawing.Color.Gray
        Me.CustomerContactnotxt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.CustomerContactnotxt.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(244, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.CustomerContactnotxt.FocusedBorderColor = System.Drawing.Color.Black
        Me.CustomerContactnotxt.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.CustomerContactnotxt.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerContactnotxt.ForeColor = System.Drawing.Color.Black
        Me.CustomerContactnotxt.Location = New System.Drawing.Point(540, 68)
        Me.CustomerContactnotxt.Margin = New System.Windows.Forms.Padding(10)
        Me.CustomerContactnotxt.Name = "CustomerContactnotxt"
        Me.CustomerContactnotxt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.CustomerContactnotxt.Radius = 10
        Me.CustomerContactnotxt.SelectedText = ""
        Me.CustomerContactnotxt.Size = New System.Drawing.Size(235, 48)
        Me.CustomerContactnotxt.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(299, 61)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(169, 18)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = "Customer Address"
        '
        'CustomerAddresstxt
        '
        Me.CustomerAddresstxt.BackColor = System.Drawing.Color.Transparent
        Me.CustomerAddresstxt.BaseColor = System.Drawing.Color.White
        Me.CustomerAddresstxt.BorderColor = System.Drawing.Color.Gray
        Me.CustomerAddresstxt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.CustomerAddresstxt.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(244, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.CustomerAddresstxt.FocusedBorderColor = System.Drawing.Color.Black
        Me.CustomerAddresstxt.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.CustomerAddresstxt.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerAddresstxt.ForeColor = System.Drawing.Color.Black
        Me.CustomerAddresstxt.Location = New System.Drawing.Point(285, 68)
        Me.CustomerAddresstxt.Margin = New System.Windows.Forms.Padding(10)
        Me.CustomerAddresstxt.Name = "CustomerAddresstxt"
        Me.CustomerAddresstxt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.CustomerAddresstxt.Radius = 10
        Me.CustomerAddresstxt.SelectedText = ""
        Me.CustomerAddresstxt.Size = New System.Drawing.Size(235, 48)
        Me.CustomerAddresstxt.TabIndex = 1
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Black
        Me.Label34.Location = New System.Drawing.Point(31, 61)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(149, 18)
        Me.Label34.TabIndex = 13
        Me.Label34.Text = "Customer Name"
        '
        'CustomerNametxt
        '
        Me.CustomerNametxt.BackColor = System.Drawing.Color.Transparent
        Me.CustomerNametxt.BaseColor = System.Drawing.Color.White
        Me.CustomerNametxt.BorderColor = System.Drawing.Color.Gray
        Me.CustomerNametxt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.CustomerNametxt.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(244, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.CustomerNametxt.FocusedBorderColor = System.Drawing.Color.Black
        Me.CustomerNametxt.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.CustomerNametxt.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerNametxt.ForeColor = System.Drawing.Color.Black
        Me.CustomerNametxt.Location = New System.Drawing.Point(17, 68)
        Me.CustomerNametxt.Margin = New System.Windows.Forms.Padding(10)
        Me.CustomerNametxt.Name = "CustomerNametxt"
        Me.CustomerNametxt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.CustomerNametxt.Radius = 10
        Me.CustomerNametxt.SelectedText = ""
        Me.CustomerNametxt.Size = New System.Drawing.Size(235, 48)
        Me.CustomerNametxt.TabIndex = 0
        '
        'GunaShadowPanel2
        '
        Me.GunaShadowPanel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaShadowPanel2.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel2.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel2.Controls.Add(Me.DataGridView1)
        Me.GunaShadowPanel2.Controls.Add(Me.Totalcost)
        Me.GunaShadowPanel2.Controls.Add(Me.Label6)
        Me.GunaShadowPanel2.Controls.Add(Me.Label5)
        Me.GunaShadowPanel2.Location = New System.Drawing.Point(2, 266)
        Me.GunaShadowPanel2.Name = "GunaShadowPanel2"
        Me.GunaShadowPanel2.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel2.Size = New System.Drawing.Size(1253, 507)
        Me.GunaShadowPanel2.TabIndex = 1
        '
        'DataGridView1
        '
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.White
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle7
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.DataGridView1.ColumnHeadersHeight = 21
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column6, Me.Column4, Me.Column5, Me.Column7, Me.Column8, Me.Column9})
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(243, Byte), Integer))
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle9
        Me.DataGridView1.EnableHeadersVisualStyles = False
        Me.DataGridView1.GridColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.DataGridView1.Location = New System.Drawing.Point(16, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(1226, 443)
        Me.DataGridView1.TabIndex = 0
        Me.DataGridView1.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.White
        Me.DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White
        Me.DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.White
        Me.DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DataGridView1.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black
        Me.DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        Me.DataGridView1.ThemeStyle.HeaderStyle.Height = 21
        Me.DataGridView1.ThemeStyle.ReadOnly = True
        Me.DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.DataGridView1.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.DataGridView1.ThemeStyle.RowsStyle.Height = 22
        Me.DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        '
        'Totalcost
        '
        Me.Totalcost.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Totalcost.AutoSize = True
        Me.Totalcost.BackColor = System.Drawing.Color.Transparent
        Me.Totalcost.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Totalcost.ForeColor = System.Drawing.Color.Black
        Me.Totalcost.Location = New System.Drawing.Point(866, 470)
        Me.Totalcost.Name = "Totalcost"
        Me.Totalcost.Size = New System.Drawing.Size(0, 29)
        Me.Totalcost.TabIndex = 50
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(844, 470)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 29)
        Me.Label6.TabIndex = 49
        Me.Label6.Text = "₹"
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(762, 470)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 29)
        Me.Label5.TabIndex = 48
        Me.Label5.Text = "Total: "
        '
        'ShadowPanel3
        '
        Me.ShadowPanel3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ShadowPanel3.BackColor = System.Drawing.Color.Transparent
        Me.ShadowPanel3.BaseColor = System.Drawing.Color.White
        Me.ShadowPanel3.Controls.Add(Me.GunaCircleButton1)
        Me.ShadowPanel3.Controls.Add(Me.Button1)
        Me.ShadowPanel3.Controls.Add(Me.GunaLabel1)
        Me.ShadowPanel3.Controls.Add(Me.Panel3)
        Me.ShadowPanel3.ForeColor = System.Drawing.Color.White
        Me.ShadowPanel3.Location = New System.Drawing.Point(307, 187)
        Me.ShadowPanel3.Name = "ShadowPanel3"
        Me.ShadowPanel3.Radius = 10
        Me.ShadowPanel3.ShadowColor = System.Drawing.Color.Black
        Me.ShadowPanel3.Size = New System.Drawing.Size(716, 321)
        Me.ShadowPanel3.TabIndex = 44
        Me.ShadowPanel3.Visible = False
        '
        'GunaCircleButton1
        '
        Me.GunaCircleButton1.AnimationHoverSpeed = 0.07!
        Me.GunaCircleButton1.AnimationSpeed = 0.03!
        Me.GunaCircleButton1.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaCircleButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaCircleButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaCircleButton1.ForeColor = System.Drawing.Color.White
        Me.GunaCircleButton1.Image = Global.ElectronicStore.My.Resources.Resources.closeIcon2
        Me.GunaCircleButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaCircleButton1.Location = New System.Drawing.Point(675, 12)
        Me.GunaCircleButton1.Name = "GunaCircleButton1"
        Me.GunaCircleButton1.OnHoverBaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton1.OnHoverForeColor = System.Drawing.Color.Transparent
        Me.GunaCircleButton1.OnHoverImage = Nothing
        Me.GunaCircleButton1.OnPressedColor = System.Drawing.Color.Transparent
        Me.GunaCircleButton1.Size = New System.Drawing.Size(30, 24)
        Me.GunaCircleButton1.TabIndex = 7
        '
        'Button1
        '
        Me.Button1.AnimationHoverSpeed = 0.07!
        Me.Button1.AnimationSpeed = 0.03!
        Me.Button1.BackColor = System.Drawing.Color.Transparent
        Me.Button1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button1.BorderColor = System.Drawing.Color.Black
        Me.Button1.CheckedBaseColor = System.Drawing.Color.Gray
        Me.Button1.CheckedBorderColor = System.Drawing.Color.Black
        Me.Button1.CheckedForeColor = System.Drawing.Color.White
        Me.Button1.CheckedImage = Nothing
        Me.Button1.CheckedLineColor = System.Drawing.Color.DimGray
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button1.FocusedColor = System.Drawing.Color.Empty
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Image = Global.ElectronicStore.My.Resources.Resources.enter__1_
        Me.Button1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Button1.ImageSize = New System.Drawing.Size(20, 20)
        Me.Button1.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(154, 197)
        Me.Button1.Name = "Button1"
        Me.Button1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.Button1.OnHoverForeColor = System.Drawing.Color.White
        Me.Button1.OnHoverImage = Nothing
        Me.Button1.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button1.OnPressedColor = System.Drawing.Color.Black
        Me.Button1.Radius = 10
        Me.Button1.Size = New System.Drawing.Size(412, 55)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Verify"
        Me.Button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaLabel1
        '
        Me.GunaLabel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaLabel1.AutoSize = True
        Me.GunaLabel1.Font = New System.Drawing.Font("Segoe UI", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel1.ForeColor = System.Drawing.Color.Black
        Me.GunaLabel1.Location = New System.Drawing.Point(199, 35)
        Me.GunaLabel1.Name = "GunaLabel1"
        Me.GunaLabel1.Size = New System.Drawing.Size(307, 40)
        Me.GunaLabel1.TabIndex = 5
        Me.GunaLabel1.Text = "Verify Your Password"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.BaseColor = System.Drawing.Color.White
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.TextBox2)
        Me.Panel3.Controls.Add(Me.GunaCirclePictureBox2)
        Me.Panel3.Location = New System.Drawing.Point(154, 102)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Radius = 10
        Me.Panel3.Size = New System.Drawing.Size(412, 52)
        Me.Panel3.TabIndex = 2
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(47, 15)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(70, 20)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Password"
        '
        'TextBox2
        '
        Me.TextBox2.BaseColor = System.Drawing.Color.Transparent
        Me.TextBox2.BorderColor = System.Drawing.Color.Transparent
        Me.TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox2.FocusedBaseColor = System.Drawing.Color.Transparent
        Me.TextBox2.FocusedBorderColor = System.Drawing.Color.Transparent
        Me.TextBox2.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBox2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.Color.Blue
        Me.TextBox2.Location = New System.Drawing.Point(47, 4)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9679)
        Me.TextBox2.SelectedText = ""
        Me.TextBox2.Size = New System.Drawing.Size(322, 46)
        Me.TextBox2.TabIndex = 4
        Me.TextBox2.UseSystemPasswordChar = True
        '
        'GunaCirclePictureBox2
        '
        Me.GunaCirclePictureBox2.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCirclePictureBox2.Image = Global.ElectronicStore.My.Resources.Resources.padlock
        Me.GunaCirclePictureBox2.Location = New System.Drawing.Point(3, 5)
        Me.GunaCirclePictureBox2.Name = "GunaCirclePictureBox2"
        Me.GunaCirclePictureBox2.Size = New System.Drawing.Size(38, 40)
        Me.GunaCirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.GunaCirclePictureBox2.TabIndex = 4
        Me.GunaCirclePictureBox2.TabStop = False
        Me.GunaCirclePictureBox2.UseTransfarantBackground = False
        '
        'Doc
        '
        '
        'PPD
        '
        Me.PPD.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PPD.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PPD.ClientSize = New System.Drawing.Size(400, 300)
        Me.PPD.Enabled = True
        Me.PPD.Icon = CType(resources.GetObject("PPD.Icon"), System.Drawing.Icon)
        Me.PPD.Name = "PPD"
        Me.PPD.Visible = False
        '
        'Column1
        '
        Me.Column1.HeaderText = "Sr no"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.HeaderText = "Product Name"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.HeaderText = "Manufacturer"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        '
        'Column6
        '
        Me.Column6.HeaderText = "Quantity"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'Column4
        '
        Me.Column4.HeaderText = "Price"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'Column5
        '
        Me.Column5.HeaderText = "GST%"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.HeaderText = "Tax"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        '
        'Column8
        '
        Me.Column8.HeaderText = "Total "
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Column9
        '
        Me.Column9.HeaderText = "Stk Code"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        '
        'Billing
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1259, 774)
        Me.Controls.Add(Me.ShadowPanel3)
        Me.Controls.Add(Me.GunaShadowPanel2)
        Me.Controls.Add(Me.GunaShadowPanel1)
        Me.Name = "Billing"
        Me.Text = "Billing"
        Me.GunaShadowPanel1.ResumeLayout(False)
        Me.GunaShadowPanel1.PerformLayout()
        Me.GunaShadowPanel2.ResumeLayout(False)
        Me.GunaShadowPanel2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ShadowPanel3.ResumeLayout(False)
        Me.ShadowPanel3.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.GunaCirclePictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GunaShadowPanel1 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaShadowPanel2 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents DataGridView1 As Guna.UI.WinForms.GunaDataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents CustomerAddresstxt As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label34 As Label
    Friend WithEvents CustomerNametxt As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents BillingSTK As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents CustomerContactnotxt As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents AddStock As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Print As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents ClearAll As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents SearchProd As Guna.UI.WinForms.GunaAdvenceButton
    Public WithEvents Totalcost As Label
    Friend WithEvents GunaAdvenceButton1 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents ShadowPanel3 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Panel3 As Guna.UI.WinForms.GunaElipsePanel
    Friend WithEvents TextBox2 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents GunaCirclePictureBox2 As Guna.UI.WinForms.GunaCirclePictureBox
    Friend WithEvents GunaLabel1 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Button1 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Label8 As Label
    Friend WithEvents GunaCircleButton1 As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents Doc As Printing.PrintDocument
    Friend WithEvents PPD As PrintPreviewDialog
    Friend WithEvents GunaAdvenceButton2 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
End Class
