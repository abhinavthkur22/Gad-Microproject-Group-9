﻿Imports System.Net
Imports System.Reflection
Imports System.Security.Cryptography
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports FireSharp
Imports FireSharp.Config
Imports FireSharp.Interfaces
Imports System.Drawing.Printing 'Printing Class for print
Public Class Billing

    Public Shared currentuser, storename, gstno, pass As String
    Dim totalfair, totalwithgst, fair, totalsales, totalsalesfromdatabse, actualsellingprice, actualcostprice, actualprofit, costprice, totalprofitfromdatabse As Double
    Dim tax, CalculatedTax, aviquantity As Int64
            Dim stkcode123 As String
    Private client As IFirebaseClient
    Private Sub Billing_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        WindowState = FormWindowState.Maximized
        DataGridView1.ReadOnly = False
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.AllowUserToDeleteRows = False

        Try
            ' Initialize Firebase client
            Dim fcon As New FirebaseConfig() With {
                .AuthSecret = "gN8oJuBoKD4ZWjFQvwGTS4chLYNyvDXSgeDaJW91",
                .BasePath = "https://userregistration-7cd40-default-rtdb.asia-southeast1.firebasedatabase.app/"
            }
            client = New FireSharp.FirebaseClient(fcon)
        Catch ex As Exception
            MessageBox.Show("Cannot Connect to Surver!! Please Check Your Internet Connection and try again later", "Internet Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try
    End Sub
    Private Sub Billing_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Form1.Close()
    End Sub

    Private Sub SearchProd_Click(sender As Object, e As EventArgs) Handles SearchProd.Click

        If String.IsNullOrEmpty(BillingSTK.Text.ToLower) Then
            MessageBox.Show("Please Provide STK Code to search product", "Invalid stk", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        Try
            Dim res = client.Get("User/" & currentuser & "/ZzappStockdata/" & BillingSTK.Text.ToLower)

            If res.StatusCode = HttpStatusCode.OK Then
                Dim stockItem As Myuser = res.ResultAs(Of Myuser)

                If stockItem IsNot Nothing Then
                    Dim message As String = "Stock Details:" & vbCrLf
                    message &= "Stock Code: " & BillingSTK.Text & vbCrLf
                    message &= "Product Name: " & stockItem.ProductName & vbCrLf
                    message &= "Company Name: " & stockItem.CompanyName & vbCrLf
                    message &= "Model No: " & stockItem.ModelNo & vbCrLf
                    message &= "Selling Price: " & stockItem.SellingPrice.ToString & vbCrLf
                    message &= "Tax: " & stockItem.TAXInNumber.ToString
                    costprice = stockItem.CostPrice

                    Dim Response As DialogResult = MessageBox.Show(message + Environment.NewLine + "Would you like to add this Billings?", "Stock Details", MessageBoxButtons.OKCancel, MessageBoxIcon.Information)

                    If Response = DialogResult.OK Then
                        AddStock_Click(sender, e)
                    End If
                Else
                    MessageBox.Show("No stock data found for the provided STK code.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            Else
                MessageBox.Show("Error retrieving stock data: " & res.StatusCode.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MessageBox.Show("Error retrieving stock data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub DataGridView1_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellValueChanged
        If e.ColumnIndex = 3 Then
            Dim rowIndex As Integer = e.RowIndex
            RecalculateTotalFair(rowIndex)
        End If
    End Sub
    Private Sub RecalculateTotalFair(index As Integer)
        totalfair = 0
        Dim totalTax As Double = 0
        actualprofit = 0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If Not row.IsNewRow Then
                Dim totalRow As Double = 0
                Dim cell As DataGridViewCell = row.Cells(3)
                If cell.Value IsNot Nothing Then
                    Dim quantity As Int64
                    If Int64.TryParse(cell.Value.ToString(), quantity) Then
                        Dim sellingPrice As Int64 = 0
                        If row.Cells.Count > 4 AndAlso row.Cells(4).Value IsNot Nothing Then
                            sellingPrice = Convert.ToInt64(row.Cells(4).Value)
                        End If
                        If quantity = 0 Then
                            Dim result As DialogResult = MessageBox.Show("Quantity is 0. Do you want to remove this row?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                            If result = DialogResult.Yes Then
                                DataGridView1.Rows.Remove(row)
                                Continue For
                            Else
                                cell.Value = 1
                            End If
                        End If
                        actualsellingprice = quantity * sellingPrice
                        actualcostprice = quantity * costprice
                        totalRow = actualsellingprice
                        actualprofit += (actualsellingprice - actualcostprice)
                    End If
                End If

                ' Update total with GST for the current row
                Dim rowTax As Double = 0
                If row.Cells.Count > 5 AndAlso row.Cells(5).Value IsNot Nothing Then
                    rowTax = Convert.ToDouble(row.Cells(5).Value)
                End If
                Dim totalTaxForRow As Double = (totalRow * rowTax) / 100
                totalTax += totalTaxForRow
                totalfair += totalRow
                row.Cells(6).Value = totalTaxForRow
                row.Cells(7).Value = totalRow + totalTaxForRow

            End If
        Next

        ' Update Totalcost label
        Totalcost.Text = totalfair + totalTax
        totalsales = totalfair + totalTax
        '
        '
        'MessageBox.Show(actualprofit.ToString(), "Profit")
    End Sub




    Private Sub AddStock_Click(sender As Object, e As EventArgs) Handles AddStock.Click
        Dim sellingPrice As Int64
        Dim quantity As Int64
        Dim Product As String = ""
        Dim Company As String = ""


        quantity = 1

        If (String.IsNullOrWhiteSpace(BillingSTK.Text)) Then
            MessageBox.Show("Please Provide STK Code to search product", "Invalid stk", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        Try
            Dim res = client.Get("User/" & currentuser & "/ZzappStockdata/" & BillingSTK.Text.ToLower)
            If res.StatusCode = HttpStatusCode.OK Then
                Dim stockItem As Myuser = res.ResultAs(Of Myuser)
                If stockItem IsNot Nothing Then
                    stkcode123 = BillingSTK.Text.ToLower
                    Product = stockItem.ProductName
                    Company = stockItem.CompanyName
                    sellingPrice = Convert.ToInt64(stockItem.SellingPrice)
                    tax = Convert.ToInt64(stockItem.TAXInNumber)
                    BillingSTK.ResetText()
                    aviquantity = stockItem.Quantity
                    costprice = stockItem.CostPrice
                    'MsgBox(costprice)
                Else
                    MessageBox.Show("No stock data found for the provided STK code.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return
                End If
            Else
                MessageBox.Show("Error retrieving stock data: " & res.StatusCode.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
        Catch ex As Exception
            MessageBox.Show("Error retrieving stock data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try

        ' Add new row to the DataGridView
        Dim newRowIdx As Integer = DataGridView1.Rows.Add(
            DataGridView1.Rows.Count + 1,
            Product,
            Company,
            quantity,
            sellingPrice,
            tax,
            totalwithgst
            )
        DataGridView1.Rows(newRowIdx).Cells(8).Value = stkcode123.ToString
        RecalculateTotalFair(newRowIdx)
    End Sub

    Private Sub ClearAll_Click_1(sender As Object, e As EventArgs) Handles ClearAll.Click
        DataGridView1.Rows.Clear()
        Totalcost.Text = 0
        BillingSTK.ResetText()
        CustomerAddresstxt.ResetText()
        CustomerContactnotxt.ResetText()
        CustomerNametxt.ResetText()
        actualcostprice = 0
        actualprofit = 0
        actualsellingprice = 0
    End Sub

    Private Sub Print_Click(sender As Object, e As EventArgs) Handles Print.Click
        BillPrinting()

    End Sub


    Private Sub UpdateUserTotalSalesAndProfit(userId As String, totalSales As Double, totalProfit As Double)
        totalSales += totalsalesfromdatabse
        totalProfit += totalprofitfromdatabse

        Try
            ' Create a new user entry with total sales and total profit
            Dim userData As New Myuser() With {
            .Totalsales = totalSales.ToString(),
            .Totalprofit = totalProfit.ToString()
}

            Dim setter = client.Set("User/" & userId & "/Total_Sales", userData)

            If setter.StatusCode <> HttpStatusCode.OK Then
                MessageBox.Show("Failed to update user total sales and profit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            Throw New Exception("An error occurred while updating user total sales and profit.", ex)
        End Try
    End Sub

    Function GetTotalSales() As Double
        Try

            Dim res = client.Get("User/" & currentuser & "/Total_Sales")
            Dim totals = res.ResultAs(Of Myuser)


            If totals IsNot Nothing Then

                'MsgBox("Total Sales: " & totals.Totalsales)


                Return Double.Parse(totals.Totalsales)
            Else

                MsgBox("Total sales data not found for the current user.")
                Return 0
            End If
        Catch ex As Exception

            MsgBox("An error occurred while retrieving total sales data: " & ex.Message)
            Return 0
        End Try
    End Function

    Function GetTotalProfit() As Double
        Try

            Dim res = client.Get("User/" & currentuser & "/Total_Sales")
            Dim totals = res.ResultAs(Of Myuser)


            If totals IsNot Nothing Then

                'MsgBox("Total Sales: " & totals.Totalsales)


                Return Double.Parse(totals.Totalprofit)
            Else

                MsgBox("Total sales data not found for the current user.")
                Return 0
            End If
        Catch ex As Exception

            MsgBox("An error occurred while retrieving total sales data: " & ex.Message)
            Return 0
        End Try
    End Function
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles GunaAdvenceButton1.Click
        Dim PasswordFromBillingPage As String

        ShadowPanel3.Visible = True

    End Sub

    Private Sub GunaCircleButton1_Click(sender As Object, e As EventArgs) Handles GunaCircleButton1.Click
        ShadowPanel3.Visible = False
    End Sub

    Private Sub TextBox2_GotFocus(sender As Object, e As EventArgs) Handles TextBox2.GotFocus
        Label8.Hide()
    End Sub

    Private Sub TextBox2_LostFocus(sender As Object, e As EventArgs) Handles TextBox2.LostFocus
        If String.IsNullOrEmpty(TextBox2.Text.Trim) Then
            Label8.Show()
        End If
    End Sub
    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If String.IsNullOrEmpty(TextBox2.Text) Then
            MessageBox.Show("Password Required", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Error)
            TextBox2.Focus()
        ElseIf (pass = TextBox2.Text) Then
            Me.Hide()
            Dashboard.ShowDialog()
            ShadowPanel3.Hide()
        Else
            MessageBox.Show("Inccorrect Password", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Dim Invoiceno As Int64

    Function getinvoiceno() As Int64
        Dim InvoiceNumber As Int64 = 0
        Try
            Dim find = client.Get("User/" & currentuser & "/Invoice/InvoiceNumber")
            Dim invoiceResult = find.ResultAs(Of Int64)

            If invoiceResult <> 0 Then
                InvoiceNumber = invoiceResult
            Else
                MsgBox("Something went wrong while retrieving the invoice number.")
            End If
        Catch ex As Exception
            MsgBox("An error occurred: " & ex.Message)
        End Try
        Return InvoiceNumber
    End Function

    Sub setinvoiceno(ByVal newInvoiceNumber As Int64)
        Try
            Dim setincno = client.Set("User/" & currentuser & "/Invoice/InvoiceNumber", newInvoiceNumber)

            If setincno.StatusCode = HttpStatusCode.OK Then

            Else
                MsgBox("Failed to update invoice number.")
            End If
        Catch ex As Exception
            MsgBox("An error occurred: " & ex.Message)
        End Try
    End Sub

    Private Sub Doc_PrintPage(sender As Object, e As PrintPageEventArgs) Handles Doc.PrintPage
        Dim f8 As New Font("Arial", 8, FontStyle.Regular)
        Dim f6 As New Font("Arial", 6, FontStyle.Regular)
        Dim f6b As New Font("Arial", 6, FontStyle.Bold)
        Dim f8b As New Font("Verdana", 8, FontStyle.Bold)
        Dim content As New Font("Verdana", 5, FontStyle.Regular)
        Dim pen As New Pen(Color.Black)
        Dim brush As New SolidBrush(Color.Black)

        Dim Left As New PointF(5, 5)


        Dim right As New StringFormat()
        right.Alignment = StringAlignment.Far

        Dim center As New StringFormat()
        center.Alignment = StringAlignment.Center

        Dim rec1 As New Rectangle(5, 5, 250, 70)

        e.Graphics.DrawString("Invoice", f8b, Brushes.Black, rec1, center)

        Dim startY As Single = 20

        Dim currentInvoiceNo As Int64 = getinvoiceno()

        Dim invoicno As String = "Bill No: BN" & currentInvoiceNo
        e.Graphics.DrawString(invoicno, content, Brushes.Black, Left.X + 5, startY)

        Dim sellerName As String = "Seller Name: " & storename
        e.Graphics.DrawString(sellerName, content, Brushes.Black, Left.X + 5, startY + 15)

        Dim currentDateAndTime As String = DateTime.Now.ToString("dd/MM/yy hh:mm tt")
        e.Graphics.DrawString("Billing Date: " & currentDateAndTime, content, Brushes.Black, Left.X + 5, startY + 30)

        Dim gstNumber As String = "GST No: " & gstno
        e.Graphics.DrawString(gstNumber, content, Brushes.Black, Left.X + 5, startY + 45)

        Dim billingAddress As String = "Billing Address: Chembur "
        e.Graphics.DrawString(billingAddress, content, Brushes.Black, Left.X + 5, startY + 60)

        Dim customerName As String = "Customer Name: " & CustomerNametxt.Text
        e.Graphics.DrawString(customerName, content, Brushes.Black, Left.X + 5, startY + 75)

        Dim CustomerAddress As String = "Customer Address: " & CustomerAddresstxt.Text
        e.Graphics.DrawString(CustomerAddress, content, Brushes.Black, Left.X + 5, startY + 90)

        Dim customerContact As String = "Customer Contact: " & CustomerContactnotxt.Text
        e.Graphics.DrawString(customerContact, content, Brushes.Black, Left.X + 5, startY + 105)


        Dim Bill As New Rectangle(5, startY + 45 + 73, 250, 70)
        Dim srno As New Rectangle(-10, startY + 65 + 73, 60, 17)
        Dim rec2 As New Rectangle(30, startY + 65 + 73, 60, 17)
        Dim rec3 As New Rectangle(85, startY + 65 + 73, 60, 17)
        Dim rec4 As New Rectangle(145, startY + 65 + 73, 60, 17)
        Dim rec5 As New Rectangle(195, startY + 65 + 73, 60, 17)

        e.Graphics.DrawString("Purchased Items", f8b, brush, Bill, center)
        e.Graphics.DrawString("Sr No", f6b, brush, srno, center)
        e.Graphics.DrawString("Product", f6b, brush, rec2, center)
        e.Graphics.DrawString("Qty", f6b, brush, rec3, center)
        e.Graphics.DrawString("Price", f6b, brush, rec4, center)
        e.Graphics.DrawString("Price+Gst", f6b, brush, rec5, center)

        Dim y As Int64 = 0


        For i = 0 To DataGridView1.Rows.Count - 1
            Dim rec6 As New Rectangle(-10, startY + 80 + y + 73, 60, 17)
            Dim rec7 As New Rectangle(30, startY + y + 80 + 73, 60, 17)
            Dim rec8 As New Rectangle(85, startY + y + 80 + 73, 60, 17)
            Dim rec9 As New Rectangle(145, startY + y + 80 + 73, 60, 17)
            Dim rec10 As New Rectangle(195, startY + y + 80 + 73, 60, 17)


            e.Graphics.DrawString(i + 1, f6, brush, rec6, center)
            e.Graphics.DrawString(DataGridView1.Rows(i).Cells(1).Value, f6, brush, rec7, center)
            e.Graphics.DrawString(DataGridView1.Rows(i).Cells(3).Value, f6, brush, rec8, center)
            e.Graphics.DrawString(DataGridView1.Rows(i).Cells(4).Value, f6, brush, rec9, center)
            e.Graphics.DrawString(DataGridView1.Rows(i).Cells(7).Value, f6, brush, rec10, center)
            y += 17
        Next
        Dim rec11 As New Rectangle(-20, startY + y + 80 + 73, 250, 70)
        Dim rec12 As New Rectangle(50, startY + y + 80 + 73, 250, 70)
        e.Graphics.DrawString("Total Price: ", f8b, brush, rec11, center)
        e.Graphics.DrawString(Totalcost.Text, f8b, brush, rec12, center)

        setinvoiceno(currentInvoiceNo + 1)

    End Sub

    Public Sub decreaseQuantity()
        Dim Quantity As Int64
        Dim Stockcode As String
        Dim QuantityFromDatabase As Int64
        Dim updatedQuantity As Int64

        For i = 0 To DataGridView1.RowCount - 1
            Quantity = DataGridView1.Rows(i).Cells(3).Value
            Stockcode = DataGridView1.Rows(i).Cells(8).Value

            Dim getQuantity = client.Get("User/" & currentuser & "/ZzappStockdata/" & Stockcode)
            Dim item = getQuantity.ResultAs(Of Myuser)()

            If item IsNot Nothing Then
                QuantityFromDatabase = Int64.Parse(item.Quantity)
                updatedQuantity = QuantityFromDatabase - Quantity

                Dim setquantity = client.Set("User/" & currentuser & "/ZzappStockdata/" & Stockcode & "/Quantity", updatedQuantity)
            Else
                MsgBox("Item not found in the database.")
            End If
        Next
    End Sub


    Private Sub GunaAdvenceButton2_Click(sender As Object, e As EventArgs) Handles GunaAdvenceButton2.Click
        decreaseQuantity()
        If DataGridView1.RowCount <> 0 And DataGridView1.RowCount >= 1 Then
            totalsalesfromdatabse = GetTotalSales()
            totalprofitfromdatabse = GetTotalProfit()

            Try

                Dim res = client.Get("User/" & currentuser)
                Dim dbsuser = res.ResultAs(Of Myuser)

                If dbsuser Is Nothing Then
                    MessageBox.Show("User does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return
                End If

                UpdateUserTotalSalesAndProfit(currentuser, totalsales, actualprofit)

            Catch ex As Exception
                MessageBox.Show("An error occurred while updating total sales: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Else
            MessageBox.Show("Bill Cannot Be generated due to Empty Product Deatils", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        Doc.Print()
        DataGridView1.Rows.Clear()
        Totalcost.Text = 0
        BillingSTK.ResetText()
        CustomerAddresstxt.ResetText()
        CustomerContactnotxt.ResetText()
        CustomerNametxt.ResetText()
        actualcostprice = 0
        actualprofit = 0
        actualsellingprice = 0
    End Sub
    Public Sub BillPrinting()
        Doc.DefaultPageSettings.PaperSize = New PaperSize("Billing", 260, 600)
        PPD.Document = Doc
        PPD.Show()
        PPD.WindowState = FormWindowState.Maximized
        PPD.PrintPreviewControl.Zoom = 2.5
    End Sub
End Class

