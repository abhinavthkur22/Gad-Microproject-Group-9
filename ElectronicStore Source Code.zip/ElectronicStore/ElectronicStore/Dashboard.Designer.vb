﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dashboard))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GunaImageButton1 = New Guna.UI.WinForms.GunaImageButton()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GunaElipsePanel1 = New Guna.UI.WinForms.GunaElipsePanel()
        Me.GunaShadowPanel1 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.GunaShadowPanel10 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.GunaShadowPanel12 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.GunaShadowPanel13 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaShadowPanel14 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GunaShadowPanel16 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GunaShadowPanel15 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Quantity = New Guna.UI.WinForms.GunaTextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.TaxInPer = New Guna.UI.WinForms.GunaTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SellingPriceTxt = New Guna.UI.WinForms.GunaTextBox()
        Me.Price = New System.Windows.Forms.Label()
        Me.CostPriceTXT = New Guna.UI.WinForms.GunaTextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Stkcode = New System.Windows.Forms.Label()
        Me.STKcodeTextBox = New Guna.UI.WinForms.GunaTextBox()
        Me.AddStockData = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.ModelNumber = New System.Windows.Forms.Label()
        Me.ModelNameTextBox = New Guna.UI.WinForms.GunaTextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.ProName = New Guna.UI.WinForms.GunaTextBox()
        Me.ComName = New System.Windows.Forms.Label()
        Me.CompanyNameText = New Guna.UI.WinForms.GunaTextBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GunaButton1 = New Guna.UI.WinForms.GunaButton()
        Me.RefreshBtn = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaShadowPanel17 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaShadowPanel19 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.GunaCircleButton1 = New Guna.UI.WinForms.GunaCircleButton()
        Me.GunaAdvenceButton2 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.GunaTextBox5 = New Guna.UI.WinForms.GunaTextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.GunaTextBox1 = New Guna.UI.WinForms.GunaTextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.UpadteGstTxt = New Guna.UI.WinForms.GunaTextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.GunaTextBox3 = New Guna.UI.WinForms.GunaTextBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.GunaTextBox4 = New Guna.UI.WinForms.GunaTextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.GunaAdvenceButton1 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.GunaTextBox7 = New Guna.UI.WinForms.GunaTextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.GunaTextBox8 = New Guna.UI.WinForms.GunaTextBox()
        Me.DataGridView1 = New Guna.UI.WinForms.GunaDataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.GunaShadowPanel18 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.GunaShadowPanel11 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GunaCirclePictureBox1 = New Guna.UI.WinForms.GunaCirclePictureBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.Panel2 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GunaShadowPanel6 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.billingaddress = New System.Windows.Forms.Label()
        Me.GunaShadowPanel4 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.state = New System.Windows.Forms.Label()
        Me.GunaShadowPanel7 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.contact = New System.Windows.Forms.Label()
        Me.GunaShadowPanel3 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.surname = New System.Windows.Forms.Label()
        Me.GunaShadowPanel8 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.gstno = New System.Windows.Forms.Label()
        Me.GunaShadowPanel5 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.store = New System.Windows.Forms.Label()
        Me.GunaShadowPanel9 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.address = New System.Windows.Forms.Label()
        Me.GunaShadowPanel2 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.username = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel1 = New Guna.UI.WinForms.GunaElipsePanel()
        Me.ImageButton2 = New Guna.UI.WinForms.GunaImageButton()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.ManageBtn = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.LogoutBtn = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaLabel1 = New Guna.UI.WinForms.GunaLabel()
        Me.StkListBtn = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.TaxBtn = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.AboutBtn = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.DebtBtn = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.DashboardBtn = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Button4 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GunaElipsePanel1.SuspendLayout()
        Me.GunaShadowPanel1.SuspendLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GunaShadowPanel10.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.GunaShadowPanel14.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.GunaShadowPanel16.SuspendLayout()
        Me.GunaShadowPanel15.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GunaShadowPanel17.SuspendLayout()
        Me.GunaShadowPanel19.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        Me.GunaShadowPanel18.SuspendLayout()
        Me.GunaShadowPanel11.SuspendLayout()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GunaShadowPanel6.SuspendLayout()
        Me.GunaShadowPanel4.SuspendLayout()
        Me.GunaShadowPanel7.SuspendLayout()
        Me.GunaShadowPanel3.SuspendLayout()
        Me.GunaShadowPanel8.SuspendLayout()
        Me.GunaShadowPanel5.SuspendLayout()
        Me.GunaShadowPanel9.SuspendLayout()
        Me.GunaShadowPanel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GunaImageButton1
        '
        Me.GunaImageButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaImageButton1.Image = Nothing
        Me.GunaImageButton1.ImageSize = New System.Drawing.Size(64, 64)
        Me.GunaImageButton1.Location = New System.Drawing.Point(227, 309)
        Me.GunaImageButton1.Name = "GunaImageButton1"
        Me.GunaImageButton1.OnHoverImage = Nothing
        Me.GunaImageButton1.OnHoverImageOffset = New System.Drawing.Point(0, 0)
        Me.GunaImageButton1.Size = New System.Drawing.Size(19, 64)
        Me.GunaImageButton1.TabIndex = 1
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Location = New System.Drawing.Point(-13, -35)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1321, 867)
        Me.TabControl1.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Black
        Me.TabPage1.Controls.Add(Me.GunaElipsePanel1)
        Me.TabPage1.Controls.Add(Me.Label26)
        Me.TabPage1.Controls.Add(Me.Label25)
        Me.TabPage1.Controls.Add(Me.GunaShadowPanel12)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.ForeColor = System.Drawing.Color.White
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1313, 841)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        '
        'GunaElipsePanel1
        '
        Me.GunaElipsePanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaElipsePanel1.BackColor = System.Drawing.Color.Transparent
        Me.GunaElipsePanel1.BaseColor = System.Drawing.Color.Transparent
        Me.GunaElipsePanel1.Controls.Add(Me.GunaShadowPanel1)
        Me.GunaElipsePanel1.Controls.Add(Me.GunaShadowPanel10)
        Me.GunaElipsePanel1.Location = New System.Drawing.Point(314, 64)
        Me.GunaElipsePanel1.Name = "GunaElipsePanel1"
        Me.GunaElipsePanel1.Size = New System.Drawing.Size(962, 240)
        Me.GunaElipsePanel1.TabIndex = 30
        '
        'GunaShadowPanel1
        '
        Me.GunaShadowPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GunaShadowPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.GunaShadowPanel1.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.GunaShadowPanel1.Controls.Add(Me.Label17)
        Me.GunaShadowPanel1.Controls.Add(Me.Label24)
        Me.GunaShadowPanel1.Controls.Add(Me.PictureBox7)
        Me.GunaShadowPanel1.Controls.Add(Me.Label16)
        Me.GunaShadowPanel1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaShadowPanel1.Location = New System.Drawing.Point(87, 11)
        Me.GunaShadowPanel1.Name = "GunaShadowPanel1"
        Me.GunaShadowPanel1.Radius = 15
        Me.GunaShadowPanel1.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel1.Size = New System.Drawing.Size(407, 205)
        Me.GunaShadowPanel1.TabIndex = 1
        '
        'Label17
        '
        Me.Label17.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(125, 107)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(24, 23)
        Me.Label17.TabIndex = 29
        Me.Label17.Text = "₹"
        '
        'Label24
        '
        Me.Label24.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.White
        Me.Label24.Location = New System.Drawing.Point(144, 107)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(24, 23)
        Me.Label24.TabIndex = 28
        Me.Label24.Text = "0"
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.ElectronicStore.My.Resources.Resources.money
        Me.PictureBox7.Location = New System.Drawing.Point(17, 65)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(100, 102)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox7.TabIndex = 22
        Me.PictureBox7.TabStop = False
        '
        'Label16
        '
        Me.Label16.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(143, 20)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(132, 23)
        Me.Label16.TabIndex = 21
        Me.Label16.Text = "Total Profit"
        '
        'GunaShadowPanel10
        '
        Me.GunaShadowPanel10.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GunaShadowPanel10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.GunaShadowPanel10.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel10.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.GunaShadowPanel10.Controls.Add(Me.Label27)
        Me.GunaShadowPanel10.Controls.Add(Me.Label19)
        Me.GunaShadowPanel10.Controls.Add(Me.Label28)
        Me.GunaShadowPanel10.Controls.Add(Me.Label20)
        Me.GunaShadowPanel10.Controls.Add(Me.Label29)
        Me.GunaShadowPanel10.Controls.Add(Me.PictureBox8)
        Me.GunaShadowPanel10.Controls.Add(Me.Label18)
        Me.GunaShadowPanel10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaShadowPanel10.Location = New System.Drawing.Point(520, 11)
        Me.GunaShadowPanel10.Name = "GunaShadowPanel10"
        Me.GunaShadowPanel10.Radius = 15
        Me.GunaShadowPanel10.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel10.Size = New System.Drawing.Size(416, 205)
        Me.GunaShadowPanel10.TabIndex = 2
        '
        'Label27
        '
        Me.Label27.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.White
        Me.Label27.Location = New System.Drawing.Point(126, 107)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(24, 23)
        Me.Label27.TabIndex = 32
        Me.Label27.Text = "₹"
        '
        'Label19
        '
        Me.Label19.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(-874, 107)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(24, 23)
        Me.Label19.TabIndex = 29
        Me.Label19.Text = "₹"
        '
        'Label28
        '
        Me.Label28.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.White
        Me.Label28.Location = New System.Drawing.Point(145, 107)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(24, 23)
        Me.Label28.TabIndex = 31
        Me.Label28.Text = "0"
        '
        'Label20
        '
        Me.Label20.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(-857, 107)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(136, 23)
        Me.Label20.TabIndex = 28
        Me.Label20.Text = "100000000"
        '
        'Label29
        '
        Me.Label29.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.White
        Me.Label29.Location = New System.Drawing.Point(151, 20)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(130, 23)
        Me.Label29.TabIndex = 30
        Me.Label29.Text = "Total Sales"
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = Global.ElectronicStore.My.Resources.Resources.rupee__2_
        Me.PictureBox8.Location = New System.Drawing.Point(22, 68)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(100, 102)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox8.TabIndex = 24
        Me.PictureBox8.TabStop = False
        '
        'Label18
        '
        Me.Label18.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(-909, 20)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(130, 23)
        Me.Label18.TabIndex = 24
        Me.Label18.Text = "Total Sales"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.White
        Me.Label26.Location = New System.Drawing.Point(317, 316)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(221, 32)
        Me.Label26.TabIndex = 29
        Me.Label26.Text = "Sales Reports"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.White
        Me.Label25.Location = New System.Drawing.Point(308, 29)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(152, 32)
        Me.Label25.TabIndex = 21
        Me.Label25.Text = "Cashflow"
        '
        'GunaShadowPanel12
        '
        Me.GunaShadowPanel12.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaShadowPanel12.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel12.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.GunaShadowPanel12.Location = New System.Drawing.Point(317, 358)
        Me.GunaShadowPanel12.Name = "GunaShadowPanel12"
        Me.GunaShadowPanel12.Radius = 15
        Me.GunaShadowPanel12.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel12.Size = New System.Drawing.Size(952, 427)
        Me.GunaShadowPanel12.TabIndex = 28
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(771, 465)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(21, 13)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Da"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Black
        Me.TabPage2.Controls.Add(Me.Label30)
        Me.TabPage2.Controls.Add(Me.GunaShadowPanel13)
        Me.TabPage2.Controls.Add(Me.GunaShadowPanel14)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1313, 841)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.White
        Me.Label30.Location = New System.Drawing.Point(323, 31)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(101, 32)
        Me.Label30.TabIndex = 24
        Me.Label30.Text = "Debts"
        '
        'GunaShadowPanel13
        '
        Me.GunaShadowPanel13.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaShadowPanel13.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel13.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.GunaShadowPanel13.Location = New System.Drawing.Point(318, 304)
        Me.GunaShadowPanel13.Name = "GunaShadowPanel13"
        Me.GunaShadowPanel13.Radius = 15
        Me.GunaShadowPanel13.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel13.Size = New System.Drawing.Size(947, 490)
        Me.GunaShadowPanel13.TabIndex = 29
        '
        'GunaShadowPanel14
        '
        Me.GunaShadowPanel14.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.GunaShadowPanel14.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel14.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.GunaShadowPanel14.Controls.Add(Me.Label31)
        Me.GunaShadowPanel14.Controls.Add(Me.Label32)
        Me.GunaShadowPanel14.Controls.Add(Me.PictureBox10)
        Me.GunaShadowPanel14.Controls.Add(Me.Label33)
        Me.GunaShadowPanel14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaShadowPanel14.Location = New System.Drawing.Point(321, 75)
        Me.GunaShadowPanel14.Name = "GunaShadowPanel14"
        Me.GunaShadowPanel14.Radius = 15
        Me.GunaShadowPanel14.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel14.Size = New System.Drawing.Size(322, 205)
        Me.GunaShadowPanel14.TabIndex = 22
        '
        'Label31
        '
        Me.Label31.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.White
        Me.Label31.Location = New System.Drawing.Point(130, 107)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(24, 23)
        Me.Label31.TabIndex = 29
        Me.Label31.Text = "₹"
        '
        'Label32
        '
        Me.Label32.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.White
        Me.Label32.Location = New System.Drawing.Point(147, 107)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(136, 23)
        Me.Label32.TabIndex = 28
        Me.Label32.Text = "100000000"
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = Global.ElectronicStore.My.Resources.Resources.debt
        Me.PictureBox10.Location = New System.Drawing.Point(25, 68)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(100, 102)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox10.TabIndex = 22
        Me.PictureBox10.TabStop = False
        '
        'Label33
        '
        Me.Label33.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.White
        Me.Label33.Location = New System.Drawing.Point(21, 20)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(283, 23)
        Me.Label33.TabIndex = 21
        Me.Label33.Text = "Customer Debt Ammount"
        '
        'TabPage3
        '
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1313, 841)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "TabPage3"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.Black
        Me.TabPage4.Controls.Add(Me.GunaShadowPanel16)
        Me.TabPage4.Controls.Add(Me.Label3)
        Me.TabPage4.Controls.Add(Me.GunaShadowPanel15)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1313, 841)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "TabPage4"
        '
        'GunaShadowPanel16
        '
        Me.GunaShadowPanel16.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaShadowPanel16.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.GunaShadowPanel16.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel16.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.GunaShadowPanel16.Controls.Add(Me.Label38)
        Me.GunaShadowPanel16.Controls.Add(Me.Label37)
        Me.GunaShadowPanel16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaShadowPanel16.Location = New System.Drawing.Point(314, 706)
        Me.GunaShadowPanel16.Name = "GunaShadowPanel16"
        Me.GunaShadowPanel16.Radius = 5
        Me.GunaShadowPanel16.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel16.Size = New System.Drawing.Size(947, 89)
        Me.GunaShadowPanel16.TabIndex = 32
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.BackColor = System.Drawing.Color.Transparent
        Me.Label38.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.White
        Me.Label38.Location = New System.Drawing.Point(23, 50)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(911, 16)
        Me.Label38.TabIndex = 23
        Me.Label38.Text = "Optimize stock management by directly adjusting quantities in the 'Stock List' to" &
    " maintain accuracy and prevent duplication."
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.BackColor = System.Drawing.Color.Transparent
        Me.Label37.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Red
        Me.Label37.Location = New System.Drawing.Point(23, 19)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(230, 18)
        Me.Label37.TabIndex = 22
        Me.Label37.Text = "Already Created a Stock?"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(308, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(166, 32)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "Add Stock"
        '
        'GunaShadowPanel15
        '
        Me.GunaShadowPanel15.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaShadowPanel15.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel15.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.GunaShadowPanel15.Controls.Add(Me.Label36)
        Me.GunaShadowPanel15.Controls.Add(Me.Quantity)
        Me.GunaShadowPanel15.Controls.Add(Me.Label35)
        Me.GunaShadowPanel15.Controls.Add(Me.TaxInPer)
        Me.GunaShadowPanel15.Controls.Add(Me.Label4)
        Me.GunaShadowPanel15.Controls.Add(Me.SellingPriceTxt)
        Me.GunaShadowPanel15.Controls.Add(Me.Price)
        Me.GunaShadowPanel15.Controls.Add(Me.CostPriceTXT)
        Me.GunaShadowPanel15.Controls.Add(Me.Label39)
        Me.GunaShadowPanel15.Controls.Add(Me.Stkcode)
        Me.GunaShadowPanel15.Controls.Add(Me.STKcodeTextBox)
        Me.GunaShadowPanel15.Controls.Add(Me.AddStockData)
        Me.GunaShadowPanel15.Controls.Add(Me.ModelNumber)
        Me.GunaShadowPanel15.Controls.Add(Me.ModelNameTextBox)
        Me.GunaShadowPanel15.Controls.Add(Me.Label34)
        Me.GunaShadowPanel15.Controls.Add(Me.ProName)
        Me.GunaShadowPanel15.Controls.Add(Me.ComName)
        Me.GunaShadowPanel15.Controls.Add(Me.CompanyNameText)
        Me.GunaShadowPanel15.Location = New System.Drawing.Point(314, 112)
        Me.GunaShadowPanel15.Name = "GunaShadowPanel15"
        Me.GunaShadowPanel15.Radius = 15
        Me.GunaShadowPanel15.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel15.ShadowStyle = Guna.UI.WinForms.ShadowMode.Dropped
        Me.GunaShadowPanel15.Size = New System.Drawing.Size(947, 572)
        Me.GunaShadowPanel15.TabIndex = 30
        '
        'Label36
        '
        Me.Label36.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label36.AutoSize = True
        Me.Label36.BackColor = System.Drawing.Color.Transparent
        Me.Label36.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.White
        Me.Label36.Location = New System.Drawing.Point(526, 184)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(83, 18)
        Me.Label36.TabIndex = 55
        Me.Label36.Text = "Quantity"
        '
        'Quantity
        '
        Me.Quantity.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Quantity.BackColor = System.Drawing.Color.Transparent
        Me.Quantity.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Quantity.BorderColor = System.Drawing.Color.Black
        Me.Quantity.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Quantity.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Quantity.FocusedBorderColor = System.Drawing.Color.Black
        Me.Quantity.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.Quantity.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Quantity.ForeColor = System.Drawing.Color.White
        Me.Quantity.Location = New System.Drawing.Point(512, 191)
        Me.Quantity.Name = "Quantity"
        Me.Quantity.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Quantity.Radius = 10
        Me.Quantity.SelectedText = ""
        Me.Quantity.Size = New System.Drawing.Size(329, 53)
        Me.Quantity.TabIndex = 54
        '
        'Label35
        '
        Me.Label35.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.White
        Me.Label35.Location = New System.Drawing.Point(526, 373)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(91, 18)
        Me.Label35.TabIndex = 53
        Me.Label35.Text = "Tax In %"
        '
        'TaxInPer
        '
        Me.TaxInPer.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TaxInPer.BackColor = System.Drawing.Color.Transparent
        Me.TaxInPer.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.TaxInPer.BorderColor = System.Drawing.Color.Black
        Me.TaxInPer.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TaxInPer.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.TaxInPer.FocusedBorderColor = System.Drawing.Color.Black
        Me.TaxInPer.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TaxInPer.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TaxInPer.ForeColor = System.Drawing.Color.White
        Me.TaxInPer.Location = New System.Drawing.Point(512, 380)
        Me.TaxInPer.Name = "TaxInPer"
        Me.TaxInPer.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TaxInPer.Radius = 10
        Me.TaxInPer.SelectedText = ""
        Me.TaxInPer.Size = New System.Drawing.Size(329, 53)
        Me.TaxInPer.TabIndex = 52
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(104, 373)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 18)
        Me.Label4.TabIndex = 51
        Me.Label4.Text = "Selling Price"
        '
        'SellingPriceTxt
        '
        Me.SellingPriceTxt.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.SellingPriceTxt.BackColor = System.Drawing.Color.Transparent
        Me.SellingPriceTxt.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.SellingPriceTxt.BorderColor = System.Drawing.Color.Black
        Me.SellingPriceTxt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SellingPriceTxt.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.SellingPriceTxt.FocusedBorderColor = System.Drawing.Color.Black
        Me.SellingPriceTxt.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.SellingPriceTxt.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SellingPriceTxt.ForeColor = System.Drawing.Color.White
        Me.SellingPriceTxt.Location = New System.Drawing.Point(90, 380)
        Me.SellingPriceTxt.Name = "SellingPriceTxt"
        Me.SellingPriceTxt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.SellingPriceTxt.Radius = 10
        Me.SellingPriceTxt.SelectedText = ""
        Me.SellingPriceTxt.Size = New System.Drawing.Size(329, 53)
        Me.SellingPriceTxt.TabIndex = 50
        '
        'Price
        '
        Me.Price.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Price.AutoSize = True
        Me.Price.BackColor = System.Drawing.Color.Transparent
        Me.Price.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Price.ForeColor = System.Drawing.Color.White
        Me.Price.Location = New System.Drawing.Point(526, 277)
        Me.Price.Name = "Price"
        Me.Price.Size = New System.Drawing.Size(96, 18)
        Me.Price.TabIndex = 49
        Me.Price.Text = "Cost Price"
        '
        'CostPriceTXT
        '
        Me.CostPriceTXT.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.CostPriceTXT.BackColor = System.Drawing.Color.Transparent
        Me.CostPriceTXT.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.CostPriceTXT.BorderColor = System.Drawing.Color.Black
        Me.CostPriceTXT.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.CostPriceTXT.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.CostPriceTXT.FocusedBorderColor = System.Drawing.Color.Black
        Me.CostPriceTXT.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.CostPriceTXT.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CostPriceTXT.ForeColor = System.Drawing.Color.White
        Me.CostPriceTXT.Location = New System.Drawing.Point(512, 284)
        Me.CostPriceTXT.Name = "CostPriceTXT"
        Me.CostPriceTXT.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.CostPriceTXT.Radius = 10
        Me.CostPriceTXT.SelectedText = ""
        Me.CostPriceTXT.Size = New System.Drawing.Size(329, 53)
        Me.CostPriceTXT.TabIndex = 48
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.BackColor = System.Drawing.Color.Transparent
        Me.Label39.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.White
        Me.Label39.Location = New System.Drawing.Point(369, 18)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(200, 32)
        Me.Label39.TabIndex = 32
        Me.Label39.Text = "Add Product"
        '
        'Stkcode
        '
        Me.Stkcode.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Stkcode.AutoSize = True
        Me.Stkcode.BackColor = System.Drawing.Color.Transparent
        Me.Stkcode.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Stkcode.ForeColor = System.Drawing.Color.White
        Me.Stkcode.Location = New System.Drawing.Point(102, 274)
        Me.Stkcode.Name = "Stkcode"
        Me.Stkcode.Size = New System.Drawing.Size(93, 18)
        Me.Stkcode.TabIndex = 45
        Me.Stkcode.Text = "STK Code"
        '
        'STKcodeTextBox
        '
        Me.STKcodeTextBox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.STKcodeTextBox.BackColor = System.Drawing.Color.Transparent
        Me.STKcodeTextBox.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.STKcodeTextBox.BorderColor = System.Drawing.Color.Black
        Me.STKcodeTextBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.STKcodeTextBox.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.STKcodeTextBox.FocusedBorderColor = System.Drawing.Color.Black
        Me.STKcodeTextBox.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.STKcodeTextBox.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.STKcodeTextBox.ForeColor = System.Drawing.Color.White
        Me.STKcodeTextBox.Location = New System.Drawing.Point(90, 284)
        Me.STKcodeTextBox.Name = "STKcodeTextBox"
        Me.STKcodeTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.STKcodeTextBox.Radius = 10
        Me.STKcodeTextBox.SelectedText = ""
        Me.STKcodeTextBox.Size = New System.Drawing.Size(329, 53)
        Me.STKcodeTextBox.TabIndex = 44
        '
        'AddStockData
        '
        Me.AddStockData.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.AddStockData.AnimationHoverSpeed = 0.07!
        Me.AddStockData.AnimationSpeed = 0.03!
        Me.AddStockData.BackColor = System.Drawing.Color.Transparent
        Me.AddStockData.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AddStockData.BorderColor = System.Drawing.Color.Black
        Me.AddStockData.CheckedBaseColor = System.Drawing.Color.Gray
        Me.AddStockData.CheckedBorderColor = System.Drawing.Color.Black
        Me.AddStockData.CheckedForeColor = System.Drawing.Color.White
        Me.AddStockData.CheckedImage = CType(resources.GetObject("AddStockData.CheckedImage"), System.Drawing.Image)
        Me.AddStockData.CheckedLineColor = System.Drawing.Color.DimGray
        Me.AddStockData.DialogResult = System.Windows.Forms.DialogResult.None
        Me.AddStockData.FocusedColor = System.Drawing.Color.Empty
        Me.AddStockData.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.AddStockData.ForeColor = System.Drawing.Color.White
        Me.AddStockData.Image = Global.ElectronicStore.My.Resources.Resources.add_to_cart
        Me.AddStockData.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.AddStockData.ImageSize = New System.Drawing.Size(25, 25)
        Me.AddStockData.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.AddStockData.Location = New System.Drawing.Point(90, 475)
        Me.AddStockData.Name = "AddStockData"
        Me.AddStockData.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AddStockData.OnHoverBorderColor = System.Drawing.Color.Black
        Me.AddStockData.OnHoverForeColor = System.Drawing.Color.White
        Me.AddStockData.OnHoverImage = Nothing
        Me.AddStockData.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.AddStockData.OnPressedColor = System.Drawing.Color.Black
        Me.AddStockData.Radius = 10
        Me.AddStockData.Size = New System.Drawing.Size(751, 53)
        Me.AddStockData.TabIndex = 41
        Me.AddStockData.Text = "Add Stock"
        Me.AddStockData.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ModelNumber
        '
        Me.ModelNumber.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ModelNumber.AutoSize = True
        Me.ModelNumber.BackColor = System.Drawing.Color.Transparent
        Me.ModelNumber.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModelNumber.ForeColor = System.Drawing.Color.White
        Me.ModelNumber.Location = New System.Drawing.Point(104, 184)
        Me.ModelNumber.Name = "ModelNumber"
        Me.ModelNumber.Size = New System.Drawing.Size(135, 18)
        Me.ModelNumber.TabIndex = 38
        Me.ModelNumber.Text = "Model Number"
        '
        'ModelNameTextBox
        '
        Me.ModelNameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ModelNameTextBox.BackColor = System.Drawing.Color.Transparent
        Me.ModelNameTextBox.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.ModelNameTextBox.BorderColor = System.Drawing.Color.Black
        Me.ModelNameTextBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ModelNameTextBox.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.ModelNameTextBox.FocusedBorderColor = System.Drawing.Color.Black
        Me.ModelNameTextBox.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.ModelNameTextBox.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModelNameTextBox.ForeColor = System.Drawing.Color.White
        Me.ModelNameTextBox.Location = New System.Drawing.Point(90, 191)
        Me.ModelNameTextBox.Name = "ModelNameTextBox"
        Me.ModelNameTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.ModelNameTextBox.Radius = 10
        Me.ModelNameTextBox.SelectedText = ""
        Me.ModelNameTextBox.Size = New System.Drawing.Size(329, 53)
        Me.ModelNameTextBox.TabIndex = 37
        '
        'Label34
        '
        Me.Label34.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.White
        Me.Label34.Location = New System.Drawing.Point(104, 89)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(133, 18)
        Me.Label34.TabIndex = 34
        Me.Label34.Text = "Product Name"
        '
        'ProName
        '
        Me.ProName.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ProName.BackColor = System.Drawing.Color.Transparent
        Me.ProName.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.ProName.BorderColor = System.Drawing.Color.Black
        Me.ProName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ProName.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.ProName.FocusedBorderColor = System.Drawing.Color.Black
        Me.ProName.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.ProName.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProName.ForeColor = System.Drawing.Color.White
        Me.ProName.Location = New System.Drawing.Point(90, 96)
        Me.ProName.Margin = New System.Windows.Forms.Padding(10)
        Me.ProName.Name = "ProName"
        Me.ProName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.ProName.Radius = 10
        Me.ProName.SelectedText = ""
        Me.ProName.Size = New System.Drawing.Size(329, 53)
        Me.ProName.TabIndex = 33
        '
        'ComName
        '
        Me.ComName.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ComName.AutoSize = True
        Me.ComName.BackColor = System.Drawing.Color.Transparent
        Me.ComName.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComName.ForeColor = System.Drawing.Color.White
        Me.ComName.Location = New System.Drawing.Point(526, 89)
        Me.ComName.Name = "ComName"
        Me.ComName.Size = New System.Drawing.Size(146, 18)
        Me.ComName.TabIndex = 32
        Me.ComName.Text = "Company Name"
        '
        'CompanyNameText
        '
        Me.CompanyNameText.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.CompanyNameText.BackColor = System.Drawing.Color.Transparent
        Me.CompanyNameText.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.CompanyNameText.BorderColor = System.Drawing.Color.Black
        Me.CompanyNameText.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.CompanyNameText.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.CompanyNameText.FocusedBorderColor = System.Drawing.Color.Black
        Me.CompanyNameText.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.CompanyNameText.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CompanyNameText.ForeColor = System.Drawing.Color.White
        Me.CompanyNameText.Location = New System.Drawing.Point(512, 96)
        Me.CompanyNameText.Name = "CompanyNameText"
        Me.CompanyNameText.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.CompanyNameText.Radius = 10
        Me.CompanyNameText.SelectedText = ""
        Me.CompanyNameText.Size = New System.Drawing.Size(329, 53)
        Me.CompanyNameText.TabIndex = 1
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.Black
        Me.TabPage5.Controls.Add(Me.GunaButton1)
        Me.TabPage5.Controls.Add(Me.RefreshBtn)
        Me.TabPage5.Controls.Add(Me.GunaShadowPanel17)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1313, 841)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "TabPage5"
        '
        'GunaButton1
        '
        Me.GunaButton1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaButton1.AnimationHoverSpeed = 0.07!
        Me.GunaButton1.AnimationSpeed = 0.03!
        Me.GunaButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaButton1.ForeColor = System.Drawing.Color.White
        Me.GunaButton1.Image = Nothing
        Me.GunaButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton1.Location = New System.Drawing.Point(1069, 29)
        Me.GunaButton1.Name = "GunaButton1"
        Me.GunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaButton1.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaButton1.OnHoverImage = Nothing
        Me.GunaButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton1.Radius = 10
        Me.GunaButton1.Size = New System.Drawing.Size(160, 42)
        Me.GunaButton1.TabIndex = 33
        Me.GunaButton1.Text = "Update Stock"
        Me.GunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RefreshBtn
        '
        Me.RefreshBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RefreshBtn.AnimationHoverSpeed = 0.07!
        Me.RefreshBtn.AnimationSpeed = 0.03!
        Me.RefreshBtn.BaseColor = System.Drawing.Color.Transparent
        Me.RefreshBtn.BorderColor = System.Drawing.Color.Black
        Me.RefreshBtn.CheckedBaseColor = System.Drawing.Color.Gray
        Me.RefreshBtn.CheckedBorderColor = System.Drawing.Color.Black
        Me.RefreshBtn.CheckedForeColor = System.Drawing.Color.White
        Me.RefreshBtn.CheckedImage = CType(resources.GetObject("RefreshBtn.CheckedImage"), System.Drawing.Image)
        Me.RefreshBtn.CheckedLineColor = System.Drawing.Color.DimGray
        Me.RefreshBtn.DialogResult = System.Windows.Forms.DialogResult.None
        Me.RefreshBtn.FocusedColor = System.Drawing.Color.Empty
        Me.RefreshBtn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.RefreshBtn.ForeColor = System.Drawing.Color.White
        Me.RefreshBtn.Image = Global.ElectronicStore.My.Resources.Resources.reload__1_
        Me.RefreshBtn.ImageSize = New System.Drawing.Size(30, 30)
        Me.RefreshBtn.LineColor = System.Drawing.Color.Transparent
        Me.RefreshBtn.Location = New System.Drawing.Point(1235, 29)
        Me.RefreshBtn.Name = "RefreshBtn"
        Me.RefreshBtn.OnHoverBaseColor = System.Drawing.Color.Transparent
        Me.RefreshBtn.OnHoverBorderColor = System.Drawing.Color.Black
        Me.RefreshBtn.OnHoverForeColor = System.Drawing.Color.White
        Me.RefreshBtn.OnHoverImage = Nothing
        Me.RefreshBtn.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.RefreshBtn.OnPressedColor = System.Drawing.Color.Black
        Me.RefreshBtn.Size = New System.Drawing.Size(47, 42)
        Me.RefreshBtn.TabIndex = 32
        '
        'GunaShadowPanel17
        '
        Me.GunaShadowPanel17.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaShadowPanel17.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel17.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.GunaShadowPanel17.Controls.Add(Me.GunaShadowPanel19)
        Me.GunaShadowPanel17.Controls.Add(Me.DataGridView1)
        Me.GunaShadowPanel17.Location = New System.Drawing.Point(307, 77)
        Me.GunaShadowPanel17.Name = "GunaShadowPanel17"
        Me.GunaShadowPanel17.Radius = 15
        Me.GunaShadowPanel17.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel17.ShadowStyle = Guna.UI.WinForms.ShadowMode.Dropped
        Me.GunaShadowPanel17.Size = New System.Drawing.Size(975, 717)
        Me.GunaShadowPanel17.TabIndex = 31
        '
        'GunaShadowPanel19
        '
        Me.GunaShadowPanel19.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaShadowPanel19.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel19.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.GunaShadowPanel19.Controls.Add(Me.Label49)
        Me.GunaShadowPanel19.Controls.Add(Me.GunaCircleButton1)
        Me.GunaShadowPanel19.Controls.Add(Me.GunaAdvenceButton2)
        Me.GunaShadowPanel19.Controls.Add(Me.Label48)
        Me.GunaShadowPanel19.Controls.Add(Me.GunaTextBox5)
        Me.GunaShadowPanel19.Controls.Add(Me.Label43)
        Me.GunaShadowPanel19.Controls.Add(Me.GunaTextBox1)
        Me.GunaShadowPanel19.Controls.Add(Me.Label44)
        Me.GunaShadowPanel19.Controls.Add(Me.UpadteGstTxt)
        Me.GunaShadowPanel19.Controls.Add(Me.Label45)
        Me.GunaShadowPanel19.Controls.Add(Me.GunaTextBox3)
        Me.GunaShadowPanel19.Controls.Add(Me.Label46)
        Me.GunaShadowPanel19.Controls.Add(Me.GunaTextBox4)
        Me.GunaShadowPanel19.Controls.Add(Me.Label47)
        Me.GunaShadowPanel19.Controls.Add(Me.GunaAdvenceButton1)
        Me.GunaShadowPanel19.Controls.Add(Me.Label50)
        Me.GunaShadowPanel19.Controls.Add(Me.GunaTextBox7)
        Me.GunaShadowPanel19.Controls.Add(Me.Label51)
        Me.GunaShadowPanel19.Controls.Add(Me.GunaTextBox8)
        Me.GunaShadowPanel19.Location = New System.Drawing.Point(62, 91)
        Me.GunaShadowPanel19.Name = "GunaShadowPanel19"
        Me.GunaShadowPanel19.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel19.ShadowStyle = Guna.UI.WinForms.ShadowMode.Dropped
        Me.GunaShadowPanel19.Size = New System.Drawing.Size(878, 524)
        Me.GunaShadowPanel19.TabIndex = 31
        Me.GunaShadowPanel19.Visible = False
        '
        'Label49
        '
        Me.Label49.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.Red
        Me.Label49.Location = New System.Drawing.Point(19, 497)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(207, 14)
        Me.Label49.TabIndex = 60
        Me.Label49.Text = "*STK Code cannot be Modified"
        '
        'GunaCircleButton1
        '
        Me.GunaCircleButton1.AnimationHoverSpeed = 0.07!
        Me.GunaCircleButton1.AnimationSpeed = 0.03!
        Me.GunaCircleButton1.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaCircleButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaCircleButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaCircleButton1.ForeColor = System.Drawing.Color.White
        Me.GunaCircleButton1.Image = Global.ElectronicStore.My.Resources.Resources.closeIcon
        Me.GunaCircleButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaCircleButton1.Location = New System.Drawing.Point(832, 9)
        Me.GunaCircleButton1.Name = "GunaCircleButton1"
        Me.GunaCircleButton1.OnHoverBaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton1.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaCircleButton1.OnHoverImage = Nothing
        Me.GunaCircleButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaCircleButton1.Size = New System.Drawing.Size(32, 32)
        Me.GunaCircleButton1.TabIndex = 59
        '
        'GunaAdvenceButton2
        '
        Me.GunaAdvenceButton2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaAdvenceButton2.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton2.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton2.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton2.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton2.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton2.CheckedImage = CType(resources.GetObject("GunaAdvenceButton2.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton2.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton2.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaAdvenceButton2.ForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton2.Image = Global.ElectronicStore.My.Resources.Resources.add_to_cart
        Me.GunaAdvenceButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton2.ImageSize = New System.Drawing.Size(25, 25)
        Me.GunaAdvenceButton2.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton2.Location = New System.Drawing.Point(544, 98)
        Me.GunaAdvenceButton2.Name = "GunaAdvenceButton2"
        Me.GunaAdvenceButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton2.OnHoverImage = Nothing
        Me.GunaAdvenceButton2.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.Radius = 10
        Me.GunaAdvenceButton2.Size = New System.Drawing.Size(102, 53)
        Me.GunaAdvenceButton2.TabIndex = 58
        Me.GunaAdvenceButton2.Text = "Search"
        Me.GunaAdvenceButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label48
        '
        Me.Label48.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label48.AutoSize = True
        Me.Label48.BackColor = System.Drawing.Color.Transparent
        Me.Label48.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.Color.White
        Me.Label48.Location = New System.Drawing.Point(221, 78)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(93, 18)
        Me.Label48.TabIndex = 57
        Me.Label48.Text = "STK Code"
        '
        'GunaTextBox5
        '
        Me.GunaTextBox5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaTextBox5.BackColor = System.Drawing.Color.Transparent
        Me.GunaTextBox5.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.GunaTextBox5.BorderColor = System.Drawing.Color.Black
        Me.GunaTextBox5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox5.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.GunaTextBox5.FocusedBorderColor = System.Drawing.Color.Black
        Me.GunaTextBox5.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox5.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaTextBox5.ForeColor = System.Drawing.Color.White
        Me.GunaTextBox5.Location = New System.Drawing.Point(209, 98)
        Me.GunaTextBox5.Name = "GunaTextBox5"
        Me.GunaTextBox5.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox5.Radius = 10
        Me.GunaTextBox5.SelectedText = ""
        Me.GunaTextBox5.Size = New System.Drawing.Size(329, 53)
        Me.GunaTextBox5.TabIndex = 56
        '
        'Label43
        '
        Me.Label43.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label43.AutoSize = True
        Me.Label43.BackColor = System.Drawing.Color.Transparent
        Me.Label43.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.White
        Me.Label43.Location = New System.Drawing.Point(76, 269)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(83, 18)
        Me.Label43.TabIndex = 55
        Me.Label43.Text = "Quantity"
        '
        'GunaTextBox1
        '
        Me.GunaTextBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaTextBox1.BackColor = System.Drawing.Color.Transparent
        Me.GunaTextBox1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.GunaTextBox1.BorderColor = System.Drawing.Color.Black
        Me.GunaTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox1.Enabled = False
        Me.GunaTextBox1.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.GunaTextBox1.FocusedBorderColor = System.Drawing.Color.Black
        Me.GunaTextBox1.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox1.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaTextBox1.ForeColor = System.Drawing.Color.White
        Me.GunaTextBox1.Location = New System.Drawing.Point(62, 276)
        Me.GunaTextBox1.Name = "GunaTextBox1"
        Me.GunaTextBox1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox1.Radius = 10
        Me.GunaTextBox1.SelectedText = ""
        Me.GunaTextBox1.Size = New System.Drawing.Size(329, 53)
        Me.GunaTextBox1.TabIndex = 54
        '
        'Label44
        '
        Me.Label44.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label44.AutoSize = True
        Me.Label44.BackColor = System.Drawing.Color.Transparent
        Me.Label44.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.White
        Me.Label44.Location = New System.Drawing.Point(498, 355)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(91, 18)
        Me.Label44.TabIndex = 53
        Me.Label44.Text = "Tax In %"
        '
        'UpadteGstTxt
        '
        Me.UpadteGstTxt.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.UpadteGstTxt.BackColor = System.Drawing.Color.Transparent
        Me.UpadteGstTxt.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.UpadteGstTxt.BorderColor = System.Drawing.Color.Black
        Me.UpadteGstTxt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.UpadteGstTxt.Enabled = False
        Me.UpadteGstTxt.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.UpadteGstTxt.FocusedBorderColor = System.Drawing.Color.Black
        Me.UpadteGstTxt.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.UpadteGstTxt.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpadteGstTxt.ForeColor = System.Drawing.Color.White
        Me.UpadteGstTxt.Location = New System.Drawing.Point(484, 362)
        Me.UpadteGstTxt.Name = "UpadteGstTxt"
        Me.UpadteGstTxt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.UpadteGstTxt.Radius = 10
        Me.UpadteGstTxt.SelectedText = ""
        Me.UpadteGstTxt.Size = New System.Drawing.Size(329, 53)
        Me.UpadteGstTxt.TabIndex = 52
        '
        'Label45
        '
        Me.Label45.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label45.AutoSize = True
        Me.Label45.BackColor = System.Drawing.Color.Transparent
        Me.Label45.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.White
        Me.Label45.Location = New System.Drawing.Point(76, 355)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(113, 18)
        Me.Label45.TabIndex = 51
        Me.Label45.Text = "Selling Price"
        '
        'GunaTextBox3
        '
        Me.GunaTextBox3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaTextBox3.BackColor = System.Drawing.Color.Transparent
        Me.GunaTextBox3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.GunaTextBox3.BorderColor = System.Drawing.Color.Black
        Me.GunaTextBox3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox3.Enabled = False
        Me.GunaTextBox3.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.GunaTextBox3.FocusedBorderColor = System.Drawing.Color.Black
        Me.GunaTextBox3.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox3.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaTextBox3.ForeColor = System.Drawing.Color.White
        Me.GunaTextBox3.Location = New System.Drawing.Point(62, 362)
        Me.GunaTextBox3.Name = "GunaTextBox3"
        Me.GunaTextBox3.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox3.Radius = 10
        Me.GunaTextBox3.SelectedText = ""
        Me.GunaTextBox3.Size = New System.Drawing.Size(329, 53)
        Me.GunaTextBox3.TabIndex = 50
        '
        'Label46
        '
        Me.Label46.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label46.AutoSize = True
        Me.Label46.BackColor = System.Drawing.Color.Transparent
        Me.Label46.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ForeColor = System.Drawing.Color.White
        Me.Label46.Location = New System.Drawing.Point(498, 276)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(96, 18)
        Me.Label46.TabIndex = 49
        Me.Label46.Text = "Cost Price"
        '
        'GunaTextBox4
        '
        Me.GunaTextBox4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaTextBox4.BackColor = System.Drawing.Color.Transparent
        Me.GunaTextBox4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.GunaTextBox4.BorderColor = System.Drawing.Color.Black
        Me.GunaTextBox4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox4.Enabled = False
        Me.GunaTextBox4.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.GunaTextBox4.FocusedBorderColor = System.Drawing.Color.Black
        Me.GunaTextBox4.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox4.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaTextBox4.ForeColor = System.Drawing.Color.White
        Me.GunaTextBox4.Location = New System.Drawing.Point(484, 283)
        Me.GunaTextBox4.Name = "GunaTextBox4"
        Me.GunaTextBox4.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox4.Radius = 10
        Me.GunaTextBox4.SelectedText = ""
        Me.GunaTextBox4.Size = New System.Drawing.Size(329, 53)
        Me.GunaTextBox4.TabIndex = 48
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.BackColor = System.Drawing.Color.Transparent
        Me.Label47.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.White
        Me.Label47.Location = New System.Drawing.Point(339, 17)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(199, 32)
        Me.Label47.TabIndex = 32
        Me.Label47.Text = "Edit Product"
        '
        'GunaAdvenceButton1
        '
        Me.GunaAdvenceButton1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaAdvenceButton1.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton1.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton1.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.CheckedImage = CType(resources.GetObject("GunaAdvenceButton1.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton1.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton1.Enabled = False
        Me.GunaAdvenceButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaAdvenceButton1.ForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.Image = Nothing
        Me.GunaAdvenceButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton1.ImageSize = New System.Drawing.Size(25, 25)
        Me.GunaAdvenceButton1.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton1.Location = New System.Drawing.Point(278, 447)
        Me.GunaAdvenceButton1.Name = "GunaAdvenceButton1"
        Me.GunaAdvenceButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.OnHoverImage = Nothing
        Me.GunaAdvenceButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.Radius = 10
        Me.GunaAdvenceButton1.Size = New System.Drawing.Size(297, 53)
        Me.GunaAdvenceButton1.TabIndex = 41
        Me.GunaAdvenceButton1.Text = "Update Stock"
        Me.GunaAdvenceButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label50
        '
        Me.Label50.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label50.AutoSize = True
        Me.Label50.BackColor = System.Drawing.Color.Transparent
        Me.Label50.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.White
        Me.Label50.Location = New System.Drawing.Point(76, 196)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(133, 18)
        Me.Label50.TabIndex = 34
        Me.Label50.Text = "Product Name"
        '
        'GunaTextBox7
        '
        Me.GunaTextBox7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaTextBox7.BackColor = System.Drawing.Color.Transparent
        Me.GunaTextBox7.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.GunaTextBox7.BorderColor = System.Drawing.Color.Black
        Me.GunaTextBox7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox7.Enabled = False
        Me.GunaTextBox7.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.GunaTextBox7.FocusedBorderColor = System.Drawing.Color.Black
        Me.GunaTextBox7.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox7.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaTextBox7.ForeColor = System.Drawing.Color.White
        Me.GunaTextBox7.Location = New System.Drawing.Point(62, 203)
        Me.GunaTextBox7.Margin = New System.Windows.Forms.Padding(10)
        Me.GunaTextBox7.Name = "GunaTextBox7"
        Me.GunaTextBox7.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox7.Radius = 10
        Me.GunaTextBox7.SelectedText = ""
        Me.GunaTextBox7.Size = New System.Drawing.Size(329, 53)
        Me.GunaTextBox7.TabIndex = 33
        '
        'Label51
        '
        Me.Label51.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label51.AutoSize = True
        Me.Label51.BackColor = System.Drawing.Color.Transparent
        Me.Label51.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.White
        Me.Label51.Location = New System.Drawing.Point(498, 196)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(146, 18)
        Me.Label51.TabIndex = 32
        Me.Label51.Text = "Company Name"
        '
        'GunaTextBox8
        '
        Me.GunaTextBox8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaTextBox8.BackColor = System.Drawing.Color.Transparent
        Me.GunaTextBox8.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.GunaTextBox8.BorderColor = System.Drawing.Color.Black
        Me.GunaTextBox8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox8.Enabled = False
        Me.GunaTextBox8.FocusedBaseColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.GunaTextBox8.FocusedBorderColor = System.Drawing.Color.Black
        Me.GunaTextBox8.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox8.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaTextBox8.ForeColor = System.Drawing.Color.White
        Me.GunaTextBox8.Location = New System.Drawing.Point(484, 203)
        Me.GunaTextBox8.Name = "GunaTextBox8"
        Me.GunaTextBox8.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox8.Radius = 10
        Me.GunaTextBox8.SelectedText = ""
        Me.GunaTextBox8.Size = New System.Drawing.Size(329, 53)
        Me.GunaTextBox8.TabIndex = 1
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(239, Byte), Integer), CType(CType(212, Byte), Integer))
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.DataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(113, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.ColumnHeadersHeight = 40
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7, Me.Column8})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(244, Byte), Integer), CType(CType(226, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(115, Byte), Integer), CType(CType(221, Byte), Integer), CType(CType(160, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.EnableHeadersVisualStyles = False
        Me.DataGridView1.GridColor = System.Drawing.Color.FromArgb(CType(CType(187, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.DataGridView1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView1.ShowEditingIcon = False
        Me.DataGridView1.Size = New System.Drawing.Size(975, 717)
        Me.DataGridView1.TabIndex = 0
        Me.DataGridView1.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Emerald
        Me.DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(239, Byte), Integer), CType(CType(212, Byte), Integer))
        Me.DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(187, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(113, Byte), Integer))
        Me.DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DataGridView1.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        Me.DataGridView1.ThemeStyle.HeaderStyle.Height = 40
        Me.DataGridView1.ThemeStyle.ReadOnly = True
        Me.DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(244, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.DataGridView1.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.DataGridView1.ThemeStyle.RowsStyle.Height = 22
        Me.DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(115, Byte), Integer), CType(CType(221, Byte), Integer), CType(CType(160, Byte), Integer))
        Me.DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        '
        'Column1
        '
        Me.Column1.FillWeight = 40.60914!
        Me.Column1.HeaderText = "Sr No"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.FillWeight = 108.4844!
        Me.Column2.HeaderText = "Stock Code"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.FillWeight = 108.4844!
        Me.Column3.HeaderText = "Product Name"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        '
        'Column4
        '
        Me.Column4.FillWeight = 108.4844!
        Me.Column4.HeaderText = "Company "
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'Column5
        '
        Me.Column5.FillWeight = 108.4844!
        Me.Column5.HeaderText = " Cost Price "
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        '
        'Column6
        '
        Me.Column6.FillWeight = 108.4844!
        Me.Column6.HeaderText = "Selling Price "
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.FillWeight = 108.4844!
        Me.Column7.HeaderText = "Tax In Percentage"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        '
        'Column8
        '
        Me.Column8.FillWeight = 108.4844!
        Me.Column8.HeaderText = "Avaliable Quantity"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.Black
        Me.TabPage6.Controls.Add(Me.GunaShadowPanel18)
        Me.TabPage6.Controls.Add(Me.GunaShadowPanel11)
        Me.TabPage6.Controls.Add(Me.Label6)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1313, 841)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "TabPage6"
        '
        'GunaShadowPanel18
        '
        Me.GunaShadowPanel18.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaShadowPanel18.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.GunaShadowPanel18.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel18.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.GunaShadowPanel18.Controls.Add(Me.Label41)
        Me.GunaShadowPanel18.Controls.Add(Me.Label42)
        Me.GunaShadowPanel18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaShadowPanel18.Location = New System.Drawing.Point(304, 726)
        Me.GunaShadowPanel18.Name = "GunaShadowPanel18"
        Me.GunaShadowPanel18.Radius = 5
        Me.GunaShadowPanel18.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel18.Size = New System.Drawing.Size(947, 89)
        Me.GunaShadowPanel18.TabIndex = 33
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.BackColor = System.Drawing.Color.Transparent
        Me.Label41.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.White
        Me.Label41.Location = New System.Drawing.Point(23, 58)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(882, 16)
        Me.Label41.TabIndex = 23
        Me.Label41.Text = "This Software is developed as Gad Microproject by grup 9.Not a Professional Built" &
    " not recommended for commercial uses"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.BackColor = System.Drawing.Color.Transparent
        Me.Label42.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Red
        Me.Label42.Location = New System.Drawing.Point(23, 19)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(171, 18)
        Me.Label42.TabIndex = 22
        Me.Label42.Text = "Importance Notice"
        '
        'GunaShadowPanel11
        '
        Me.GunaShadowPanel11.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaShadowPanel11.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel11.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.GunaShadowPanel11.Controls.Add(Me.Label23)
        Me.GunaShadowPanel11.Controls.Add(Me.Label22)
        Me.GunaShadowPanel11.Controls.Add(Me.Label21)
        Me.GunaShadowPanel11.Controls.Add(Me.Label5)
        Me.GunaShadowPanel11.Controls.Add(Me.GunaCirclePictureBox1)
        Me.GunaShadowPanel11.Controls.Add(Me.Label40)
        Me.GunaShadowPanel11.Location = New System.Drawing.Point(308, 99)
        Me.GunaShadowPanel11.Name = "GunaShadowPanel11"
        Me.GunaShadowPanel11.Radius = 15
        Me.GunaShadowPanel11.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel11.ShadowStyle = Guna.UI.WinForms.ShadowMode.Dropped
        Me.GunaShadowPanel11.Size = New System.Drawing.Size(947, 572)
        Me.GunaShadowPanel11.TabIndex = 31
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(464, 372)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(337, 25)
        Me.Label23.TabIndex = 54
        Me.Label23.Text = "Last Updated: 17-Mar-2024"
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(464, 302)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(274, 25)
        Me.Label22.TabIndex = 53
        Me.Label22.Text = "Product Version: 1.1.2"
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(464, 236)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(425, 25)
        Me.Label21.TabIndex = 52
        Me.Label21.Text = "Developed By: Members of Group 9"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(464, 171)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(418, 25)
        Me.Label5.TabIndex = 51
        Me.Label5.Text = "Software Name: MereDukan[Beta]"
        '
        'GunaCirclePictureBox1
        '
        Me.GunaCirclePictureBox1.BaseColor = System.Drawing.Color.White
        Me.GunaCirclePictureBox1.Image = Global.ElectronicStore.My.Resources.Resources.version
        Me.GunaCirclePictureBox1.Location = New System.Drawing.Point(60, 146)
        Me.GunaCirclePictureBox1.Name = "GunaCirclePictureBox1"
        Me.GunaCirclePictureBox1.Size = New System.Drawing.Size(345, 305)
        Me.GunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.GunaCirclePictureBox1.TabIndex = 50
        Me.GunaCirclePictureBox1.TabStop = False
        Me.GunaCirclePictureBox1.UseTransfarantBackground = False
        '
        'Label40
        '
        Me.Label40.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label40.AutoSize = True
        Me.Label40.BackColor = System.Drawing.Color.Transparent
        Me.Label40.Font = New System.Drawing.Font("Verdana", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.White
        Me.Label40.Location = New System.Drawing.Point(330, 19)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(344, 45)
        Me.Label40.TabIndex = 32
        Me.Label40.Text = "About Software"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(514, 400)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Contact Us Page"
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.Black
        Me.TabPage7.Controls.Add(Me.Panel2)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(1313, 841)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "TabPage7"
        '
        'Panel2
        '
        Me.Panel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BaseColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.GunaShadowPanel6)
        Me.Panel2.Controls.Add(Me.GunaShadowPanel4)
        Me.Panel2.Controls.Add(Me.GunaShadowPanel7)
        Me.Panel2.Controls.Add(Me.GunaShadowPanel3)
        Me.Panel2.Controls.Add(Me.GunaShadowPanel8)
        Me.Panel2.Controls.Add(Me.GunaShadowPanel5)
        Me.Panel2.Controls.Add(Me.GunaShadowPanel9)
        Me.Panel2.Controls.Add(Me.GunaShadowPanel2)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Location = New System.Drawing.Point(342, 92)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Radius = 15
        Me.Panel2.ShadowColor = System.Drawing.Color.Black
        Me.Panel2.ShadowDepth = 50
        Me.Panel2.ShadowShift = 15
        Me.Panel2.Size = New System.Drawing.Size(919, 616)
        Me.Panel2.TabIndex = 0
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(500, 111)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 16)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Surname"
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(494, 395)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(112, 16)
        Me.Label14.TabIndex = 16
        Me.Label14.Text = "Billing Address"
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(85, 394)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(177, 16)
        Me.Label11.TabIndex = 15
        Me.Label11.Text = "Registered GST Number"
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(500, 307)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(117, 16)
        Me.Label12.TabIndex = 14
        Me.Label12.Text = "Contact Number"
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(85, 306)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(65, 16)
        Me.Label13.TabIndex = 13
        Me.Label13.Text = "Address"
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(500, 208)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(43, 16)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "State"
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(85, 208)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(89, 16)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "Store Name"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(79, 113)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 16)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Name"
        '
        'GunaShadowPanel6
        '
        Me.GunaShadowPanel6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaShadowPanel6.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel6.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel6.Controls.Add(Me.billingaddress)
        Me.GunaShadowPanel6.Location = New System.Drawing.Point(488, 404)
        Me.GunaShadowPanel6.Name = "GunaShadowPanel6"
        Me.GunaShadowPanel6.Radius = 3
        Me.GunaShadowPanel6.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel6.ShadowDepth = 50
        Me.GunaShadowPanel6.ShadowShift = 3
        Me.GunaShadowPanel6.Size = New System.Drawing.Size(377, 50)
        Me.GunaShadowPanel6.TabIndex = 8
        '
        'billingaddress
        '
        Me.billingaddress.AutoSize = True
        Me.billingaddress.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.billingaddress.Location = New System.Drawing.Point(16, 17)
        Me.billingaddress.Name = "billingaddress"
        Me.billingaddress.Size = New System.Drawing.Size(101, 19)
        Me.billingaddress.TabIndex = 1
        Me.billingaddress.Text = "billingaddress"
        '
        'GunaShadowPanel4
        '
        Me.GunaShadowPanel4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaShadowPanel4.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel4.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel4.Controls.Add(Me.state)
        Me.GunaShadowPanel4.Location = New System.Drawing.Point(488, 216)
        Me.GunaShadowPanel4.Name = "GunaShadowPanel4"
        Me.GunaShadowPanel4.Radius = 3
        Me.GunaShadowPanel4.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel4.ShadowDepth = 50
        Me.GunaShadowPanel4.ShadowShift = 3
        Me.GunaShadowPanel4.Size = New System.Drawing.Size(377, 50)
        Me.GunaShadowPanel4.TabIndex = 4
        '
        'state
        '
        Me.state.AutoSize = True
        Me.state.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.state.Location = New System.Drawing.Point(16, 17)
        Me.state.Name = "state"
        Me.state.Size = New System.Drawing.Size(44, 19)
        Me.state.TabIndex = 1
        Me.state.Text = "State"
        '
        'GunaShadowPanel7
        '
        Me.GunaShadowPanel7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaShadowPanel7.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel7.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel7.Controls.Add(Me.Label52)
        Me.GunaShadowPanel7.Controls.Add(Me.contact)
        Me.GunaShadowPanel7.Location = New System.Drawing.Point(488, 314)
        Me.GunaShadowPanel7.Name = "GunaShadowPanel7"
        Me.GunaShadowPanel7.Radius = 3
        Me.GunaShadowPanel7.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel7.ShadowDepth = 50
        Me.GunaShadowPanel7.ShadowShift = 3
        Me.GunaShadowPanel7.Size = New System.Drawing.Size(377, 50)
        Me.GunaShadowPanel7.TabIndex = 6
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(17, 17)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(38, 19)
        Me.Label52.TabIndex = 2
        Me.Label52.Text = "+91 "
        '
        'contact
        '
        Me.contact.AutoSize = True
        Me.contact.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.contact.Location = New System.Drawing.Point(52, 17)
        Me.contact.Name = "contact"
        Me.contact.Size = New System.Drawing.Size(0, 19)
        Me.contact.TabIndex = 1
        '
        'GunaShadowPanel3
        '
        Me.GunaShadowPanel3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaShadowPanel3.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel3.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel3.Controls.Add(Me.surname)
        Me.GunaShadowPanel3.Location = New System.Drawing.Point(488, 119)
        Me.GunaShadowPanel3.Name = "GunaShadowPanel3"
        Me.GunaShadowPanel3.Radius = 3
        Me.GunaShadowPanel3.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel3.ShadowDepth = 50
        Me.GunaShadowPanel3.ShadowShift = 3
        Me.GunaShadowPanel3.Size = New System.Drawing.Size(377, 50)
        Me.GunaShadowPanel3.TabIndex = 2
        '
        'surname
        '
        Me.surname.AutoSize = True
        Me.surname.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.surname.Location = New System.Drawing.Point(16, 17)
        Me.surname.Name = "surname"
        Me.surname.Size = New System.Drawing.Size(68, 19)
        Me.surname.TabIndex = 1
        Me.surname.Text = "Surname"
        '
        'GunaShadowPanel8
        '
        Me.GunaShadowPanel8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaShadowPanel8.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel8.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel8.Controls.Add(Me.gstno)
        Me.GunaShadowPanel8.Location = New System.Drawing.Point(71, 404)
        Me.GunaShadowPanel8.Name = "GunaShadowPanel8"
        Me.GunaShadowPanel8.Radius = 3
        Me.GunaShadowPanel8.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel8.ShadowDepth = 50
        Me.GunaShadowPanel8.ShadowShift = 3
        Me.GunaShadowPanel8.Size = New System.Drawing.Size(351, 50)
        Me.GunaShadowPanel8.TabIndex = 7
        '
        'gstno
        '
        Me.gstno.AutoSize = True
        Me.gstno.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gstno.Location = New System.Drawing.Point(20, 17)
        Me.gstno.Name = "gstno"
        Me.gstno.Size = New System.Drawing.Size(94, 19)
        Me.gstno.TabIndex = 0
        Me.gstno.Text = "GST number"
        '
        'GunaShadowPanel5
        '
        Me.GunaShadowPanel5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaShadowPanel5.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel5.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel5.Controls.Add(Me.store)
        Me.GunaShadowPanel5.Location = New System.Drawing.Point(71, 216)
        Me.GunaShadowPanel5.Name = "GunaShadowPanel5"
        Me.GunaShadowPanel5.Radius = 3
        Me.GunaShadowPanel5.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel5.ShadowDepth = 50
        Me.GunaShadowPanel5.ShadowShift = 3
        Me.GunaShadowPanel5.Size = New System.Drawing.Size(351, 50)
        Me.GunaShadowPanel5.TabIndex = 3
        '
        'store
        '
        Me.store.AutoSize = True
        Me.store.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.store.Location = New System.Drawing.Point(20, 17)
        Me.store.Name = "store"
        Me.store.Size = New System.Drawing.Size(85, 19)
        Me.store.TabIndex = 0
        Me.store.Text = "StoreName"
        '
        'GunaShadowPanel9
        '
        Me.GunaShadowPanel9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaShadowPanel9.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel9.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel9.Controls.Add(Me.address)
        Me.GunaShadowPanel9.Location = New System.Drawing.Point(71, 314)
        Me.GunaShadowPanel9.Name = "GunaShadowPanel9"
        Me.GunaShadowPanel9.Radius = 3
        Me.GunaShadowPanel9.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel9.ShadowDepth = 50
        Me.GunaShadowPanel9.ShadowShift = 3
        Me.GunaShadowPanel9.Size = New System.Drawing.Size(351, 50)
        Me.GunaShadowPanel9.TabIndex = 5
        '
        'address
        '
        Me.address.AutoSize = True
        Me.address.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.address.Location = New System.Drawing.Point(20, 17)
        Me.address.Name = "address"
        Me.address.Size = New System.Drawing.Size(64, 19)
        Me.address.TabIndex = 0
        Me.address.Text = "Address"
        '
        'GunaShadowPanel2
        '
        Me.GunaShadowPanel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaShadowPanel2.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel2.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel2.Controls.Add(Me.username)
        Me.GunaShadowPanel2.Location = New System.Drawing.Point(71, 120)
        Me.GunaShadowPanel2.Name = "GunaShadowPanel2"
        Me.GunaShadowPanel2.Radius = 3
        Me.GunaShadowPanel2.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel2.ShadowDepth = 50
        Me.GunaShadowPanel2.ShadowShift = 3
        Me.GunaShadowPanel2.Size = New System.Drawing.Size(351, 50)
        Me.GunaShadowPanel2.TabIndex = 1
        '
        'username
        '
        Me.username.AutoSize = True
        Me.username.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.username.Location = New System.Drawing.Point(20, 17)
        Me.username.Name = "username"
        Me.username.Size = New System.Drawing.Size(81, 19)
        Me.username.TabIndex = 0
        Me.username.Text = "UserName"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei UI", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(363, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(185, 42)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "My Profile"
        '
        'Label8
        '
        Me.Label8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(60, 119)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 23)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Hey!"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Panel1.Controls.Add(Me.ImageButton2)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.PictureBox6)
        Me.Panel1.Controls.Add(Me.PictureBox5)
        Me.Panel1.Controls.Add(Me.PictureBox4)
        Me.Panel1.Controls.Add(Me.PictureBox3)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.ManageBtn)
        Me.Panel1.Controls.Add(Me.LogoutBtn)
        Me.Panel1.Controls.Add(Me.GunaLabel1)
        Me.Panel1.Controls.Add(Me.StkListBtn)
        Me.Panel1.Controls.Add(Me.TaxBtn)
        Me.Panel1.Controls.Add(Me.AboutBtn)
        Me.Panel1.Controls.Add(Me.DebtBtn)
        Me.Panel1.Controls.Add(Me.DashboardBtn)
        Me.Panel1.Location = New System.Drawing.Point(6, 8)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Radius = 18
        Me.Panel1.Size = New System.Drawing.Size(274, 797)
        Me.Panel1.TabIndex = 3
        '
        'ImageButton2
        '
        Me.ImageButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ImageButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ImageButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.ImageButton2.Image = Global.ElectronicStore.My.Resources.Resources.profile
        Me.ImageButton2.ImageSize = New System.Drawing.Size(64, 64)
        Me.ImageButton2.Location = New System.Drawing.Point(90, 34)
        Me.ImageButton2.Margin = New System.Windows.Forms.Padding(0)
        Me.ImageButton2.Name = "ImageButton2"
        Me.ImageButton2.OnHoverImage = Nothing
        Me.ImageButton2.OnHoverImageOffset = New System.Drawing.Point(0, 0)
        Me.ImageButton2.Size = New System.Drawing.Size(80, 80)
        Me.ImageButton2.TabIndex = 20
        '
        'PictureBox6
        '
        Me.PictureBox6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.PictureBox6.BackColor = System.Drawing.Color.Lime
        Me.PictureBox6.Location = New System.Drawing.Point(3, 439)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(10, 53)
        Me.PictureBox6.TabIndex = 19
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.PictureBox5.BackColor = System.Drawing.Color.Lime
        Me.PictureBox5.Location = New System.Drawing.Point(3, 325)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(10, 53)
        Me.PictureBox5.TabIndex = 18
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.PictureBox4.BackColor = System.Drawing.Color.Lime
        Me.PictureBox4.Location = New System.Drawing.Point(3, 267)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(10, 53)
        Me.PictureBox4.TabIndex = 17
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.PictureBox3.BackColor = System.Drawing.Color.Lime
        Me.PictureBox3.Location = New System.Drawing.Point(3, 496)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(10, 53)
        Me.PictureBox3.TabIndex = 16
        Me.PictureBox3.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.PictureBox1.BackColor = System.Drawing.Color.Lime
        Me.PictureBox1.Location = New System.Drawing.Point(3, 206)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(10, 53)
        Me.PictureBox1.TabIndex = 15
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.PictureBox2.BackColor = System.Drawing.Color.Lime
        Me.PictureBox2.Location = New System.Drawing.Point(3, 384)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(10, 53)
        Me.PictureBox2.TabIndex = 14
        Me.PictureBox2.TabStop = False
        '
        'ManageBtn
        '
        Me.ManageBtn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ManageBtn.AnimationHoverSpeed = 0.07!
        Me.ManageBtn.AnimationSpeed = 0.03!
        Me.ManageBtn.BackColor = System.Drawing.Color.Transparent
        Me.ManageBtn.BaseColor = System.Drawing.Color.Transparent
        Me.ManageBtn.BorderColor = System.Drawing.Color.Black
        Me.ManageBtn.CheckedBaseColor = System.Drawing.Color.Gray
        Me.ManageBtn.CheckedBorderColor = System.Drawing.Color.Black
        Me.ManageBtn.CheckedForeColor = System.Drawing.Color.White
        Me.ManageBtn.CheckedImage = CType(resources.GetObject("ManageBtn.CheckedImage"), System.Drawing.Image)
        Me.ManageBtn.CheckedLineColor = System.Drawing.Color.DimGray
        Me.ManageBtn.DialogResult = System.Windows.Forms.DialogResult.None
        Me.ManageBtn.FocusedColor = System.Drawing.Color.Empty
        Me.ManageBtn.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ManageBtn.ForeColor = System.Drawing.Color.White
        Me.ManageBtn.Image = Global.ElectronicStore.My.Resources.Resources.add__1_
        Me.ManageBtn.ImageOffsetX = 55
        Me.ManageBtn.ImageSize = New System.Drawing.Size(30, 30)
        Me.ManageBtn.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.ManageBtn.Location = New System.Drawing.Point(3, 267)
        Me.ManageBtn.Name = "ManageBtn"
        Me.ManageBtn.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ManageBtn.OnHoverBorderColor = System.Drawing.Color.Transparent
        Me.ManageBtn.OnHoverForeColor = System.Drawing.Color.White
        Me.ManageBtn.OnHoverImage = Nothing
        Me.ManageBtn.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.ManageBtn.OnPressedColor = System.Drawing.Color.Transparent
        Me.ManageBtn.Radius = 15
        Me.ManageBtn.Size = New System.Drawing.Size(265, 53)
        Me.ManageBtn.TabIndex = 8
        Me.ManageBtn.Text = "Add Stock"
        Me.ManageBtn.TextOffsetX = 5
        '
        'LogoutBtn
        '
        Me.LogoutBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LogoutBtn.AnimationHoverSpeed = 0.07!
        Me.LogoutBtn.AnimationSpeed = 0.03!
        Me.LogoutBtn.BackColor = System.Drawing.Color.Transparent
        Me.LogoutBtn.BaseColor = System.Drawing.Color.Transparent
        Me.LogoutBtn.BorderColor = System.Drawing.Color.Black
        Me.LogoutBtn.CheckedBaseColor = System.Drawing.Color.Gray
        Me.LogoutBtn.CheckedBorderColor = System.Drawing.Color.Black
        Me.LogoutBtn.CheckedForeColor = System.Drawing.Color.White
        Me.LogoutBtn.CheckedImage = CType(resources.GetObject("LogoutBtn.CheckedImage"), System.Drawing.Image)
        Me.LogoutBtn.CheckedLineColor = System.Drawing.Color.DimGray
        Me.LogoutBtn.DialogResult = System.Windows.Forms.DialogResult.None
        Me.LogoutBtn.FocusedColor = System.Drawing.Color.Empty
        Me.LogoutBtn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutBtn.ForeColor = System.Drawing.Color.White
        Me.LogoutBtn.Image = CType(resources.GetObject("LogoutBtn.Image"), System.Drawing.Image)
        Me.LogoutBtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.LogoutBtn.ImageSize = New System.Drawing.Size(35, 35)
        Me.LogoutBtn.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.LogoutBtn.Location = New System.Drawing.Point(6, 720)
        Me.LogoutBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.LogoutBtn.Name = "LogoutBtn"
        Me.LogoutBtn.OnHoverBaseColor = System.Drawing.Color.Red
        Me.LogoutBtn.OnHoverBorderColor = System.Drawing.Color.Transparent
        Me.LogoutBtn.OnHoverForeColor = System.Drawing.Color.White
        Me.LogoutBtn.OnHoverImage = Nothing
        Me.LogoutBtn.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.LogoutBtn.OnPressedColor = System.Drawing.Color.Transparent
        Me.LogoutBtn.Radius = 15
        Me.LogoutBtn.Size = New System.Drawing.Size(265, 53)
        Me.LogoutBtn.TabIndex = 7
        Me.LogoutBtn.Text = "Logout"
        Me.LogoutBtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaLabel1
        '
        Me.GunaLabel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaLabel1.AutoSize = True
        Me.GunaLabel1.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel1.ForeColor = System.Drawing.Color.White
        Me.GunaLabel1.Location = New System.Drawing.Point(51, 168)
        Me.GunaLabel1.Name = "GunaLabel1"
        Me.GunaLabel1.Size = New System.Drawing.Size(157, 25)
        Me.GunaLabel1.TabIndex = 5
        Me.GunaLabel1.Text = "Manage Store"
        '
        'StkListBtn
        '
        Me.StkListBtn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.StkListBtn.AnimationHoverSpeed = 0.07!
        Me.StkListBtn.AnimationSpeed = 0.03!
        Me.StkListBtn.BackColor = System.Drawing.Color.Transparent
        Me.StkListBtn.BaseColor = System.Drawing.Color.Transparent
        Me.StkListBtn.BorderColor = System.Drawing.Color.Black
        Me.StkListBtn.CheckedBaseColor = System.Drawing.Color.Gray
        Me.StkListBtn.CheckedBorderColor = System.Drawing.Color.Black
        Me.StkListBtn.CheckedForeColor = System.Drawing.Color.White
        Me.StkListBtn.CheckedImage = CType(resources.GetObject("StkListBtn.CheckedImage"), System.Drawing.Image)
        Me.StkListBtn.CheckedLineColor = System.Drawing.Color.DimGray
        Me.StkListBtn.DialogResult = System.Windows.Forms.DialogResult.None
        Me.StkListBtn.FocusedColor = System.Drawing.Color.Empty
        Me.StkListBtn.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StkListBtn.ForeColor = System.Drawing.Color.White
        Me.StkListBtn.Image = Global.ElectronicStore.My.Resources.Resources.purchase_order
        Me.StkListBtn.ImageOffsetX = 50
        Me.StkListBtn.ImageSize = New System.Drawing.Size(35, 35)
        Me.StkListBtn.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.StkListBtn.Location = New System.Drawing.Point(3, 325)
        Me.StkListBtn.Name = "StkListBtn"
        Me.StkListBtn.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.StkListBtn.OnHoverBorderColor = System.Drawing.Color.Transparent
        Me.StkListBtn.OnHoverForeColor = System.Drawing.Color.White
        Me.StkListBtn.OnHoverImage = Nothing
        Me.StkListBtn.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.StkListBtn.OnPressedColor = System.Drawing.Color.Transparent
        Me.StkListBtn.Radius = 15
        Me.StkListBtn.Size = New System.Drawing.Size(265, 53)
        Me.StkListBtn.TabIndex = 4
        Me.StkListBtn.Text = "Stock List"
        Me.StkListBtn.TextOffsetX = 5
        '
        'TaxBtn
        '
        Me.TaxBtn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TaxBtn.AnimationHoverSpeed = 0.07!
        Me.TaxBtn.AnimationSpeed = 0.03!
        Me.TaxBtn.BackColor = System.Drawing.Color.Transparent
        Me.TaxBtn.BaseColor = System.Drawing.Color.Transparent
        Me.TaxBtn.BorderColor = System.Drawing.Color.Black
        Me.TaxBtn.CheckedBaseColor = System.Drawing.Color.Gray
        Me.TaxBtn.CheckedBorderColor = System.Drawing.Color.Black
        Me.TaxBtn.CheckedForeColor = System.Drawing.Color.White
        Me.TaxBtn.CheckedImage = CType(resources.GetObject("TaxBtn.CheckedImage"), System.Drawing.Image)
        Me.TaxBtn.CheckedLineColor = System.Drawing.Color.DimGray
        Me.TaxBtn.DialogResult = System.Windows.Forms.DialogResult.None
        Me.TaxBtn.FocusedColor = System.Drawing.Color.Empty
        Me.TaxBtn.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TaxBtn.ForeColor = System.Drawing.Color.White
        Me.TaxBtn.Image = CType(resources.GetObject("TaxBtn.Image"), System.Drawing.Image)
        Me.TaxBtn.ImageOffsetX = 55
        Me.TaxBtn.ImageSize = New System.Drawing.Size(30, 30)
        Me.TaxBtn.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.TaxBtn.Location = New System.Drawing.Point(3, 496)
        Me.TaxBtn.Name = "TaxBtn"
        Me.TaxBtn.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TaxBtn.OnHoverBorderColor = System.Drawing.Color.Transparent
        Me.TaxBtn.OnHoverForeColor = System.Drawing.Color.White
        Me.TaxBtn.OnHoverImage = Nothing
        Me.TaxBtn.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.TaxBtn.OnPressedColor = System.Drawing.Color.Transparent
        Me.TaxBtn.Radius = 15
        Me.TaxBtn.Size = New System.Drawing.Size(265, 53)
        Me.TaxBtn.TabIndex = 3
        Me.TaxBtn.Text = "Tax Invoice"
        Me.TaxBtn.TextOffsetX = 3
        Me.TaxBtn.Visible = False
        '
        'AboutBtn
        '
        Me.AboutBtn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.AboutBtn.AnimationHoverSpeed = 0.07!
        Me.AboutBtn.AnimationSpeed = 0.03!
        Me.AboutBtn.BackColor = System.Drawing.Color.Transparent
        Me.AboutBtn.BaseColor = System.Drawing.Color.Transparent
        Me.AboutBtn.BorderColor = System.Drawing.Color.Black
        Me.AboutBtn.CheckedBaseColor = System.Drawing.Color.Gray
        Me.AboutBtn.CheckedBorderColor = System.Drawing.Color.Black
        Me.AboutBtn.CheckedForeColor = System.Drawing.Color.White
        Me.AboutBtn.CheckedImage = CType(resources.GetObject("AboutBtn.CheckedImage"), System.Drawing.Image)
        Me.AboutBtn.CheckedLineColor = System.Drawing.Color.DimGray
        Me.AboutBtn.DialogResult = System.Windows.Forms.DialogResult.None
        Me.AboutBtn.FocusedColor = System.Drawing.Color.Empty
        Me.AboutBtn.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AboutBtn.ForeColor = System.Drawing.Color.White
        Me.AboutBtn.Image = Global.ElectronicStore.My.Resources.Resources.about
        Me.AboutBtn.ImageOffsetX = 46
        Me.AboutBtn.ImageSize = New System.Drawing.Size(30, 30)
        Me.AboutBtn.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.AboutBtn.Location = New System.Drawing.Point(3, 439)
        Me.AboutBtn.Name = "AboutBtn"
        Me.AboutBtn.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.AboutBtn.OnHoverBorderColor = System.Drawing.Color.Transparent
        Me.AboutBtn.OnHoverForeColor = System.Drawing.Color.White
        Me.AboutBtn.OnHoverImage = Nothing
        Me.AboutBtn.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.AboutBtn.OnPressedColor = System.Drawing.Color.Transparent
        Me.AboutBtn.Radius = 15
        Me.AboutBtn.Size = New System.Drawing.Size(265, 53)
        Me.AboutBtn.TabIndex = 2
        Me.AboutBtn.Text = "About Software"
        '
        'DebtBtn
        '
        Me.DebtBtn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DebtBtn.AnimationHoverSpeed = 0.07!
        Me.DebtBtn.AnimationSpeed = 0.03!
        Me.DebtBtn.BackColor = System.Drawing.Color.Transparent
        Me.DebtBtn.BaseColor = System.Drawing.Color.Transparent
        Me.DebtBtn.BorderColor = System.Drawing.Color.Black
        Me.DebtBtn.CheckedBaseColor = System.Drawing.Color.Gray
        Me.DebtBtn.CheckedBorderColor = System.Drawing.Color.Black
        Me.DebtBtn.CheckedForeColor = System.Drawing.Color.White
        Me.DebtBtn.CheckedImage = CType(resources.GetObject("DebtBtn.CheckedImage"), System.Drawing.Image)
        Me.DebtBtn.CheckedLineColor = System.Drawing.Color.DimGray
        Me.DebtBtn.DialogResult = System.Windows.Forms.DialogResult.None
        Me.DebtBtn.FocusedColor = System.Drawing.Color.Empty
        Me.DebtBtn.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DebtBtn.ForeColor = System.Drawing.Color.White
        Me.DebtBtn.Image = Global.ElectronicStore.My.Resources.Resources.wallet2
        Me.DebtBtn.ImageOffsetX = 50
        Me.DebtBtn.ImageSize = New System.Drawing.Size(40, 40)
        Me.DebtBtn.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.DebtBtn.Location = New System.Drawing.Point(3, 384)
        Me.DebtBtn.Name = "DebtBtn"
        Me.DebtBtn.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.DebtBtn.OnHoverBorderColor = System.Drawing.Color.Transparent
        Me.DebtBtn.OnHoverForeColor = System.Drawing.Color.White
        Me.DebtBtn.OnHoverImage = Nothing
        Me.DebtBtn.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.DebtBtn.OnPressedColor = System.Drawing.Color.Transparent
        Me.DebtBtn.Padding = New System.Windows.Forms.Padding(5)
        Me.DebtBtn.Radius = 15
        Me.DebtBtn.Size = New System.Drawing.Size(265, 53)
        Me.DebtBtn.TabIndex = 1
        Me.DebtBtn.Text = "Billing"
        Me.DebtBtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.DebtBtn.TextOffsetX = -15
        '
        'DashboardBtn
        '
        Me.DashboardBtn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DashboardBtn.AnimationHoverSpeed = 0.07!
        Me.DashboardBtn.AnimationSpeed = 0.03!
        Me.DashboardBtn.BackColor = System.Drawing.Color.Transparent
        Me.DashboardBtn.BaseColor = System.Drawing.Color.Transparent
        Me.DashboardBtn.BorderColor = System.Drawing.Color.Black
        Me.DashboardBtn.CheckedBaseColor = System.Drawing.Color.Gray
        Me.DashboardBtn.CheckedBorderColor = System.Drawing.Color.Black
        Me.DashboardBtn.CheckedForeColor = System.Drawing.Color.White
        Me.DashboardBtn.CheckedImage = CType(resources.GetObject("DashboardBtn.CheckedImage"), System.Drawing.Image)
        Me.DashboardBtn.CheckedLineColor = System.Drawing.Color.DimGray
        Me.DashboardBtn.DialogResult = System.Windows.Forms.DialogResult.None
        Me.DashboardBtn.FocusedColor = System.Drawing.Color.Empty
        Me.DashboardBtn.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DashboardBtn.ForeColor = System.Drawing.Color.White
        Me.DashboardBtn.Image = CType(resources.GetObject("DashboardBtn.Image"), System.Drawing.Image)
        Me.DashboardBtn.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.DashboardBtn.ImageSize = New System.Drawing.Size(25, 25)
        Me.DashboardBtn.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.DashboardBtn.Location = New System.Drawing.Point(-4, 206)
        Me.DashboardBtn.Name = "DashboardBtn"
        Me.DashboardBtn.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.DashboardBtn.OnHoverBorderColor = System.Drawing.Color.Transparent
        Me.DashboardBtn.OnHoverForeColor = System.Drawing.Color.White
        Me.DashboardBtn.OnHoverImage = Nothing
        Me.DashboardBtn.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.DashboardBtn.OnPressedColor = System.Drawing.Color.Transparent
        Me.DashboardBtn.Radius = 15
        Me.DashboardBtn.Size = New System.Drawing.Size(268, 53)
        Me.DashboardBtn.TabIndex = 0
        Me.DashboardBtn.Text = "Dashboard"
        Me.DashboardBtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.AnimationHoverSpeed = 0.07!
        Me.Button4.AnimationSpeed = 0.03!
        Me.Button4.BackColor = System.Drawing.Color.Transparent
        Me.Button4.BaseColor = System.Drawing.Color.Transparent
        Me.Button4.BorderColor = System.Drawing.Color.Transparent
        Me.Button4.CheckedBaseColor = System.Drawing.Color.Gray
        Me.Button4.CheckedBorderColor = System.Drawing.Color.Black
        Me.Button4.CheckedForeColor = System.Drawing.Color.White
        Me.Button4.CheckedImage = Nothing
        Me.Button4.CheckedLineColor = System.Drawing.Color.DimGray
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button4.FocusedColor = System.Drawing.Color.Empty
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Image = Global.ElectronicStore.My.Resources.Resources.light
        Me.Button4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Button4.ImageSize = New System.Drawing.Size(20, 20)
        Me.Button4.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button4.Location = New System.Drawing.Point(1232, 784)
        Me.Button4.Name = "Button4"
        Me.Button4.OnHoverBaseColor = System.Drawing.Color.Transparent
        Me.Button4.OnHoverBorderColor = System.Drawing.Color.Black
        Me.Button4.OnHoverForeColor = System.Drawing.Color.White
        Me.Button4.OnHoverImage = Nothing
        Me.Button4.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button4.OnPressedColor = System.Drawing.Color.Black
        Me.Button4.Radius = 10
        Me.Button4.Size = New System.Drawing.Size(56, 29)
        Me.Button4.TabIndex = 7
        Me.Button4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Button4.Visible = False
        '
        'Dashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(1285, 813)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.GunaImageButton1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Dashboard"
        Me.Text = "MereDukan"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GunaElipsePanel1.ResumeLayout(False)
        Me.GunaShadowPanel1.ResumeLayout(False)
        Me.GunaShadowPanel1.PerformLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GunaShadowPanel10.ResumeLayout(False)
        Me.GunaShadowPanel10.PerformLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GunaShadowPanel14.ResumeLayout(False)
        Me.GunaShadowPanel14.PerformLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.GunaShadowPanel16.ResumeLayout(False)
        Me.GunaShadowPanel16.PerformLayout()
        Me.GunaShadowPanel15.ResumeLayout(False)
        Me.GunaShadowPanel15.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.GunaShadowPanel17.ResumeLayout(False)
        Me.GunaShadowPanel19.ResumeLayout(False)
        Me.GunaShadowPanel19.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.GunaShadowPanel18.ResumeLayout(False)
        Me.GunaShadowPanel18.PerformLayout()
        Me.GunaShadowPanel11.ResumeLayout(False)
        Me.GunaShadowPanel11.PerformLayout()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.GunaShadowPanel6.ResumeLayout(False)
        Me.GunaShadowPanel6.PerformLayout()
        Me.GunaShadowPanel4.ResumeLayout(False)
        Me.GunaShadowPanel4.PerformLayout()
        Me.GunaShadowPanel7.ResumeLayout(False)
        Me.GunaShadowPanel7.PerformLayout()
        Me.GunaShadowPanel3.ResumeLayout(False)
        Me.GunaShadowPanel3.PerformLayout()
        Me.GunaShadowPanel8.ResumeLayout(False)
        Me.GunaShadowPanel8.PerformLayout()
        Me.GunaShadowPanel5.ResumeLayout(False)
        Me.GunaShadowPanel5.PerformLayout()
        Me.GunaShadowPanel9.ResumeLayout(False)
        Me.GunaShadowPanel9.PerformLayout()
        Me.GunaShadowPanel2.ResumeLayout(False)
        Me.GunaShadowPanel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GunaImageButton1 As Guna.UI.WinForms.GunaImageButton
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Panel1 As Guna.UI.WinForms.GunaElipsePanel
    Friend WithEvents DashboardBtn As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Button4 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents AboutBtn As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents DebtBtn As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents StkListBtn As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents TaxBtn As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents LogoutBtn As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents ManageBtn As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents GunaLabel1 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ImageButton2 As Guna.UI.WinForms.GunaImageButton
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents GunaShadowPanel12 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label15 As Label
    Friend WithEvents GunaShadowPanel1 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label17 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents Label16 As Label
    Friend WithEvents GunaShadowPanel10 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label27 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents Label18 As Label
    Friend WithEvents GunaElipsePanel1 As Guna.UI.WinForms.GunaElipsePanel
    Friend WithEvents GunaShadowPanel13 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label30 As Label
    Friend WithEvents GunaShadowPanel14 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents Label33 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents GunaShadowPanel15 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents ComName As Label
    Friend WithEvents CompanyNameText As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents AddStockData As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents ModelNumber As Label
    Friend WithEvents ModelNameTextBox As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label34 As Label
    Friend WithEvents ProName As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Stkcode As Label
    Friend WithEvents STKcodeTextBox As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label39 As Label
    Friend WithEvents Price As Label
    Friend WithEvents CostPriceTXT As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label35 As Label
    Friend WithEvents TaxInPer As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents SellingPriceTxt As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label36 As Label
    Friend WithEvents Quantity As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Panel2 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label7 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents GunaShadowPanel6 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents billingaddress As Label
    Friend WithEvents GunaShadowPanel4 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents state As Label
    Friend WithEvents GunaShadowPanel7 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents contact As Label
    Friend WithEvents GunaShadowPanel3 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents surname As Label
    Friend WithEvents GunaShadowPanel8 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents gstno As Label
    Friend WithEvents GunaShadowPanel5 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents store As Label
    Friend WithEvents GunaShadowPanel9 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents address As Label
    Friend WithEvents GunaShadowPanel2 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents username As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents GunaShadowPanel16 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label38 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents RefreshBtn As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaShadowPanel17 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents DataGridView1 As Guna.UI.WinForms.GunaDataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents GunaShadowPanel11 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents GunaCirclePictureBox1 As Guna.UI.WinForms.GunaCirclePictureBox
    Friend WithEvents Label40 As Label
    Friend WithEvents GunaShadowPanel18 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents GunaButton1 As Guna.UI.WinForms.GunaButton
    Friend WithEvents GunaShadowPanel19 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceButton2 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Label48 As Label
    Friend WithEvents GunaTextBox5 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label43 As Label
    Friend WithEvents GunaTextBox1 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label44 As Label
    Friend WithEvents UpadteGstTxt As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label45 As Label
    Friend WithEvents GunaTextBox3 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label46 As Label
    Friend WithEvents GunaTextBox4 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label47 As Label
    Friend WithEvents GunaAdvenceButton1 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Label50 As Label
    Friend WithEvents GunaTextBox7 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label51 As Label
    Friend WithEvents GunaTextBox8 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents GunaCircleButton1 As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents Label49 As Label
    Friend WithEvents Label52 As Label
End Class
