﻿Imports System.Diagnostics.Contracts
Imports System.Diagnostics.Eventing.Reader
Imports System.Net
Imports System.Security.Cryptography.X509Certificates
Imports System.Windows.Forms.AxHost
Imports FireSharp.Config
Imports FireSharp.Interfaces
Imports FireSharp.Response
Public Class Form1
    '--------------------------------------Variable Declaration-------------------------
    Dim Greetusername As String
    Private nightMode As Boolean = True
    Private passShow As Boolean = False
    Public Shared userid, password As String
    '------------------------------------------Fire Base Linkage ------------------------------------------
    Private fcon As New FirebaseConfig() With
    {
            .AuthSecret = "gN8oJuBoKD4ZWjFQvwGTS4chLYNyvDXSgeDaJW91",
            .BasePath = "https://userregistration-7cd40-default-rtdb.asia-southeast1.firebasedatabase.app/"
    }
    Private client As IFirebaseClient


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Focus()
        TabControl1.SelectedIndex = 0
        Try
            client = New FireSharp.FirebaseClient(fcon)
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub




    '------------------------------------------Fire Base Linkage End ------------------------------------------

    Private Sub TextBox1_GotFocus(sender As Object, e As EventArgs) Handles TextBox1.GotFocus
        Label3.Text = ""
    End Sub

    Private Sub TextBox1_LostFocus(sender As Object, e As EventArgs) Handles TextBox1.LostFocus
        If String.IsNullOrWhiteSpace(TextBox1.Text) Then
            Label3.Text = "Username"
        End If
    End Sub

    Private Sub TextBox2_GotFocus(sender As Object, e As EventArgs) Handles TextBox2.GotFocus
        Label4.Text = ""
    End Sub

    Private Sub TextBox2_LostFocus(sender As Object, e As EventArgs) Handles TextBox2.LostFocus
        If String.IsNullOrWhiteSpace(TextBox2.Text) Then
            Label4.Text = "Password"
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        userid = TextBox1.Text
        password = TextBox2.Text



        If String.IsNullOrEmpty(userid) And String.IsNullOrEmpty(password) Then
            MessageBox.Show("UserId and Password Required", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return
        Else
            If String.IsNullOrEmpty(userid) Then
                MessageBox.Show("Invlaid UserId", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBox1.Focus()
                Return
            End If
            If String.IsNullOrEmpty(password) Then
                MessageBox.Show("Invalid Password ", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBox2.Focus()
                Return
            End If
        End If
        Try
            ' Retrieve user data from the database
            Dim res = client.Get("User/" & userid)
            Dim resuser = res.ResultAs(Of Myuser)

            ' Check if the retrieved user data matches the provided credentials
            If resuser IsNot Nothing AndAlso resuser.Password = password Then
                Billing.pass = resuser.Password
                ' Set user-specific data for the dashboard
                Dashboard.Fname = resuser.Name
                Dashboard.Storename = resuser.Storename
                Dashboard.Fsurname = resuser.Surname
                Dashboard.Fstate = resuser.State
                Dashboard.Faddress = resuser.Address
                Dashboard.Fcontact = resuser.Contactno
                Dashboard.Fgst = resuser.Gstno
                Dashboard.Fbillingaddress = resuser.BillingAddress
                Dashboard.usernameofcurrentuser = resuser.Username
                Billing.currentuser = resuser.Username
                Billing.storename = resuser.Storename
                Billing.gstno = resuser.Gstno

                ' Switch to the appropriate tab in the UI
                TabControl1.SelectedIndex = 1

                ' Update the greeting label with the user's name
                Label5.Text = "Welcome, " & resuser.Name
            Else
                ' Credentials mismatch, display error message
                MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            ' Handle exceptions, e.g., network issues or database errors
            MessageBox.Show("Cannot connect to server. Please check your internet connection and try again later.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If nightMode Then
            Button4.Image = My.Resources.light
            Me.BackColor = Color.Black
            Panel1.BaseColor = Color.Black
            Panel2.BorderStyle = BorderStyle.None
            Panel3.BorderStyle = BorderStyle.None
            Panel4.BorderStyle = BorderStyle.None
            Label1.ForeColor = Color.White
            Label1.BackColor = Color.FromArgb(15, 15, 15)
            Button2.ForeColor = Color.White
            ShadowPanel1.BaseColor = Color.FromArgb(15, 15, 15)
            GunaShadowPanel1.BaseColor = Color.FromArgb(40, 40, 40)
            GunaShadowPanel2.BaseColor = Color.FromArgb(40, 40, 40)
            TabPage2.BackColor = Color.Black
            Label5.ForeColor = Color.White
            Label6.ForeColor = Color.White
            Label7.ForeColor = Color.White
            Label8.ForeColor = Color.White
            Label9.ForeColor = Color.White
            Label10.ForeColor = Color.White
            Label11.ForeColor = Color.White
            Label12.ForeColor = Color.White
        Else
            Button4.Image = My.Resources.night_mode1
            Me.BackColor = Color.White
            Panel1.BaseColor = Color.White
            Panel2.BorderStyle = BorderStyle.FixedSingle
            Panel3.BorderStyle = BorderStyle.FixedSingle
            Panel4.BorderStyle = BorderStyle.FixedSingle
            Button2.ForeColor = Color.Black
            Label1.ForeColor = Color.Blue
            Label1.BackColor = Color.White
            ShadowPanel1.BaseColor = Color.White
            GunaShadowPanel1.BaseColor = Color.White
            GunaShadowPanel2.BaseColor = Color.White
            TabPage2.BackColor = Color.White
            Label5.ForeColor = Color.White
            Label6.ForeColor = Color.Black
            Label7.ForeColor = Color.Black
            Label8.ForeColor = Color.Black
            Label9.ForeColor = Color.Black
            Label10.ForeColor = Color.Black
            Label11.ForeColor = Color.Black
            Label12.ForeColor = Color.Black
        End If
        nightMode = Not nightMode
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If passShow Then
            Button5.Image = My.Resources.eye
            TextBox2.UseSystemPasswordChar = True
            TextBox2.PasswordChar = ""
        Else
            Button5.Image = My.Resources.view
            TextBox2.UseSystemPasswordChar = False
            TextBox2.PasswordChar = ""
        End If
        passShow = Not passShow
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        TextBox1.Focus()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        TextBox2.Focus()
    End Sub

    Private Sub GunaAdvenceButton2_Click_1(sender As Object, e As EventArgs) Handles GunaAdvenceButton2.Click
        Me.Hide()
        Dashboard.Show()
        'Me.Close()

    End Sub

    Private Sub GunaAdvenceButton1_Click(sender As Object, e As EventArgs) Handles GunaAdvenceButton1.Click
        TabControl1.SelectedIndex = 0
    End Sub

    Private Sub GunaAdvenceButton3_Click(sender As Object, e As EventArgs) Handles GunaAdvenceButton3.Click
        Me.Hide()
        Billing.Show()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
        Register.Show()
        'Me.Close()
    End Sub
End Class
