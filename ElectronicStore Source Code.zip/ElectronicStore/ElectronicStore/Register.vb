﻿Imports System.Net
Imports System.Security.Cryptography
Imports System.Security.Cryptography.X509Certificates
Imports System.Windows.Forms
Imports FireSharp.Config
Imports FireSharp.Interfaces
Imports FireSharp.Response
Imports Microsoft.VisualBasic.ApplicationServices

Public Class Register

    ' Declare class-level variables
    Dim Oname, surname, storename, storecat, state, address, gst, baddress, username, password, conpass As String
    Dim telephoneno, contact As Int64

    Private nightMode As Boolean = True
    Private passShow As Boolean = False
    Private passConShow As Boolean = False
    Private client As IFirebaseClient

    Private Sub Register_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox7.Enabled = False
        TextBox8.Enabled = False
        Button8.Enabled = False
        TextBox7.BorderColor = Color.Gray
        TextBox8.BorderColor = Color.Gray
        Try
            ' Initialize Firebase client
            Dim fcon As New FirebaseConfig() With {
                .AuthSecret = "gN8oJuBoKD4ZWjFQvwGTS4chLYNyvDXSgeDaJW91",
                .BasePath = "https://userregistration-7cd40-default-rtdb.asia-southeast1.firebasedatabase.app/"
            }
            client = New FireSharp.FirebaseClient(fcon)
        Catch ex As Exception
            MessageBox.Show("Cannot Connect to Surver!! Please Check Your Internet Connection and try again later", "Internet Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try
    End Sub
    '-----------------------------------------------Dark Mode----------------------------------------- 
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If nightMode Then
            Button4.Image = My.Resources.light
            Me.BackColor = Color.Black
            Panel1.BaseColor = Color.FromArgb(18, 18, 18)
            Panel3.BaseColor = Color.FromArgb(32, 32, 32)
            Panel4.BaseColor = Color.FromArgb(32, 32, 32)
            Panel3.ShadowColor = Color.White
            Panel4.ShadowColor = Color.White
            TabPage1.BackColor = Color.Black
            TabPage2.BackColor = Color.Black
            Label1.ForeColor = Color.White
            Label2.ForeColor = Color.White
            Label3.ForeColor = Color.White
            Label4.ForeColor = Color.White
            Label5.ForeColor = Color.White
            Label6.ForeColor = Color.White
            Label7.ForeColor = Color.White
            Label8.ForeColor = Color.White
            Label9.ForeColor = Color.White
            Label10.ForeColor = Color.White
            Label11.ForeColor = Color.White
            Label12.ForeColor = Color.White
            Label15.ForeColor = Color.White
            Panel2.BorderStyle = BorderStyle.None
            Panel5.BorderStyle = BorderStyle.None
            Panel6.BorderStyle = BorderStyle.None
            Checkbox1.ForeColor = Color.White
            CheckBox2.ForeColor = Color.White
        Else
            Button4.Image = My.Resources.night_mode1
            Me.BackColor = Color.White
            Panel1.BaseColor = Color.White
            Panel3.BaseColor = Color.White
            Panel4.BaseColor = Color.White
            Panel3.ShadowColor = Color.Black
            Panel4.ShadowColor = Color.Black
            TabPage1.BackColor = Color.White
            TabPage2.BackColor = Color.White
            Label1.ForeColor = Color.Black
            Label2.ForeColor = Color.Black
            Label3.ForeColor = Color.Black
            Label4.ForeColor = Color.Black
            Label5.ForeColor = Color.Black
            Label6.ForeColor = Color.Black
            Label7.ForeColor = Color.Black
            Label8.ForeColor = Color.Black
            Label9.ForeColor = Color.Black
            Label10.ForeColor = Color.Black
            Label11.ForeColor = Color.Black
            Label12.ForeColor = Color.Black
            Label15.ForeColor = Color.Black
            Checkbox1.ForeColor = Color.Black
            Panel2.BorderStyle = BorderStyle.FixedSingle
            Panel5.BorderStyle = BorderStyle.FixedSingle
            Panel6.BorderStyle = BorderStyle.FixedSingle
            CheckBox2.ForeColor = Color.Black
        End If
        nightMode = Not nightMode
    End Sub

    '----------------------------------Open Login form on register form close-------------------------------
    Private Sub Register_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        'Me.Close()
        Form1.WindowState = FormWindowState.Normal
        Form1.Show()
    End Sub

    '--------------------------------------------Back To login page-----------------------------------------
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click, Button10.Click
        Me.Close()
        Form1.WindowState = FormWindowState.Normal
        Form1.Show()
    End Sub

    '-----------------------------------------------GST input Condition------------------------------------
    Private Sub Checkbox1_CheckedChanged(sender As Object, e As EventArgs) Handles Checkbox1.CheckedChanged
        If Checkbox1.Checked Then
            TextBox7.Enabled = True
            TextBox8.Enabled = True
            TextBox7.BaseColor = Color.White
            TextBox8.BaseColor = Color.White
            TextBox7.BorderColor = Color.Black
            TextBox8.BorderColor = Color.Black
        Else
            TextBox7.Enabled = False
            TextBox8.Enabled = False
            TextBox7.BaseColor = Color.FromArgb(224, 224, 224)
            TextBox8.BaseColor = Color.FromArgb(224, 224, 224)
            TextBox7.BorderColor = Color.Gray
            TextBox8.BorderColor = Color.Gray
        End If
    End Sub

    '---------------------------------------Input Save -------------------------------------------
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim parsedTelephoneNumber As Int64
        Dim parsedContact As Int64

        Oname = TextBox1.Text
        surname = TextBox2.Text
        storename = TextBox3.Text

        If Checkbox1.Checked Then
            baddress = TextBox8.Text
            gst = TextBox7.Text
            If gst.Length <> 15 Then
                MessageBox.Show("Please enter a valid 15-digit GST number.", "Invalid GST Number", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
            If String.IsNullOrEmpty(baddress) Then
                MessageBox.Show("Please Provide Billing Address.", "Empty Billing Address", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
        Else
            baddress = "null"
            gst = "null"
        End If

        ' Parsing telephone number
        If Not Int64.TryParse(TextBox4.Text, parsedTelephoneNumber) Then
            MessageBox.Show("Please enter a valid telephone number.", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return ' Exit the method if telephone number is not a valid integer
        End If

        telephoneno = parsedTelephoneNumber

        ' Check if an item is selected in ComboBox2 before accessing its value
        If ComboBox2.SelectedItem IsNot Nothing Then
            state = ComboBox2.SelectedItem.ToString()
        Else
            MessageBox.Show("Please select a state.", "Incomplete Information", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return ' Exit the method if state is not selected
        End If

        address = TextBox5.Text

        ' Parsing contact number
        If Not Int64.TryParse(TextBox6.Text, parsedContact) Then
            MessageBox.Show("Please enter a valid contact number.", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return ' Exit the method if contact is not a valid integer
        End If

        ' Check if contact is exactly 10 digits
        If TextBox6.Text.Length <> 10 Then
            MessageBox.Show("Contact number must be exactly 10 digits.", "Invalid Entry", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return ' Exit the method if contact number length is invalid
        End If

        contact = parsedContact

        If String.IsNullOrWhiteSpace(Oname) Or String.IsNullOrWhiteSpace(surname) Or String.IsNullOrWhiteSpace(storename) Or String.IsNullOrWhiteSpace(state) Or String.IsNullOrWhiteSpace(address) Then
            MessageBox.Show("Please fill in all required details.", "Incomplete Information", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            TabControl1.SelectedIndex = 1

        End If
    End Sub

    '----------------------------------------Previuos Page----------------------------------------------------
    Private Sub GunaAdvenceButton3_Click(sender As Object, e As EventArgs) Handles GunaAdvenceButton3.Click
        TabControl1.SelectedIndex = 0
    End Sub

    Private Sub GunaShadowPanel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel4.Paint

    End Sub

    '--------------------------------------------User And Password Entry-------------------------------------------

    '--------------------show password logic for password -------------------------
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If passShow Then
            Button5.Image = My.Resources.eye
            TextBoxPass.UseSystemPasswordChar = True
            TextBoxPass.PasswordChar = ""
        Else
            Button5.Image = My.Resources.view
            TextBoxPass.UseSystemPasswordChar = False
            TextBoxPass.PasswordChar = ""
        End If
        passShow = Not passShow
    End Sub

    '--------------------------Term and Condition URl---------------------------------
    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked

        Process.Start("https://meredukantermsandcondition.netlify.app/")
    End Sub


    '--------------------show password logic for Confirm password -------------------------
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If passConShow Then
            Button6.Image = My.Resources.eye
            TextBoxConpass.UseSystemPasswordChar = True
            TextBoxConpass.PasswordChar = ""
        Else
            Button6.Image = My.Resources.view
            TextBoxConpass.UseSystemPasswordChar = False
            TextBoxConpass.PasswordChar = ""
        End If
        passConShow = Not passConShow
    End Sub

    '----------------------------------------- Placeholder Logic--------------------------------------------
    Private Sub TextBoxUsername_GotFocus(sender As Object, e As EventArgs) Handles TextBoxUsername.GotFocus
        Usernmelabel.Text = ""
    End Sub

    Private Sub TextBoxUsername_LostFocus(sender As Object, e As EventArgs) Handles TextBoxUsername.LostFocus
        If String.IsNullOrEmpty(TextBoxUsername.Text) Then
            Usernmelabel.Text = "Username"
        End If

    End Sub

    Private Sub TextBoxPass_GotFocus(sender As Object, e As EventArgs) Handles TextBoxPass.GotFocus
        Passlabel.Text = ""
    End Sub

    Private Sub TextBoxPass_LostFocus(sender As Object, e As EventArgs) Handles TextBoxPass.LostFocus
        If String.IsNullOrEmpty(TextBoxPass.Text) Then
            Passlabel.Text = "Password"
        End If
    End Sub

    Private Sub TextBoxConpass_GotFocus(sender As Object, e As EventArgs) Handles TextBoxConpass.GotFocus
        Conpasslabel.Text = ""
    End Sub

    Private Sub TextBoxConpass_LostFocus(sender As Object, e As EventArgs) Handles TextBoxConpass.LostFocus
        If String.IsNullOrEmpty(TextBoxConpass.Text) Then
            Conpasslabel.Text = "Confirm Password"
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked Then
            Button8.Enabled = True
        Else
            Button8.Enabled = False
        End If
    End Sub
    Private Sub Usernmelabel_Click(sender As Object, e As EventArgs) Handles Usernmelabel.Click
        TextBoxUsername.SetOnGotFocus()
    End Sub
    Private Sub Passlabel_Click(sender As Object, e As EventArgs) Handles Passlabel.Click
        TextBoxPass.Focus()
    End Sub
    Private Sub Conpasslabel_Click(sender As Object, e As EventArgs) Handles Conpasslabel.Click
        TextBoxConpass.Focus()
    End Sub


    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        ' Get input values
        username = TextBoxUsername.Text
        password = TextBoxPass.Text
        conpass = TextBoxConpass.Text

        ' Check if any field is empty
        If String.IsNullOrEmpty(username) Or String.IsNullOrEmpty(password) Or String.IsNullOrEmpty(conpass) Then
            MessageBox.Show("Please provide all required information.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Check if password matches confirm password
        If password <> conpass Then
            MessageBox.Show("Password doesn't match.", "Invalid Confirm Password", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        If password.Length < 8 Then
            MessageBox.Show("Password length should be greater than 8 characters.", "Invalid Confirm Password", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        '-------------------------------------------Existing User name check--------------------------------
        Try
            Dim res = client.Get("User/" + username)
            Dim dbsuser = res.ResultAs(Of Myuser)

            Dim CurUser As New Myuser() With
        {
            .Username = TextBoxUsername.Text
        }

            ' Check if a user with the same username already exists
            If (Myuser.CheckuserExist(dbsuser, CurUser)) Then
                MessageBox.Show("Username Already Exists!", "Existing User", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBoxUsername.Focus()
                Return
            End If
            '---------------------------------------Existing User name check End --------------------------------
            Dim invoiceset As Int64 = 1
            ' Proceed with the registration process if everything is valid
            Dim NewUser As New Myuser() With {
                .Name = Oname,
                .Surname = surname,
                .Storename = storename,
                .Storecat = storecat,
                .State = state,
                .Address = address,
                .Gstno = gst,
                .BillingAddress = baddress,
                .Username = username,
                .Password = password,
                .Telephoneno = telephoneno,
                .Contactno = contact
            }

            ' Set the user details under 'User' node and create a folder named 'Invoice' under the user with invoice number set to 0
            Dim setter = client.Set("User/" & username, NewUser)
            Dim invoiceSetter = client.Set("User/" & username & "/Invoice/CurrentInvoiceNo", invoiceset)


            If setter.StatusCode = HttpStatusCode.OK And invoiceSetter.StatusCode = HttpStatusCode.OK Then

                MessageBox.Show("Your login ID has been successfully created.", "Registration Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)


                Me.Hide()
                Form1.Show()
                Me.Close()
            Else
                MessageBox.Show("Failed to create login id.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MessageBox.Show("Cannot Connect to Surver!! Please Check Your Internet Connection and try again later", "Internet Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try
    End Sub

End Class