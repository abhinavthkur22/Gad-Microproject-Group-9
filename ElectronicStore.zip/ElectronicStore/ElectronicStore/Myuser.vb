﻿Imports Microsoft.VisualBasic.ApplicationServices

Public Class Myuser
    Public Property Name As String
    Public Property Username As String
    Public Property Password As String
    Public Property Surname As String
    Public Property Storename As String
    Public Property Storecat As String
    Public Property Telephoneno As String
    Public Property State As String
    Public Property Address As String
    Public Property Contactno As String
    Public Property Gstno As String
    Public Property BillingAddress As String

    Private Shared TheError As String = "User Not Found"
    Private Shared GstExistError As String = "GST Number Already Exists in Database"


    'Stock add
    Public Property ProductName As String
    Public Property CompanyName As String
    Public Property ModelNo As String
    Public Property Quantity As String
    Public Property StkCode As String
    Public Property CostPrice As String
    Public Property SellingPrice As String
    Public Property TAXInNumber As String
    Public Property stk As String
    Public Property totalFair As Int64

    Public Property CustomerName As String
    Public Property CustomerAddress As String
    Public Property CustomerContact As String
    Public Property PurchaseDateTime As String

    Public Property Totalsales As String

    Public Property Totalprofit As Int64
    Public Property CurrentInvoiceNo As Int64


    Public Shared Sub ShowError()
        MessageBox.Show(TheError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Public Shared Sub ShowGstExistError()
        MessageBox.Show(GstExistError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Public Shared Function IsEqual(user1 As Myuser, user2 As Myuser) As Boolean
        If user1 Is Nothing Or user2 Is Nothing Then
            TheError = "User Not Found"
            Return False
        End If

        If user1.Username <> user2.Username OrElse user1.Password <> user2.Password Then
            TheError = "Invalid Username Or Password"
            Return False
        End If

        Return True
    End Function

    Public Shared Function CheckuserExist(user1 As Myuser, user2 As Myuser) As Boolean
        If user1 Is Nothing Or user2 Is Nothing Then
            TheError = "User Not Found"
            Return False
        End If

        If user1.Username = user2.Username Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Shared Function CheckgstExist(gst1 As Myuser, gst2 As Myuser) As Boolean
        If gst1 Is Nothing Or gst2 Is Nothing Then
            TheError = "User Not Found"
            Return False
        End If
        If gst1.Gstno = gst2.Gstno Then
            Return True
        Else
            Return False
        End If
    End Function




End Class
