﻿Imports System.Reflection.Emit
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Button
Imports FireSharp.Config
Imports FireSharp.Response
Imports FireSharp.Interfaces
Imports System.Diagnostics.Eventing.Reader
Imports System.Net
Imports FireSharp
Imports Guna.UI.WinForms

Public Class Dashboard

    Function RefreshStocks()
        Try
            DataGridView1.Rows.Clear()

            ' Retrieve data from the "ZzappStockdata" node in Firebase
            Dim res = client.Get("User/" & usernameofcurrentuser & "/ZzappStockdata")
            Dim stockDataDict = res.ResultAs(Of Dictionary(Of String, Myuser))


            If stockDataDict IsNot Nothing AndAlso stockDataDict.Count > 0 Then
                ' Iterate through each stock data entry
                For Each kvp As KeyValuePair(Of String, Myuser) In stockDataDict
                    Dim stockCode As String = kvp.Key
                    Dim stockItem As Myuser = kvp.Value
                    Dim productName As String = stockItem.ProductName
                    Dim companyName As String = stockItem.CompanyName
                    Dim modelNo As String = stockItem.ModelNo
                    Dim costPrice As Double = stockItem.CostPrice
                    Dim sellingPrice As Double = stockItem.SellingPrice
                    Dim tax As Double = stockItem.TAXInNumber
                    Dim quantity As Integer = stockItem.Quantity

                    DataGridView1.Rows.Add(
                DataGridView1.Rows.Count + 1, ' Sr No
                stockCode,                     ' Stock Code
                productName,                  ' Product Name
                companyName,                  ' Company
                costPrice,                    ' Cost Price
                sellingPrice,                 ' Selling Price
                tax,                          ' Tax In Percentage
                quantity                      ' Avaliable Quantity
                )
                Next
            Else
                MessageBox.Show("No stock data found.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            MessageBox.Show("Error retrieving stock data from Firebase: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function




    Public Shared Fname, Fsurname, Storename, Fstate, Faddress, Fcontact, Fgst, Fbillingaddress, usernameofcurrentuser As String
    Dim Product, Company, Model, stk As String
    Dim Quant, SPrice, Cprise As Double
    Dim tax As Double
    Public nightmode As Boolean = False

    Private client As IFirebaseClient

    Private Sub Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            ' Initialize Firebase client
            Dim fcon As New FirebaseConfig() With {
                .AuthSecret = "gN8oJuBoKD4ZWjFQvwGTS4chLYNyvDXSgeDaJW91",
                .BasePath = "https://userregistration-7cd40-default-rtdb.asia-southeast1.firebasedatabase.app/"
            }
            client = New FireSharp.FirebaseClient(fcon)
        Catch ex As Exception
            MessageBox.Show("Cannot Connect to Surver!! Please Check Your Internet Connection and try again later", "Internet Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try
        TotalSalesPrice()

        Label8.Text = "Hey! " & Fname
        username.Text = Fname
        surname.Text = Fsurname
        store.Text = Storename
        state.Text = Fstate
        address.Text = Faddress
        contact.Text = Fcontact
        gstno.Text = Fgst
        billingaddress.Text = Fbillingaddress
        'Label9.Text = Storename
        DashboardBtn.BackColor = Color.FromArgb(50, 50, 50)
        PictureBox1.Show()
        PictureBox2.Hide()
        PictureBox3.Hide()
        PictureBox4.Hide()
        PictureBox5.Hide()
        PictureBox6.Hide()
        ImageButton2.ImageSize = New Size(64, 64)
        Me.WindowState = FormWindowState.Maximized
        TabControl1.SelectedIndex = 0




        Button4.Image = My.Resources.light
        Me.BackColor = Color.Black
        TabPage1.BackColor = Color.Black
        TabPage2.BackColor = Color.Black
        TabPage3.BackColor = Color.Black
        TabPage4.BackColor = Color.Black
        TabPage5.BackColor = Color.Black
        TabPage6.BackColor = Color.Black
        TabPage7.BackColor = Color.Black
        Label2.ForeColor = Color.White
        Label1.ForeColor = Color.White
        Label10.ForeColor = Color.White
        Label11.ForeColor = Color.White
        Label7.ForeColor = Color.White
        Label9.ForeColor = Color.White
        Label11.ForeColor = Color.White
        Label12.ForeColor = Color.White
        Label13.ForeColor = Color.White
        Label14.ForeColor = Color.White
        Panel1.BaseColor = Color.FromArgb(40, 40, 40)
        Panel2.BaseColor = Color.FromArgb(40, 40, 40)

        RefreshStocks()

        If Fgst = "null" Then
            TaxInPer.Enabled = False
            TaxInPer.Text = 0
        Else
            TaxInPer.Enabled = True
        End If


    End Sub

    Private Sub Dashboard_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Form1.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If nightmode Then
            Button4.Image = My.Resources.light
            Me.BackColor = Color.Black
            TabPage1.BackColor = Color.Black
            TabPage2.BackColor = Color.Black
            TabPage3.BackColor = Color.Black
            TabPage4.BackColor = Color.Black
            TabPage5.BackColor = Color.Black
            TabPage6.BackColor = Color.Black
            TabPage7.BackColor = Color.Black
            Label2.ForeColor = Color.White
            Label1.ForeColor = Color.White
            Label10.ForeColor = Color.White
            Label11.ForeColor = Color.White
            Label7.ForeColor = Color.White
            Label9.ForeColor = Color.White
            Label11.ForeColor = Color.White
            Label12.ForeColor = Color.White
            Label13.ForeColor = Color.White
            Label14.ForeColor = Color.White
            Panel1.BaseColor = Color.FromArgb(40, 40, 40)
            Panel2.BaseColor = Color.FromArgb(40, 40, 40)

        Else
            Button4.Image = My.Resources.night_mode1
            Me.BackColor = Color.White
            TabPage1.BackColor = Color.White
            TabPage2.BackColor = Color.White
            TabPage3.BackColor = Color.White
            TabPage4.BackColor = Color.White
            TabPage5.BackColor = Color.White
            TabPage6.BackColor = Color.White
            TabPage7.BackColor = Color.Transparent
            Label2.ForeColor = Color.Black
            Label1.ForeColor = Color.Black
            Label10.ForeColor = Color.Black
            Label11.ForeColor = Color.Black
            Label7.ForeColor = Color.Black
            Label9.ForeColor = Color.Black
            Label11.ForeColor = Color.Black
            Label12.ForeColor = Color.Black
            Label13.ForeColor = Color.Black
            Label14.ForeColor = Color.Black
            Panel1.BaseColor = Color.Black
            Panel2.BaseColor = Color.White
        End If
        nightmode = Not nightmode
    End Sub

    Private Sub DashboardBtn_Click(sender As Object, e As EventArgs) Handles DashboardBtn.Click
        TabControl1.SelectedIndex = 0

        DashboardBtn.BackColor = Color.FromArgb(50, 50, 50)
        DebtBtn.BackColor = Color.Transparent
        TaxBtn.BackColor = Color.Transparent
        ManageBtn.BackColor = Color.Transparent
        StkListBtn.BackColor = Color.Transparent
        AboutBtn.BackColor = Color.Transparent
        ImageButton2.Image = My.Resources.profile
        ImageButton2.ImageSize = New Size(64, 64)

        PictureBox1.Show()
        PictureBox2.Hide()
        PictureBox3.Hide()
        PictureBox4.Hide()
        PictureBox5.Hide()
        PictureBox6.Hide()
    End Sub

    Private Sub DebtBtn_Click(sender As Object, e As EventArgs) Handles DebtBtn.Click

        DashboardBtn.BackColor = Color.Transparent
        DebtBtn.BackColor = Color.FromArgb(50, 50, 50)
        TaxBtn.BackColor = Color.Transparent
        ManageBtn.BackColor = Color.Transparent
        StkListBtn.BackColor = Color.Transparent
        AboutBtn.BackColor = Color.Transparent
        ImageButton2.Image = My.Resources.profile
        ImageButton2.ImageSize = New Size(64, 64)

        PictureBox1.Hide()
        PictureBox2.Show()
        PictureBox3.Hide()
        PictureBox4.Hide()
        PictureBox5.Hide()
        PictureBox6.Hide()

        Dim res As DialogResult = MessageBox.Show("Are You Sure You wants to head to Billing Section?" + Environment.NewLine + "Returning Back to Dashboard Requires Password", "Billing Page", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)

        If (res = DialogResult.OK) Then
            Me.Hide()
            Billing.ShowDialog()
            'Me.Close()
        End If
    End Sub


    Private Sub TaxBtn_Click(sender As Object, e As EventArgs) Handles TaxBtn.Click
        TabControl1.SelectedIndex = 2

        DashboardBtn.BackColor = Color.Transparent
        DebtBtn.BackColor = Color.Transparent
        TaxBtn.BackColor = Color.FromArgb(50, 50, 50)
        ManageBtn.BackColor = Color.Transparent
        StkListBtn.BackColor = Color.Transparent
        AboutBtn.BackColor = Color.Transparent
        ImageButton2.Image = My.Resources.profile
        ImageButton2.ImageSize = New Size(64, 64)

        PictureBox1.Hide()
        PictureBox2.Hide()
        PictureBox3.Show()
        PictureBox4.Hide()
        PictureBox5.Hide()
        PictureBox6.Hide()
    End Sub

    Private Sub ManageBtn_Click(sender As Object, e As EventArgs) Handles ManageBtn.Click
        TabControl1.SelectedIndex = 3

        DashboardBtn.BackColor = Color.Transparent
        DebtBtn.BackColor = Color.Transparent
        TaxBtn.BackColor = Color.Transparent
        ManageBtn.BackColor = Color.FromArgb(50, 50, 50)
        StkListBtn.BackColor = Color.Transparent
        AboutBtn.BackColor = Color.Transparent
        ImageButton2.Image = My.Resources.profile
        ImageButton2.ImageSize = New Size(64, 64)

        PictureBox1.Hide()
        PictureBox2.Hide()
        PictureBox3.Hide()
        PictureBox4.Show()
        PictureBox5.Hide()
        PictureBox6.Hide()
    End Sub

    Private Sub StkListBtn_Click(sender As Object, e As EventArgs) Handles StkListBtn.Click
        TabControl1.SelectedIndex = 4

        DashboardBtn.BackColor = Color.Transparent
        DebtBtn.BackColor = Color.Transparent
        TaxBtn.BackColor = Color.Transparent
        ManageBtn.BackColor = Color.Transparent
        StkListBtn.BackColor = Color.FromArgb(50, 50, 50)
        AboutBtn.BackColor = Color.Transparent
        ImageButton2.Image = My.Resources.profile
        ImageButton2.ImageSize = New Size(64, 64)

        PictureBox1.Hide()
        PictureBox2.Hide()
        PictureBox3.Hide()
        PictureBox4.Hide()
        PictureBox5.Show()
        PictureBox6.Hide()
    End Sub

    Private Sub AboutBtn_Click(sender As Object, e As EventArgs) Handles AboutBtn.Click
        TabControl1.SelectedIndex = 5

        DashboardBtn.BackColor = Color.Transparent
        DebtBtn.BackColor = Color.Transparent
        TaxBtn.BackColor = Color.Transparent
        ManageBtn.BackColor = Color.Transparent
        StkListBtn.BackColor = Color.Transparent
        AboutBtn.BackColor = Color.FromArgb(50, 50, 50)
        ImageButton2.Image = My.Resources.profile
        ImageButton2.ImageSize = New Size(64, 64)

        PictureBox1.Hide()
        PictureBox2.Hide()
        PictureBox3.Hide()
        PictureBox4.Hide()
        PictureBox5.Hide()
        PictureBox6.Show()
    End Sub

    Private Sub LogoutBtn_Click(sender As Object, e As EventArgs) Handles LogoutBtn.Click
        If MessageBox.Show("Do You really want to logout?", "Logout", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = DialogResult.OK Then
            Me.Hide()
            Form1.TextBox1.Clear()
            Form1.TextBox2.Clear()
            Form1.userid = Nothing
            Form1.password = Nothing
            Form1.ShowDialog()
            Me.Close()
        End If
    End Sub

    Private Sub ImageButton2_Click(sender As Object, e As EventArgs) Handles ImageButton2.Click
        DashboardBtn.BackColor = Color.Transparent
        DebtBtn.BackColor = Color.Transparent
        TaxBtn.BackColor = Color.Transparent
        ManageBtn.BackColor = Color.Transparent
        StkListBtn.BackColor = Color.Transparent
        AboutBtn.BackColor = Color.Transparent

        PictureBox1.Hide()
        PictureBox2.Hide()
        PictureBox3.Hide()
        PictureBox4.Hide()
        PictureBox5.Hide()
        PictureBox6.Hide()

        ImageButton2.Image = My.Resources.profilenew
        ImageButton2.ImageSize = New Size(80, 80)
        TabControl1.SelectedIndex = 6
    End Sub

    'Add stock Page


    Private Sub AddStockData_Click(sender As Object, e As EventArgs) Handles AddStockData.Click

        If String.IsNullOrEmpty(ProName.Text) OrElse String.IsNullOrEmpty(CompanyNameText.Text) OrElse String.IsNullOrEmpty(ModelNameTextBox.Text) OrElse String.IsNullOrEmpty(Quantity.Text) OrElse String.IsNullOrEmpty(Price.Text) OrElse String.IsNullOrEmpty(CostPriceTXT.Text) OrElse String.IsNullOrEmpty(SellingPriceTxt.Text) OrElse String.IsNullOrEmpty(TaxInPer.Text) OrElse String.IsNullOrEmpty(STKcodeTextBox.Text) Then
            MessageBox.Show("All Fields are Required", "Incomplete Fields", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Validate tax percentage
        If Not Double.TryParse(TaxInPer.Text, tax) OrElse tax < 0 OrElse tax > 100 Then
            MessageBox.Show("Invalid Tax Percentage. Please enter a value between 0 and 100.", "Invalid Tax Percentage", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Validate quantity
        If Not Integer.TryParse(Quantity.Text, Quant) OrElse Quant <= 0 Then
            MessageBox.Show("Invalid Quantity. Please enter a quantity greater than 0 or Cannot be points.", "Invalid Quantity", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        'Validate Cost Price
        If Not Double.TryParse(CostPriceTXT.Text, Cprise) OrElse Cprise <= 0 Then
            MessageBox.Show("Invalid Cost Price. Please enter a Price greater than 0.", "Invalid Quantity", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        'Validate Selling Price
        If Not Double.TryParse(SellingPriceTxt.Text, SPrice) OrElse SPrice <= 0 Then
            MessageBox.Show("Invalid Selling Price. Please enter a price greater than 0.", "Invalid Selling Price", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' If all validations pass, then retrieve the values from textboxes
        Product = ProName.Text
        Company = CompanyNameText.Text
        Model = ModelNameTextBox.Text
        stk = STKcodeTextBox.Text.ToLower

        ' Display the retrieved values in a message box
        Dim message As String = "Product Name: " & Product & Environment.NewLine &
                        "Company Name: " & Company & Environment.NewLine &
                        "Model: " & Model & Environment.NewLine &
                        "Stock Code: " & stk & Environment.NewLine &
                        "Cost Price: " & Cprise & Environment.NewLine &
                        "Selling Price: " & SPrice & Environment.NewLine &
                        "Tax: " & tax

        Dim result As DialogResult = MessageBox.Show(message, "Stock Information Verification", MessageBoxButtons.OKCancel, MessageBoxIcon.Information)

        If result = DialogResult.OK Then

            Try
                ' Check if the user already exists
                Dim res = client.Get("User/" + usernameofcurrentuser)
                Dim dbsuser = res.ResultAs(Of Myuser)

                ' Check if the user exists
                If dbsuser Is Nothing Then
                    MessageBox.Show("User does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return
                End If

                ' Create a new stock entry
                Dim newStock As New Myuser() With {
                    .ProductName = Product,
                    .CompanyName = Company,
                    .ModelNo = Model,
                    .CostPrice = Cprise,
                    .SellingPrice = SPrice,
                    .StkCode = stk,
                    .TAXInNumber = tax,
                    .Quantity = Quant
                }

                ' Adding the stock data under the user's folder
                Dim setter = client.Set("User/" + usernameofcurrentuser + "/ZzappStockdata" + "/" + stk, newStock)

                If setter.StatusCode = HttpStatusCode.OK Then
                    MessageBox.Show("Stock Added Successfully", "Successful", MessageBoxButtons.OK)
                    ProName.Clear()
                    CompanyNameText.Clear()
                    STKcodeTextBox.Clear()
                    Quantity.Clear()
                    CostPriceTXT.Clear()
                    SellingPriceTxt.Clear()
                    ModelNameTextBox.Clear()
                    TaxInPer.Clear()
                    RefreshStocks()
                Else
                    MessageBox.Show("Failed to add stock data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Catch ex As Exception
                MessageBox.Show("Cannot Connect to Server! Please Check Your Internet Connection and try again later.", "Internet Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End Try
        End If
    End Sub


    Private Sub refresh_Click(sender As Object, e As EventArgs) Handles RefreshBtn.Click
        DataGridView1.Rows.Clear()

        Try
            ' Retrieve data from the "ZzappStockdata" node in Firebase
            Dim res = client.Get("User/" & usernameofcurrentuser & "/ZzappStockdata")
            Dim stockDataDict = res.ResultAs(Of Dictionary(Of String, Myuser))


            If stockDataDict IsNot Nothing AndAlso stockDataDict.Count > 0 Then

                For Each kvp As KeyValuePair(Of String, Myuser) In stockDataDict
                    Dim stockCode As String = kvp.Key
                    Dim stockItem As Myuser = kvp.Value
                    Dim productName As String = stockItem.ProductName
                    Dim companyName As String = stockItem.CompanyName
                    Dim modelNo As String = stockItem.ModelNo
                    Dim costPrice As Double = stockItem.CostPrice
                    Dim sellingPrice As Double = stockItem.SellingPrice
                    Dim tax As Double = stockItem.TAXInNumber
                    Dim quantity As Integer = stockItem.Quantity

                    DataGridView1.Rows.Add(
                    DataGridView1.Rows.Count + 1, ' Sr No
                    stockCode,                     ' Stock Code
                    productName,                  ' Product Name
                    companyName,                  ' Company
                    costPrice,                    ' Cost Price
                    sellingPrice,                 ' Selling Price
                    tax,                          ' Tax In Percentage
                    quantity                      ' Avaliable Quantity
                    )
                Next

                ' Display the concatenated message in a message box
                MessageBox.Show("Table Refreshed Successfully", "Stock Data", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("No stock data found.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            MessageBox.Show("Error retrieving stock data from Firebase: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Function TotalSalesPrice() As Double
        Try
            Dim res = client.Get("User/" & usernameofcurrentuser & "/Total_Sales")
            Dim totals = res.ResultAs(Of Myuser)

            If totals IsNot Nothing Then
                Label28.Text = totals.Totalsales
                Label24.Text = totals.Totalprofit
            Else
                Label24.Text = 0
            End If
        Catch ex As Exception
            MessageBox.Show("Cannot Connect to Surver", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function


    Private Sub GunaButton1_Click(sender As Object, e As EventArgs) Handles GunaButton1.Click
        If TaxInPer.Enabled = False Then
            UpadteGstTxt.Enabled = False
            UpadteGstTxt.Text = 0
        Else
            UpadteGstTxt.Enabled = True
        End If
        GunaShadowPanel19.Show()
        GunaTextBox5.Focus()
    End Sub
    Private Sub GunaCircleButton1_Click(sender As Object, e As EventArgs) Handles GunaCircleButton1.Click
        GunaShadowPanel19.Hide()
        GunaTextBox1.ResetText()
        UpadteGstTxt.ResetText()
        GunaTextBox3.ResetText()
        GunaTextBox4.ResetText()
        GunaTextBox7.ResetText()
        GunaTextBox8.ResetText()
        GunaTextBox5.ResetText()
        GunaTextBox1.Enabled = False
        UpadteGstTxt.Enabled = False
        GunaTextBox3.Enabled = False
        GunaTextBox4.Enabled = False
        GunaTextBox7.Enabled = False
        GunaTextBox8.Enabled = False
        GunaAdvenceButton1.Enabled = False
    End Sub
    Private Sub GunaAdvenceButton2_Click(sender As Object, e As EventArgs) Handles GunaAdvenceButton2.Click
        If TaxInPer.Enabled = False Then
            UpadteGstTxt.Enabled = False
            UpadteGstTxt.Text = 0
        Else
            UpadteGstTxt.Enabled = True
        End If
        If String.IsNullOrEmpty(GunaTextBox5.Text) Then
            MessageBox.Show("Stk Code is Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            GunaTextBox5.Focus()
            Return
        End If

        Try
            Dim finder = client.Get("User/" & usernameofcurrentuser & "/ZzappStockdata/" & GunaTextBox5.Text)
            Dim stockDataDict = finder.ResultAs(Of Myuser)

            If stockDataDict IsNot Nothing Then
                GunaTextBox1.Enabled = True
                If TaxInPer.Enabled = False Then
                    UpadteGstTxt.Enabled = False
                    UpadteGstTxt.Text = 0
                Else
                    UpadteGstTxt.Enabled = True
                End If
                GunaTextBox3.Enabled = True
                GunaTextBox4.Enabled = True
                GunaTextBox7.Enabled = True
                GunaTextBox8.Enabled = True
                GunaAdvenceButton1.Enabled = True
                GunaTextBox7.Text = stockDataDict.ProductName
                GunaTextBox8.Text = stockDataDict.CompanyName
                GunaTextBox1.Text = stockDataDict.Quantity
                If TaxInPer.Enabled = False Then
                    UpadteGstTxt.Enabled = False
                    UpadteGstTxt.Text = 0
                Else
                    UpadteGstTxt.Text = stockDataDict.TAXInNumber
                End If

                GunaTextBox3.Text = stockDataDict.SellingPrice
                GunaTextBox4.Text = stockDataDict.CostPrice
            Else
                MessageBox.Show("Cannot Find Product from provided Stk code '{0}' " & GunaTextBox5.Text, "Inlaid Stk code", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MessageBox.Show("An error occurred while fetching stock data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub GunaAdvenceButton1_Click(sender As Object, e As EventArgs) Handles GunaAdvenceButton1.Click
        If String.IsNullOrEmpty(GunaTextBox1.Text) Or
           String.IsNullOrEmpty(UpadteGstTxt.Text) Or
           String.IsNullOrEmpty(GunaTextBox3.Text) Or
           String.IsNullOrEmpty(GunaTextBox4.Text) Or
           String.IsNullOrEmpty(GunaTextBox7.Text) Or
           String.IsNullOrEmpty(GunaTextBox8.Text) Then
            MessageBox.Show("All Field are Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        Try
            Dim UpdatedProductDetails As New Myuser With
        {
            .Quantity = GunaTextBox1.Text,
            .TAXInNumber = UpadteGstTxt.Text,
            .SellingPrice = GunaTextBox3.Text,
            .CostPrice = GunaTextBox4.Text,
            .ProductName = GunaTextBox7.Text,
            .CompanyName = GunaTextBox8.Text
        }
            Dim add = client.Set("User/" & usernameofcurrentuser & "/ZzappStockdata/" & GunaTextBox5.Text, UpdatedProductDetails)
            If HttpStatusCode.OK Then
                RefreshStocks()
                MessageBox.Show("Product Updated Successfull", "Update Successfully", MessageBoxButtons.OK)
                GunaTextBox1.ResetText()
                UpadteGstTxt.ResetText()
                GunaTextBox3.ResetText()
                GunaTextBox4.ResetText()
                GunaTextBox7.ResetText()
                GunaTextBox8.ResetText()
                GunaTextBox5.ResetText()
                GunaTextBox1.Enabled = False
                UpadteGstTxt.Enabled = False
                GunaTextBox3.Enabled = False
                GunaTextBox4.Enabled = False
                GunaTextBox7.Enabled = False
                GunaTextBox8.Enabled = False
                GunaAdvenceButton1.Enabled = False
            Else
                MessageBox.Show("Falid to update product details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If
        Catch Exception As Exception
            MessageBox.Show("Cannot Connect to server check your internet connection", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class