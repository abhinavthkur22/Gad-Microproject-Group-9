﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Register
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Register))
        Me.Panel3 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Button3 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Label1 = New Guna.UI.WinForms.GunaLabel()
        Me.Button1 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Label10 = New Guna.UI.WinForms.GunaLabel()
        Me.Label11 = New Guna.UI.WinForms.GunaLabel()
        Me.Checkbox1 = New Guna.UI.WinForms.GunaCheckBox()
        Me.TextBox8 = New Guna.UI.WinForms.GunaTextBox()
        Me.Label9 = New Guna.UI.WinForms.GunaLabel()
        Me.ComboBox2 = New Guna.UI.WinForms.GunaComboBox()
        Me.TextBox6 = New Guna.UI.WinForms.GunaTextBox()
        Me.TextBox1 = New Guna.UI.WinForms.GunaTextBox()
        Me.TextBox2 = New Guna.UI.WinForms.GunaTextBox()
        Me.Label8 = New Guna.UI.WinForms.GunaLabel()
        Me.Label6 = New Guna.UI.WinForms.GunaLabel()
        Me.Label2 = New Guna.UI.WinForms.GunaLabel()
        Me.Label4 = New Guna.UI.WinForms.GunaLabel()
        Me.Label7 = New Guna.UI.WinForms.GunaLabel()
        Me.Label5 = New Guna.UI.WinForms.GunaLabel()
        Me.TextBox3 = New Guna.UI.WinForms.GunaTextBox()
        Me.Label3 = New Guna.UI.WinForms.GunaLabel()
        Me.TextBox4 = New Guna.UI.WinForms.GunaTextBox()
        Me.ComboBox1 = New Guna.UI.WinForms.GunaComboBox()
        Me.TextBox5 = New Guna.UI.WinForms.GunaTextBox()
        Me.TextBox7 = New Guna.UI.WinForms.GunaTextBox()
        Me.Panel1 = New Guna.UI.WinForms.GunaElipsePanel()
        Me.Button4 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel4 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.LinkLabel1 = New Guna.UI.WinForms.GunaLinkLabel()
        Me.CheckBox2 = New Guna.UI.WinForms.GunaCheckBox()
        Me.Button8 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Panel6 = New Guna.UI.WinForms.GunaElipsePanel()
        Me.Button6 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Conpasslabel = New System.Windows.Forms.Label()
        Me.TextBoxConpass = New Guna.UI.WinForms.GunaTextBox()
        Me.GunaCirclePictureBox3 = New Guna.UI.WinForms.GunaCirclePictureBox()
        Me.GunaAdvenceButton3 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaLabel1 = New Guna.UI.WinForms.GunaLabel()
        Me.Panel2 = New Guna.UI.WinForms.GunaElipsePanel()
        Me.Usernmelabel = New System.Windows.Forms.Label()
        Me.GunaCirclePictureBox1 = New Guna.UI.WinForms.GunaCirclePictureBox()
        Me.TextBoxUsername = New Guna.UI.WinForms.GunaTextBox()
        Me.Panel5 = New Guna.UI.WinForms.GunaElipsePanel()
        Me.Button5 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Passlabel = New System.Windows.Forms.Label()
        Me.TextBoxPass = New Guna.UI.WinForms.GunaTextBox()
        Me.GunaCirclePictureBox2 = New Guna.UI.WinForms.GunaCirclePictureBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Button10 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Panel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel6.SuspendLayout()
        CType(Me.GunaCirclePictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        CType(Me.GunaCirclePictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel3
        '
        Me.Panel3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.BaseColor = System.Drawing.Color.White
        Me.Panel3.Controls.Add(Me.Label12)
        Me.Panel3.Controls.Add(Me.Button3)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.Button1)
        Me.Panel3.Controls.Add(Me.Label10)
        Me.Panel3.Controls.Add(Me.Label11)
        Me.Panel3.Controls.Add(Me.Checkbox1)
        Me.Panel3.Controls.Add(Me.TextBox8)
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.ComboBox2)
        Me.Panel3.Controls.Add(Me.TextBox6)
        Me.Panel3.Controls.Add(Me.TextBox1)
        Me.Panel3.Controls.Add(Me.TextBox2)
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Controls.Add(Me.TextBox3)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.TextBox4)
        Me.Panel3.Controls.Add(Me.ComboBox1)
        Me.Panel3.Controls.Add(Me.TextBox5)
        Me.Panel3.Controls.Add(Me.TextBox7)
        Me.Panel3.ForeColor = System.Drawing.Color.Black
        Me.Panel3.Location = New System.Drawing.Point(71, 72)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Radius = 10
        Me.Panel3.ShadowColor = System.Drawing.Color.Black
        Me.Panel3.Size = New System.Drawing.Size(988, 594)
        Me.Panel3.TabIndex = 34
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(30, 547)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(195, 27)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Already have an Account?"
        '
        'Button3
        '
        Me.Button3.AnimationHoverSpeed = 0.07!
        Me.Button3.AnimationSpeed = 0.03!
        Me.Button3.BaseColor = System.Drawing.Color.Transparent
        Me.Button3.BorderColor = System.Drawing.Color.Black
        Me.Button3.CheckedBaseColor = System.Drawing.Color.Gray
        Me.Button3.CheckedBorderColor = System.Drawing.Color.Black
        Me.Button3.CheckedForeColor = System.Drawing.Color.Transparent
        Me.Button3.CheckedImage = CType(resources.GetObject("Button3.CheckedImage"), System.Drawing.Image)
        Me.Button3.CheckedLineColor = System.Drawing.Color.DimGray
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button3.FocusedColor = System.Drawing.Color.Empty
        Me.Button3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.Blue
        Me.Button3.Image = Nothing
        Me.Button3.ImageSize = New System.Drawing.Size(20, 20)
        Me.Button3.LineColor = System.Drawing.Color.Transparent
        Me.Button3.Location = New System.Drawing.Point(214, 541)
        Me.Button3.Name = "Button3"
        Me.Button3.OnHoverBaseColor = System.Drawing.Color.Transparent
        Me.Button3.OnHoverBorderColor = System.Drawing.Color.Transparent
        Me.Button3.OnHoverForeColor = System.Drawing.Color.Lime
        Me.Button3.OnHoverImage = Nothing
        Me.Button3.OnHoverLineColor = System.Drawing.Color.Transparent
        Me.Button3.OnPressedColor = System.Drawing.Color.Black
        Me.Button3.Size = New System.Drawing.Size(66, 34)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "Sign In"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(336, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(280, 40)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Register Your Store"
        '
        'Button1
        '
        Me.Button1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button1.AnimationHoverSpeed = 0.07!
        Me.Button1.AnimationSpeed = 0.03!
        Me.Button1.BackColor = System.Drawing.Color.Transparent
        Me.Button1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button1.BorderColor = System.Drawing.Color.Black
        Me.Button1.CheckedBaseColor = System.Drawing.Color.Gray
        Me.Button1.CheckedBorderColor = System.Drawing.Color.Black
        Me.Button1.CheckedForeColor = System.Drawing.Color.White
        Me.Button1.CheckedImage = Nothing
        Me.Button1.CheckedLineColor = System.Drawing.Color.DimGray
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button1.FocusedColor = System.Drawing.Color.Empty
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Image = Nothing
        Me.Button1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Button1.ImageSize = New System.Drawing.Size(20, 20)
        Me.Button1.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(303, 462)
        Me.Button1.Name = "Button1"
        Me.Button1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.Button1.OnHoverForeColor = System.Drawing.Color.White
        Me.Button1.OnHoverImage = Nothing
        Me.Button1.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button1.OnPressedColor = System.Drawing.Color.Black
        Me.Button1.Radius = 10
        Me.Button1.Size = New System.Drawing.Size(412, 55)
        Me.Button1.TabIndex = 33
        Me.Button1.Text = "Save and Next"
        Me.Button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label10.Location = New System.Drawing.Point(119, 372)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(74, 15)
        Me.Label10.TabIndex = 28
        Me.Label10.Text = "GST Number"
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label11.Location = New System.Drawing.Point(489, 372)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(85, 15)
        Me.Label11.TabIndex = 30
        Me.Label11.Text = "Billing Address"
        '
        'Checkbox1
        '
        Me.Checkbox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Checkbox1.BaseColor = System.Drawing.Color.White
        Me.Checkbox1.CheckedOffColor = System.Drawing.Color.Gray
        Me.Checkbox1.CheckedOnColor = System.Drawing.Color.Lime
        Me.Checkbox1.FillColor = System.Drawing.Color.White
        Me.Checkbox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Checkbox1.Location = New System.Drawing.Point(122, 349)
        Me.Checkbox1.Name = "Checkbox1"
        Me.Checkbox1.Size = New System.Drawing.Size(147, 20)
        Me.Checkbox1.TabIndex = 17
        Me.Checkbox1.Text = "I have GST number"
        '
        'TextBox8
        '
        Me.TextBox8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox8.BackColor = System.Drawing.Color.Transparent
        Me.TextBox8.BaseColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TextBox8.BorderColor = System.Drawing.Color.Black
        Me.TextBox8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox8.FocusedBaseColor = System.Drawing.Color.White
        Me.TextBox8.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox8.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBox8.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.TextBox8.Location = New System.Drawing.Point(494, 390)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBox8.Radius = 6
        Me.TextBox8.SelectedText = ""
        Me.TextBox8.Size = New System.Drawing.Size(392, 45)
        Me.TextBox8.TabIndex = 29
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label9.Location = New System.Drawing.Point(491, 273)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(96, 15)
        Me.Label9.TabIndex = 25
        Me.Label9.Text = "Contact Number"
        '
        'ComboBox2
        '
        Me.ComboBox2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ComboBox2.BackColor = System.Drawing.Color.Transparent
        Me.ComboBox2.BaseColor = System.Drawing.Color.White
        Me.ComboBox2.BorderColor = System.Drawing.Color.Black
        Me.ComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.FocusedColor = System.Drawing.Color.Empty
        Me.ComboBox2.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ComboBox2.ForeColor = System.Drawing.Color.Black
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.ItemHeight = 38
        Me.ComboBox2.Items.AddRange(New Object() {"Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"})
        Me.ComboBox2.Location = New System.Drawing.Point(494, 226)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ComboBox2.OnHoverItemForeColor = System.Drawing.Color.White
        Me.ComboBox2.Radius = 6
        Me.ComboBox2.Size = New System.Drawing.Size(392, 44)
        Me.ComboBox2.TabIndex = 26
        '
        'TextBox6
        '
        Me.TextBox6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox6.BackColor = System.Drawing.Color.Transparent
        Me.TextBox6.BaseColor = System.Drawing.Color.White
        Me.TextBox6.BorderColor = System.Drawing.Color.Black
        Me.TextBox6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox6.FocusedBaseColor = System.Drawing.Color.White
        Me.TextBox6.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox6.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBox6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.TextBox6.Location = New System.Drawing.Point(494, 291)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBox6.Radius = 6
        Me.TextBox6.SelectedText = ""
        Me.TextBox6.Size = New System.Drawing.Size(392, 45)
        Me.TextBox6.TabIndex = 32
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox1.BackColor = System.Drawing.Color.Transparent
        Me.TextBox1.BaseColor = System.Drawing.Color.White
        Me.TextBox1.BorderColor = System.Drawing.Color.Black
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox1.FocusedBaseColor = System.Drawing.Color.White
        Me.TextBox1.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox1.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.TextBox1.Location = New System.Drawing.Point(121, 91)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBox1.Radius = 6
        Me.TextBox1.SelectedText = ""
        Me.TextBox1.Size = New System.Drawing.Size(361, 45)
        Me.TextBox1.TabIndex = 10
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox2.BackColor = System.Drawing.Color.Transparent
        Me.TextBox2.BaseColor = System.Drawing.Color.White
        Me.TextBox2.BorderColor = System.Drawing.Color.Black
        Me.TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox2.FocusedBaseColor = System.Drawing.Color.White
        Me.TextBox2.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox2.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBox2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.TextBox2.Location = New System.Drawing.Point(494, 91)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBox2.Radius = 6
        Me.TextBox2.SelectedText = ""
        Me.TextBox2.Size = New System.Drawing.Size(392, 45)
        Me.TextBox2.TabIndex = 12
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label8.Location = New System.Drawing.Point(118, 208)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(80, 15)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "Telephone No"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label6.Location = New System.Drawing.Point(118, 273)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 15)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Address"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(123, 73)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 15)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "First Name"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label4.Location = New System.Drawing.Point(491, 73)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 15)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Surname Name"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label7.Location = New System.Drawing.Point(491, 208)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(33, 15)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "State"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label5.Location = New System.Drawing.Point(491, 137)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 15)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Store Catogory"
        '
        'TextBox3
        '
        Me.TextBox3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox3.BackColor = System.Drawing.Color.Transparent
        Me.TextBox3.BaseColor = System.Drawing.Color.White
        Me.TextBox3.BorderColor = System.Drawing.Color.Black
        Me.TextBox3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox3.FocusedBaseColor = System.Drawing.Color.White
        Me.TextBox3.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox3.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBox3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.TextBox3.Location = New System.Drawing.Point(122, 155)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBox3.Radius = 6
        Me.TextBox3.SelectedText = ""
        Me.TextBox3.Size = New System.Drawing.Size(361, 45)
        Me.TextBox3.TabIndex = 14
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label3.Location = New System.Drawing.Point(124, 137)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 15)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Store Name"
        '
        'TextBox4
        '
        Me.TextBox4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox4.BackColor = System.Drawing.Color.Transparent
        Me.TextBox4.BaseColor = System.Drawing.Color.White
        Me.TextBox4.BorderColor = System.Drawing.Color.Black
        Me.TextBox4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox4.FocusedBaseColor = System.Drawing.Color.White
        Me.TextBox4.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox4.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBox4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.TextBox4.Location = New System.Drawing.Point(121, 226)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBox4.Radius = 6
        Me.TextBox4.SelectedText = ""
        Me.TextBox4.Size = New System.Drawing.Size(361, 45)
        Me.TextBox4.TabIndex = 19
        '
        'ComboBox1
        '
        Me.ComboBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ComboBox1.BackColor = System.Drawing.Color.Transparent
        Me.ComboBox1.BaseColor = System.Drawing.Color.White
        Me.ComboBox1.BorderColor = System.Drawing.Color.Black
        Me.ComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.DropDownWidth = 300
        Me.ComboBox1.FocusedColor = System.Drawing.Color.Empty
        Me.ComboBox1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.ComboBox1.ForeColor = System.Drawing.Color.Black
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.ItemHeight = 38
        Me.ComboBox1.Items.AddRange(New Object() {"Electronic Store", "Hardware Store", "Medical", "Other"})
        Me.ComboBox1.Location = New System.Drawing.Point(494, 157)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ComboBox1.OnHoverItemForeColor = System.Drawing.Color.White
        Me.ComboBox1.Radius = 6
        Me.ComboBox1.Size = New System.Drawing.Size(392, 44)
        Me.ComboBox1.TabIndex = 15
        '
        'TextBox5
        '
        Me.TextBox5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox5.BackColor = System.Drawing.Color.Transparent
        Me.TextBox5.BaseColor = System.Drawing.Color.White
        Me.TextBox5.BorderColor = System.Drawing.Color.Black
        Me.TextBox5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox5.FocusedBaseColor = System.Drawing.Color.White
        Me.TextBox5.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox5.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBox5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.TextBox5.Location = New System.Drawing.Point(121, 291)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBox5.Radius = 6
        Me.TextBox5.SelectedText = ""
        Me.TextBox5.Size = New System.Drawing.Size(361, 45)
        Me.TextBox5.TabIndex = 23
        '
        'TextBox7
        '
        Me.TextBox7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox7.BackColor = System.Drawing.Color.Transparent
        Me.TextBox7.BaseColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TextBox7.BorderColor = System.Drawing.Color.Black
        Me.TextBox7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox7.FocusedBaseColor = System.Drawing.Color.White
        Me.TextBox7.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox7.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBox7.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.TextBox7.Location = New System.Drawing.Point(122, 390)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBox7.Radius = 6
        Me.TextBox7.SelectedText = ""
        Me.TextBox7.Size = New System.Drawing.Size(361, 45)
        Me.TextBox7.TabIndex = 27
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BaseColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.TabControl1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.ForeColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Radius = 10
        Me.Panel1.Size = New System.Drawing.Size(1103, 714)
        Me.Panel1.TabIndex = 7
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.AnimationHoverSpeed = 0.07!
        Me.Button4.AnimationSpeed = 0.03!
        Me.Button4.BackColor = System.Drawing.Color.Transparent
        Me.Button4.BaseColor = System.Drawing.Color.Transparent
        Me.Button4.BorderColor = System.Drawing.Color.Black
        Me.Button4.CheckedBaseColor = System.Drawing.Color.Gray
        Me.Button4.CheckedBorderColor = System.Drawing.Color.Black
        Me.Button4.CheckedForeColor = System.Drawing.Color.White
        Me.Button4.CheckedImage = Nothing
        Me.Button4.CheckedLineColor = System.Drawing.Color.DimGray
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button4.FocusedColor = System.Drawing.Color.Empty
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Image = Global.ElectronicStore.My.Resources.Resources.night_mode1
        Me.Button4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Button4.ImageSize = New System.Drawing.Size(20, 20)
        Me.Button4.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button4.Location = New System.Drawing.Point(1047, 682)
        Me.Button4.Name = "Button4"
        Me.Button4.OnHoverBaseColor = System.Drawing.Color.Transparent
        Me.Button4.OnHoverBorderColor = System.Drawing.Color.Black
        Me.Button4.OnHoverForeColor = System.Drawing.Color.White
        Me.Button4.OnHoverImage = Nothing
        Me.Button4.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button4.OnPressedColor = System.Drawing.Color.Black
        Me.Button4.Radius = 10
        Me.Button4.Size = New System.Drawing.Size(56, 29)
        Me.Button4.TabIndex = 6
        Me.Button4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(-8, -24)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1122, 750)
        Me.TabControl1.TabIndex = 35
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TabPage1.Controls.Add(Me.Panel3)
        Me.TabPage1.ForeColor = System.Drawing.Color.Transparent
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1114, 724)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Panel4)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1114, 724)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.BaseColor = System.Drawing.Color.White
        Me.Panel4.Controls.Add(Me.LinkLabel1)
        Me.Panel4.Controls.Add(Me.CheckBox2)
        Me.Panel4.Controls.Add(Me.Button8)
        Me.Panel4.Controls.Add(Me.Panel6)
        Me.Panel4.Controls.Add(Me.GunaAdvenceButton3)
        Me.Panel4.Controls.Add(Me.GunaLabel1)
        Me.Panel4.Controls.Add(Me.Panel2)
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Controls.Add(Me.Label15)
        Me.Panel4.Controls.Add(Me.Button10)
        Me.Panel4.ForeColor = System.Drawing.Color.Black
        Me.Panel4.Location = New System.Drawing.Point(64, 66)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Radius = 10
        Me.Panel4.ShadowColor = System.Drawing.Color.Black
        Me.Panel4.Size = New System.Drawing.Size(1005, 612)
        Me.Panel4.TabIndex = 35
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(338, 366)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(133, 16)
        Me.LinkLabel1.TabIndex = 41
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "terms and conditions."
        Me.LinkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CheckBox2
        '
        Me.CheckBox2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.CheckBox2.BaseColor = System.Drawing.Color.White
        Me.CheckBox2.CheckedOffColor = System.Drawing.Color.Gray
        Me.CheckBox2.CheckedOnColor = System.Drawing.Color.Lime
        Me.CheckBox2.FillColor = System.Drawing.Color.White
        Me.CheckBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.Location = New System.Drawing.Point(270, 365)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(77, 20)
        Me.CheckBox2.TabIndex = 40
        Me.CheckBox2.Text = "I accept "
        '
        'Button8
        '
        Me.Button8.AnimationHoverSpeed = 0.07!
        Me.Button8.AnimationSpeed = 0.03!
        Me.Button8.BackColor = System.Drawing.Color.Transparent
        Me.Button8.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button8.BorderColor = System.Drawing.Color.Black
        Me.Button8.CheckedBaseColor = System.Drawing.Color.Gray
        Me.Button8.CheckedBorderColor = System.Drawing.Color.Black
        Me.Button8.CheckedForeColor = System.Drawing.Color.White
        Me.Button8.CheckedImage = Nothing
        Me.Button8.CheckedLineColor = System.Drawing.Color.DimGray
        Me.Button8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button8.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button8.FocusedColor = System.Drawing.Color.Empty
        Me.Button8.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.White
        Me.Button8.Image = Global.ElectronicStore.My.Resources.Resources.add_user
        Me.Button8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Button8.ImageSize = New System.Drawing.Size(20, 20)
        Me.Button8.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button8.Location = New System.Drawing.Point(510, 440)
        Me.Button8.Name = "Button8"
        Me.Button8.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button8.OnHoverBorderColor = System.Drawing.Color.Black
        Me.Button8.OnHoverForeColor = System.Drawing.Color.White
        Me.Button8.OnHoverImage = Nothing
        Me.Button8.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button8.OnPressedColor = System.Drawing.Color.Black
        Me.Button8.Radius = 10
        Me.Button8.Size = New System.Drawing.Size(235, 55)
        Me.Button8.TabIndex = 39
        Me.Button8.Text = "Create Account"
        Me.Button8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Transparent
        Me.Panel6.BaseColor = System.Drawing.Color.White
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.Button6)
        Me.Panel6.Controls.Add(Me.Conpasslabel)
        Me.Panel6.Controls.Add(Me.TextBoxConpass)
        Me.Panel6.Controls.Add(Me.GunaCirclePictureBox3)
        Me.Panel6.Location = New System.Drawing.Point(269, 289)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Radius = 10
        Me.Panel6.Size = New System.Drawing.Size(476, 52)
        Me.Panel6.TabIndex = 36
        '
        'Button6
        '
        Me.Button6.AnimationHoverSpeed = 0.07!
        Me.Button6.AnimationSpeed = 0.03!
        Me.Button6.BackColor = System.Drawing.Color.Transparent
        Me.Button6.BaseColor = System.Drawing.Color.Transparent
        Me.Button6.BorderColor = System.Drawing.Color.Black
        Me.Button6.CheckedBaseColor = System.Drawing.Color.Gray
        Me.Button6.CheckedBorderColor = System.Drawing.Color.Black
        Me.Button6.CheckedForeColor = System.Drawing.Color.White
        Me.Button6.CheckedImage = Nothing
        Me.Button6.CheckedLineColor = System.Drawing.Color.DimGray
        Me.Button6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button6.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button6.FocusedColor = System.Drawing.Color.Empty
        Me.Button6.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.White
        Me.Button6.Image = Global.ElectronicStore.My.Resources.Resources.eye
        Me.Button6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Button6.ImageSize = New System.Drawing.Size(20, 20)
        Me.Button6.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button6.Location = New System.Drawing.Point(428, 4)
        Me.Button6.Name = "Button6"
        Me.Button6.OnHoverBaseColor = System.Drawing.Color.Transparent
        Me.Button6.OnHoverBorderColor = System.Drawing.Color.Black
        Me.Button6.OnHoverForeColor = System.Drawing.Color.White
        Me.Button6.OnHoverImage = Nothing
        Me.Button6.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button6.OnPressedColor = System.Drawing.Color.Black
        Me.Button6.Radius = 10
        Me.Button6.Size = New System.Drawing.Size(48, 41)
        Me.Button6.TabIndex = 6
        Me.Button6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Conpasslabel
        '
        Me.Conpasslabel.AutoSize = True
        Me.Conpasslabel.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Conpasslabel.ForeColor = System.Drawing.Color.Black
        Me.Conpasslabel.Location = New System.Drawing.Point(47, 14)
        Me.Conpasslabel.Name = "Conpasslabel"
        Me.Conpasslabel.Size = New System.Drawing.Size(127, 20)
        Me.Conpasslabel.TabIndex = 7
        Me.Conpasslabel.Text = "Confirm Password"
        '
        'TextBoxConpass
        '
        Me.TextBoxConpass.BaseColor = System.Drawing.Color.Transparent
        Me.TextBoxConpass.BorderColor = System.Drawing.Color.Transparent
        Me.TextBoxConpass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBoxConpass.FocusedBaseColor = System.Drawing.Color.Transparent
        Me.TextBoxConpass.FocusedBorderColor = System.Drawing.Color.Transparent
        Me.TextBoxConpass.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBoxConpass.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxConpass.ForeColor = System.Drawing.Color.Blue
        Me.TextBoxConpass.Location = New System.Drawing.Point(51, 1)
        Me.TextBoxConpass.Name = "TextBoxConpass"
        Me.TextBoxConpass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9679)
        Me.TextBoxConpass.SelectedText = ""
        Me.TextBoxConpass.Size = New System.Drawing.Size(385, 46)
        Me.TextBoxConpass.TabIndex = 4
        Me.TextBoxConpass.UseSystemPasswordChar = True
        '
        'GunaCirclePictureBox3
        '
        Me.GunaCirclePictureBox3.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCirclePictureBox3.Image = Global.ElectronicStore.My.Resources.Resources.padlock
        Me.GunaCirclePictureBox3.Location = New System.Drawing.Point(3, 5)
        Me.GunaCirclePictureBox3.Name = "GunaCirclePictureBox3"
        Me.GunaCirclePictureBox3.Size = New System.Drawing.Size(38, 40)
        Me.GunaCirclePictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.GunaCirclePictureBox3.TabIndex = 4
        Me.GunaCirclePictureBox3.TabStop = False
        Me.GunaCirclePictureBox3.UseTransfarantBackground = False
        '
        'GunaAdvenceButton3
        '
        Me.GunaAdvenceButton3.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton3.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton3.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton3.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton3.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton3.CheckedImage = Nothing
        Me.GunaAdvenceButton3.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton3.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.GunaAdvenceButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton3.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaAdvenceButton3.ForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton3.Image = Global.ElectronicStore.My.Resources.Resources.previous
        Me.GunaAdvenceButton3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton3.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton3.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton3.Location = New System.Drawing.Point(269, 440)
        Me.GunaAdvenceButton3.Name = "GunaAdvenceButton3"
        Me.GunaAdvenceButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton3.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton3.OnHoverImage = Nothing
        Me.GunaAdvenceButton3.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton3.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.Radius = 10
        Me.GunaAdvenceButton3.Size = New System.Drawing.Size(235, 55)
        Me.GunaAdvenceButton3.TabIndex = 38
        Me.GunaAdvenceButton3.Text = "Previous Page"
        Me.GunaAdvenceButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaLabel1
        '
        Me.GunaLabel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GunaLabel1.AutoSize = True
        Me.GunaLabel1.Font = New System.Drawing.Font("Segoe UI", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel1.ForeColor = System.Drawing.Color.Blue
        Me.GunaLabel1.Location = New System.Drawing.Point(371, 44)
        Me.GunaLabel1.Name = "GunaLabel1"
        Me.GunaLabel1.Size = New System.Drawing.Size(227, 40)
        Me.GunaLabel1.TabIndex = 37
        Me.GunaLabel1.Text = "Create Account"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BaseColor = System.Drawing.Color.White
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Usernmelabel)
        Me.Panel2.Controls.Add(Me.GunaCirclePictureBox1)
        Me.Panel2.Controls.Add(Me.TextBoxUsername)
        Me.Panel2.Location = New System.Drawing.Point(269, 127)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Radius = 10
        Me.Panel2.Size = New System.Drawing.Size(476, 52)
        Me.Panel2.TabIndex = 34
        '
        'Usernmelabel
        '
        Me.Usernmelabel.AutoSize = True
        Me.Usernmelabel.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Usernmelabel.ForeColor = System.Drawing.Color.Black
        Me.Usernmelabel.Location = New System.Drawing.Point(47, 15)
        Me.Usernmelabel.Name = "Usernmelabel"
        Me.Usernmelabel.Size = New System.Drawing.Size(75, 20)
        Me.Usernmelabel.TabIndex = 6
        Me.Usernmelabel.Text = "Username"
        '
        'GunaCirclePictureBox1
        '
        Me.GunaCirclePictureBox1.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCirclePictureBox1.Image = Global.ElectronicStore.My.Resources.Resources.user
        Me.GunaCirclePictureBox1.Location = New System.Drawing.Point(3, 5)
        Me.GunaCirclePictureBox1.Name = "GunaCirclePictureBox1"
        Me.GunaCirclePictureBox1.Size = New System.Drawing.Size(38, 40)
        Me.GunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.GunaCirclePictureBox1.TabIndex = 3
        Me.GunaCirclePictureBox1.TabStop = False
        Me.GunaCirclePictureBox1.UseTransfarantBackground = False
        '
        'TextBoxUsername
        '
        Me.TextBoxUsername.BaseColor = System.Drawing.Color.Transparent
        Me.TextBoxUsername.BorderColor = System.Drawing.Color.Transparent
        Me.TextBoxUsername.BorderSize = 3
        Me.TextBoxUsername.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBoxUsername.FocusedBaseColor = System.Drawing.Color.Transparent
        Me.TextBoxUsername.FocusedBorderColor = System.Drawing.Color.Transparent
        Me.TextBoxUsername.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBoxUsername.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxUsername.ForeColor = System.Drawing.Color.Blue
        Me.TextBoxUsername.Location = New System.Drawing.Point(44, 3)
        Me.TextBoxUsername.Name = "TextBoxUsername"
        Me.TextBoxUsername.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBoxUsername.SelectedText = ""
        Me.TextBoxUsername.Size = New System.Drawing.Size(365, 46)
        Me.TextBoxUsername.TabIndex = 2
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Transparent
        Me.Panel5.BaseColor = System.Drawing.Color.White
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.Button5)
        Me.Panel5.Controls.Add(Me.Passlabel)
        Me.Panel5.Controls.Add(Me.TextBoxPass)
        Me.Panel5.Controls.Add(Me.GunaCirclePictureBox2)
        Me.Panel5.Location = New System.Drawing.Point(269, 210)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Radius = 10
        Me.Panel5.Size = New System.Drawing.Size(476, 52)
        Me.Panel5.TabIndex = 35
        '
        'Button5
        '
        Me.Button5.AnimationHoverSpeed = 0.07!
        Me.Button5.AnimationSpeed = 0.03!
        Me.Button5.BackColor = System.Drawing.Color.Transparent
        Me.Button5.BaseColor = System.Drawing.Color.Transparent
        Me.Button5.BorderColor = System.Drawing.Color.Black
        Me.Button5.CheckedBaseColor = System.Drawing.Color.Gray
        Me.Button5.CheckedBorderColor = System.Drawing.Color.Black
        Me.Button5.CheckedForeColor = System.Drawing.Color.White
        Me.Button5.CheckedImage = Nothing
        Me.Button5.CheckedLineColor = System.Drawing.Color.DimGray
        Me.Button5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button5.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button5.FocusedColor = System.Drawing.Color.Empty
        Me.Button5.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.Image = Global.ElectronicStore.My.Resources.Resources.eye
        Me.Button5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Button5.ImageSize = New System.Drawing.Size(20, 20)
        Me.Button5.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button5.Location = New System.Drawing.Point(428, 7)
        Me.Button5.Name = "Button5"
        Me.Button5.OnHoverBaseColor = System.Drawing.Color.Transparent
        Me.Button5.OnHoverBorderColor = System.Drawing.Color.Black
        Me.Button5.OnHoverForeColor = System.Drawing.Color.White
        Me.Button5.OnHoverImage = Nothing
        Me.Button5.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Button5.OnPressedColor = System.Drawing.Color.Black
        Me.Button5.Radius = 10
        Me.Button5.Size = New System.Drawing.Size(48, 41)
        Me.Button5.TabIndex = 6
        Me.Button5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Passlabel
        '
        Me.Passlabel.AutoSize = True
        Me.Passlabel.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Passlabel.ForeColor = System.Drawing.Color.Black
        Me.Passlabel.Location = New System.Drawing.Point(47, 15)
        Me.Passlabel.Name = "Passlabel"
        Me.Passlabel.Size = New System.Drawing.Size(70, 20)
        Me.Passlabel.TabIndex = 7
        Me.Passlabel.Text = "Password"
        '
        'TextBoxPass
        '
        Me.TextBoxPass.BaseColor = System.Drawing.Color.Transparent
        Me.TextBoxPass.BorderColor = System.Drawing.Color.Transparent
        Me.TextBoxPass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBoxPass.FocusedBaseColor = System.Drawing.Color.Transparent
        Me.TextBoxPass.FocusedBorderColor = System.Drawing.Color.Transparent
        Me.TextBoxPass.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.TextBoxPass.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPass.ForeColor = System.Drawing.Color.Blue
        Me.TextBoxPass.Location = New System.Drawing.Point(44, 2)
        Me.TextBoxPass.Name = "TextBoxPass"
        Me.TextBoxPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9679)
        Me.TextBoxPass.SelectedText = ""
        Me.TextBoxPass.Size = New System.Drawing.Size(392, 46)
        Me.TextBoxPass.TabIndex = 4
        Me.TextBoxPass.UseSystemPasswordChar = True
        '
        'GunaCirclePictureBox2
        '
        Me.GunaCirclePictureBox2.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCirclePictureBox2.Image = Global.ElectronicStore.My.Resources.Resources.padlock
        Me.GunaCirclePictureBox2.Location = New System.Drawing.Point(3, 5)
        Me.GunaCirclePictureBox2.Name = "GunaCirclePictureBox2"
        Me.GunaCirclePictureBox2.Size = New System.Drawing.Size(38, 40)
        Me.GunaCirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.GunaCirclePictureBox2.TabIndex = 4
        Me.GunaCirclePictureBox2.TabStop = False
        Me.GunaCirclePictureBox2.UseTransfarantBackground = False
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(30, 569)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(194, 27)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Already have an Account?"
        '
        'Button10
        '
        Me.Button10.AnimationHoverSpeed = 0.07!
        Me.Button10.AnimationSpeed = 0.03!
        Me.Button10.BaseColor = System.Drawing.Color.Transparent
        Me.Button10.BorderColor = System.Drawing.Color.Black
        Me.Button10.CheckedBaseColor = System.Drawing.Color.Gray
        Me.Button10.CheckedBorderColor = System.Drawing.Color.Black
        Me.Button10.CheckedForeColor = System.Drawing.Color.Transparent
        Me.Button10.CheckedImage = CType(resources.GetObject("Button10.CheckedImage"), System.Drawing.Image)
        Me.Button10.CheckedLineColor = System.Drawing.Color.DimGray
        Me.Button10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button10.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button10.FocusedColor = System.Drawing.Color.Empty
        Me.Button10.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.Blue
        Me.Button10.Image = Nothing
        Me.Button10.ImageSize = New System.Drawing.Size(20, 20)
        Me.Button10.LineColor = System.Drawing.Color.Transparent
        Me.Button10.Location = New System.Drawing.Point(213, 563)
        Me.Button10.Name = "Button10"
        Me.Button10.OnHoverBaseColor = System.Drawing.Color.Transparent
        Me.Button10.OnHoverBorderColor = System.Drawing.Color.Transparent
        Me.Button10.OnHoverForeColor = System.Drawing.Color.Lime
        Me.Button10.OnHoverImage = Nothing
        Me.Button10.OnHoverLineColor = System.Drawing.Color.Transparent
        Me.Button10.OnPressedColor = System.Drawing.Color.Black
        Me.Button10.Size = New System.Drawing.Size(65, 34)
        Me.Button10.TabIndex = 5
        Me.Button10.Text = "Sign In"
        '
        'Register
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1103, 714)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Register"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Register your Store"
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.GunaCirclePictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        CType(Me.GunaCirclePictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel3 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label12 As Label
    Friend WithEvents Button3 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Label1 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Button1 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Label10 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Label11 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Checkbox1 As Guna.UI.WinForms.GunaCheckBox
    Friend WithEvents TextBox8 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label9 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents ComboBox2 As Guna.UI.WinForms.GunaComboBox
    Friend WithEvents TextBox6 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents TextBox1 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents TextBox2 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label8 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Label6 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Label2 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Label4 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Label7 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Label5 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents TextBox3 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Label3 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents TextBox4 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents ComboBox1 As Guna.UI.WinForms.GunaComboBox
    Friend WithEvents TextBox5 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents TextBox7 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Button4 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Panel1 As Guna.UI.WinForms.GunaElipsePanel
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Panel4 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceButton3 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaLabel1 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Panel2 As Guna.UI.WinForms.GunaElipsePanel
    Friend WithEvents Usernmelabel As Label
    Friend WithEvents GunaCirclePictureBox1 As Guna.UI.WinForms.GunaCirclePictureBox
    Friend WithEvents TextBoxUsername As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents Panel5 As Guna.UI.WinForms.GunaElipsePanel
    Friend WithEvents Button5 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Passlabel As Label
    Friend WithEvents TextBoxPass As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents GunaCirclePictureBox2 As Guna.UI.WinForms.GunaCirclePictureBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Button10 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Panel6 As Guna.UI.WinForms.GunaElipsePanel
    Friend WithEvents Button6 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Conpasslabel As Label
    Friend WithEvents TextBoxConpass As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents GunaCirclePictureBox3 As Guna.UI.WinForms.GunaCirclePictureBox
    Friend WithEvents Button8 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents LinkLabel1 As Guna.UI.WinForms.GunaLinkLabel
    Friend WithEvents CheckBox2 As Guna.UI.WinForms.GunaCheckBox
End Class
